# Do Second Late — Python production handoff
Current method: Python/Pillow articulated 2D animation, NumPy/SciPy sound synthesis, FFmpeg encoding.
The user explicitly chose Python-based animation for precise character movement, mirror timing, camera work and SFX. This supersedes the earlier paid AI-video approach. Do not resume the remaining AI-video jobs for this production.

## Deliverables
- 60 seconds, 24 fps, vertical 9:16.
- Native 2160×3840 geometry render and 1080×1920 sharing copy.
- Previously generated Hindi Viraj narration, edited into phrase groups with pauses for action.
- Locally synthesized water, drips, fabric, door creaks, phone impacts and quiet tension bed.
- Plain Hinglish subtitles and separate SRT.
- Thumbnail using the same Python character rig as the film.
- Editable source ZIP with script, font license and source narration.

## Exact prediction timing
| Action | Reflection | Real | Gap |
|---|---:|---:|---:|
| Face straightens | 2s | 4s | 2s |
| Hand raises | 10s | 12s | 2s |
| Hand lowers | 14s | 16s | 2s |
| Door opens | 26s | 28s | 2s |
| Shoulder grab | 44s | 46s | 2s |
| Disappearance | 47s | 49s | 2s |
The real actor uses pose(t), the reflection uses pose(t+2). After 51 seconds, the reflection intentionally acts independently for the final reveal.

## Visual scope
Stylized articulated 2D with interpolated joint movement, eye and mouth acting, hand poses, hinged door movement, camera easing and a physical phone fall. This is a procedural rig, not hand-drawn frame-by-frame animation. No AI-generated video frames are used. No channel branding, watermark or CTA appears in the video.

## Rebuild
See README.md in Do_Second_Late_Python_Project.zip. The output directory holds the 4K master, 1080p version, SRT, thumbnail and timing report. The original draft package remains historical and is superseded by the Python project.

## Narration transcript
राघव का चेहरा पानी में झुका था। लेकिन आईने में... वह उसे देख रहा था।
उसने सोचा, नींद कम हुई है। फिर परछाईं ने हाथ उठाया। दो सेकंड बाद... उसका अपना हाथ उठ गया।
राघव ने फ़ोन निकाला। सब रिकॉर्ड करना था। तभी आईने में पीछे का दरवाज़ा खुला।
उसने पलटकर देखा। दरवाज़ा बंद था। दो सेकंड बाद... वह भी खुल गया।
आईना देर से नहीं चल रहा था। वह दो सेकंड आगे था।
फिर आईने में उसके कंधे पर एक काला हाथ आया। राघव पीछे हटना चाहता था। मगर दो सेकंड बीत चुके थे।
बाथरूम खाली था। आईना नहीं। अब तुम्हारी बारी।

## Hinglish subtitle copy — timing pending final edit
Raghav ka chehra paani mein jhuka tha.
Lekin aaine mein... woh use dekh raha tha.
Usne socha, neend kam hui hai.
Phir parchhaai ne haath uthaya.
Do second baad... uska apna haath uth gaya.
Raghav ne phone nikala. Sab record karna tha.
Tabhi aaine mein peechhe ka darwaaza khula.
Usne palatkar dekha. Darwaaza band tha.
Do second baad... woh bhi khul gaya.
Aaina der se nahi chal raha tha.
Woh do second aage tha.
Phir aaine mein uske kandhe par ek kaala haath aaya.
Raghav peechhe hatna chahta tha.
Magar do second beet chuke the.
Bathroom khaali tha. Aaina nahi.
Ab tumhari baari.


## Social copy
YouTube title: Aaina 2 Second Aage Tha 😨 | Do Second Late | Hindi Horror
Description: Raghav ko laga uska aaina ajeeb tarah se chal raha hai. Phir usne kuch aisa dekha jo abhi hua hi nahi tha. Ek original kalpanik animated horror kahani.
Instagram/Facebook caption: Agar aaina tumhara agla kadam pehle hi dikha de... kya tum use badal paoge? 🪞 Do Second Late — ek kalpanik animated horror kahani.
Hashtags: #HindiHorror #AnimatedHorror #HorrorStory #DoSecondLate #HorrorReels
Pinned comment: Tum sabse pehle phone uthate ya bathroom se bhaagte?

