# Social media posting package — all 5 completed stories

Ready-to-copy Hinglish copy. Each platform has its own title/cover text, description or caption, and hashtags. YouTube tags are comma-separated. These are original fictional horror stories; no endings are revealed below. Hashtags are topic-based, not claims of current trends.

## 1. Kal Ki Recording

### YouTube Shorts
**Title**
CCTV Par Kal Ki Recording Kaise? | Hindi Horror Story

**Description**
Raat ke 2 baje security guard Aman ne CCTV par khud ko dekha. Waqt sahi tha... lekin tareekh kal ki thi. Phir recording mein dikhne wali aurat sach mein darwaaze par aa gayi.

Aap Aman ki jagah hote toh kya karte?

Ek original fictional Hindi horror story, 2D animation ke saath.
Subscribe karein aur Facebook, Instagram pe follow karein.

**Hashtags**
#HindiHorror #CCTVHorror #HorrorStory #AnimatedHorror #Shorts

**YouTube tags — comma-separated**
kal ki recording, CCTV horror story, Hindi horror story, horror story in Hindi, security guard horror, future recording, scary CCTV, paranormal story, animated horror, 2D animation, suspense story, Hindi kahani, horror shorts, scary story

### Instagram Reels
**Cover title**
KAL KI RECORDING?

**Caption**
CCTV par khud ko dekha... lekin tareekh KAL ki thi. 📹
Phir entrance ki ghanti baji.

Aap darwaaza kholte ya screen band karte?

Original fictional horror story.
Aisi aur kahaniyon ke liye FOLLOW karein. YouTube par subscribe aur FACEBOOK par bhi follow karein.

**Hashtags**
#KalKiRecording #HindiHorror #CCTVHorror #HorrorReels #AnimatedHorror

### Facebook Reels
**Title**
CCTV Mein Kal Dikh Raha Tha | Kal Ki Recording

**Description / caption**
Aman ki night shift mein CCTV ne woh dikhaya jo abhi hua hi nahi tha. Jab recording wali aurat building ke bahar pahunchi, usse samajh nahi aaya kis par yakeen kare.

Aap hote toh sabse pehle kya karte? Comment mein batayein.

Yeh ek kalpanik horror kahani hai.
FOLLOW karein; YouTube par subscribe aur INSTAGRAM par bhi follow karein.

**Hashtags**
#HindiHorror #KalKiRecording #ScaryStory #AnimatedHorror

---

## 2. Ek Floor Neeche

### YouTube Shorts
**Title**
Har Floor Par Flat 404? | Ek Floor Neeche | Hindi Horror

**Description**
Raat 2:13 baje delivery boy Kabir flat 404 ka order lekar pahuncha. Customer ka message aaya: “Ek floor neeche aa jao.” Lekin neeche bhi wahi number tha... 404.

Aap aisi delivery complete karte ya turant laut jaate?

Ek original fictional Hindi horror story, 2D animation ke saath.
Subscribe karein aur Facebook, Instagram pe follow karein.

**Hashtags**
#HindiHorror #DeliveryHorror #Flat404 #HorrorStory #Shorts

**YouTube tags — comma-separated**
ek floor neeche, flat 404, delivery boy horror story, Hindi horror story, horror story in Hindi, haunted building, endless stairs, night delivery horror, paranormal story, animated horror, 2D animation, suspense story, horror shorts, scary story

### Instagram Reels
**Cover title**
HAR FLOOR PAR 404?

**Caption**
“Bhaiya, ek floor neeche aa jao.” 📱
Woh neeche gaya. Flat number phir bhi 404 tha.

Aap kitni baar us message par yakeen karte?

Original fictional horror story.
Aisi aur kahaniyon ke liye FOLLOW karein. YouTube par subscribe aur FACEBOOK par bhi follow karein.

**Hashtags**
#EkFloorNeeche #Flat404 #HindiHorror #DeliveryHorror #HorrorReels

### Facebook Reels
**Title**
Ek Floor Neeche... Lekin Har Baar Wahi Flat 404

**Description / caption**
Ek late-night delivery. Flat 404. Aur customer ka baar-baar aata message: “Ek floor neeche.” Kabir ko laga bas ek aur manzil utarni hai.

Aapko kis pal lagta ki kuch galat hai?

Yeh ek kalpanik horror kahani hai.
FOLLOW karein; YouTube par subscribe aur INSTAGRAM par bhi follow karein.

**Hashtags**
#EkFloorNeeche #HindiHorror #HauntedBuilding #HorrorStory

---

## 3. Ginti Mat Karna

### YouTube Shorts
**Title**
7 Passengers, Paise 8 Ke? | Ginti Mat Karna | Hindi Horror

**Description**
Raat ki aakhri bus mein conductor Ravi ne 7 passengers gine. Lekin paise 8 logon ke aaye. Dobara ginne laga toh driver ne uska haath pakad liya: “Mod nikalne tak... ginti mat karna.”

Aap dobara ginte ya driver ki baat maante?

Ek original fictional Hindi horror story, 2D animation ke saath.
Subscribe karein aur Facebook, Instagram pe follow karein.

**Hashtags**
#HindiHorror #BusHorror #GintiMatKarna #HorrorStory #Shorts

**YouTube tags — comma-separated**
ginti mat karna, bus horror story, Hindi horror story, horror story in Hindi, last bus horror, night bus story, conductor horror, haunted bus, mysterious passengers, paranormal story, animated horror, 2D animation, suspense story, horror shorts

### Instagram Reels
**Cover title**
8VA PASSENGER KAUN?

**Caption**
Passengers 7. Paise 8 ke. 🚌
Aur driver ki sirf ek warning—“Ginti mat karna.”

Aap warning maante ya sach jaanne ke liye dobara ginte?

Original fictional horror story.
Aisi aur kahaniyon ke liye FOLLOW karein. YouTube par subscribe aur FACEBOOK par bhi follow karein.

**Hashtags**
#GintiMatKarna #BusHorror #HindiHorror #HorrorReels #AnimatedHorror

### Facebook Reels
**Title**
Raat Ki Aakhri Bus Mein Ginti Mat Karna

**Description / caption**
Conductor Ravi ke hisaab se bus mein 7 passengers the. Paise 8 logon ke kaise aaye? Driver jawab dene ke bajaye usse dobara ginne se rok raha tha.

Aapke liye zyada darr ki baat kya hoti—galat ginti ya driver ki warning?

Yeh ek kalpanik horror kahani hai.
FOLLOW karein; YouTube par subscribe aur INSTAGRAM par bhi follow karein.

**Hashtags**
#GintiMatKarna #HindiHorror #BusHorror #ScaryStory

---

## 4. Seat 18 A

### YouTube Shorts
**Title**
Papa Ki Flight 10 Saal Baad? | Seat 18 A | Hindi Horror

**Description**
Papa ki aakhri flight kabhi land nahi hui. 10 saal baad airport par usi flight ka boarding announcement suna. Gate par jo dikha, uske liye main taiyaar nahi tha.

Aap us gate ki taraf jaate?

Seat 18 A—ek original fictional Hindi horror story, 60 seconds ki 2D animation mein.
Subscribe karein aur Facebook, Instagram pe follow karein.

**Hashtags**
#Seat18A #AirportHorror #HindiHorror #HorrorStory #Shorts

**YouTube tags — comma-separated**
seat 18 A, seat 18A horror, airport horror story, flight horror story, Hindi horror story, horror story in Hindi, mysterious flight, boarding pass horror, father son story, emotional horror, paranormal story, animated horror, 2D animation, horror shorts

### Instagram Reels
**Cover title**
PAPA WAPAS AAYE?

**Caption**
Papa ki flight kabhi land nahi hui thi. ✈️
10 saal baad... usi flight ki boarding shuru ho gayi.

Agar aap hote, gate ki taraf jaate ya wahin ruk jaate?

Seat 18 A | Original fictional horror story.
Aisi aur kahaniyon ke liye FOLLOW karein. YouTube par subscribe aur FACEBOOK par bhi follow karein.

**Hashtags**
#Seat18A #AirportHorror #HindiHorror #HorrorReels #AnimatedHorror

### Facebook Reels
**Title**
10 Saal Baad Papa Ki Flight Ka Announcement | Seat 18 A

**Description / caption**
Jis flight ka intezaar 10 saal pehle khatam ho chuka tha, aaj usi ki boarding announce hui. Ek beta phir se apne papa ko dekhne ki umeed mein gate tak pahuncha.

Umeed aur darr ek saath ho, toh aap kya karte?

Yeh ek kalpanik airport horror kahani hai.
FOLLOW karein; YouTube par subscribe aur INSTAGRAM par bhi follow karein.

**Hashtags**
#Seat18A #AirportHorror #HindiHorror #EmotionalHorror

---

## 5. Aakhri Diya

### YouTube Shorts
**Title**
Diwali Par Yeh Diya Mat Bujhana | Aakhri Diya | Hindi Horror

**Description**
Maa har Diwali band kamre ke bahar ek diya jalati thi. Kehti thi, “Teri behen ko andhere se darr lagta hai.” Lekin meri behen 10 saal pehle mar chuki thi.

Is Diwali Maa nahi thi... aur maine woh diya bujha diya.

Aap hote toh Maa ki baat maante?

Ek original fictional Diwali horror story, 60 seconds ki 2D animation mein.
Subscribe karein aur Facebook, Instagram pe follow karein.

**Hashtags**
#DiwaliHorror #AakhriDiya #HindiHorror #HorrorStory #Shorts

**YouTube tags — comma-separated**
aakhri diya, Diwali horror story, Diwali horror, Hindi horror story, horror story in Hindi, diya horror story, haunted room, family secret horror, shadow horror, supernatural story, animated horror, 2D animation, suspense story, horror shorts

### Instagram Reels
**Cover title**
YEH DIYA MAT BUJHANA

**Caption**
Saare diye bujha dena... bas EK chhodkar. 🪔
Maa ki baat na maanne ki keemat kya ho sakti hai?

Aap woh diya jalta rehne dete?

Aakhri Diya | Original fictional Diwali horror story.
Aisi aur kahaniyon ke liye FOLLOW karein. YouTube par subscribe aur FACEBOOK par bhi follow karein.

**Hashtags**
#AakhriDiya #DiwaliHorror #HindiHorror #HorrorReels #AnimatedHorror

### Facebook Reels
**Title**
Maa Ne Kaha Tha—Diwali Par Yeh Diya Mat Bujhana

**Description / caption**
Har Diwali ek band kamre ke bahar diya jalta tha. Maa kehti thi ki Rohan ki behen ko andhere se darr lagta hai. Magar uski behen ko guzre 10 saal ho chuke the.

Is baar Rohan ne diya bujha diya.

Aapke hisaab se Maa usse kya chhupa rahi thi?

Yeh ek kalpanik Diwali horror kahani hai.
FOLLOW karein; YouTube par subscribe aur INSTAGRAM par bhi follow karein.

**Hashtags**
#AakhriDiya #DiwaliHorror #HindiHorror #ScaryStory
