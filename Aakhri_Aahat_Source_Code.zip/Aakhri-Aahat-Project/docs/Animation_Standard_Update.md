# Animation standard — user preference update

Confirmed 7 November 2026 for future Aakhri Aahat projects.

Aim for more professional, polished, expressive and atmospheric 2D animation that leaves a memorable impression.

- Characters visibly perform actions: grounded walking, turning, reaching, grasping and releasing objects.
- Use expressive eyes, facial acting, breathing, hesitation, recoil and posture changes.
- Keep character identities and cartoon style consistent across shots and thumbnails.
- Add coherent depth, moving shadows, subtle mist and motivated lighting changes.
- Use purposeful camera movement and close-ups to reveal clues.
- Synchronize footsteps, doors, clothing and object sounds with visible actions; keep narration clear.
- Build toward one distinctive visual reveal or final unsettling image per story.
- Preserve clean, normally capitalized subtitles without highlights.
- Black/crimson/off-white remain the thumbnail signature; scene lighting and colors should suit each story.
- Actual action inside the scene is essential; camera zooms over still images are not sufficient.
- No channel name or logo anywhere in video frames. CTA remains separate from the story production workflow.

Use alongside Aakhri_Aahat_Detailed_Animation_Workflow_v2.md. This is a future production standard, not a claim that prior exports meet every criterion.
