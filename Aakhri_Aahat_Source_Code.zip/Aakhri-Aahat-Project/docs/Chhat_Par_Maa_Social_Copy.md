# Chhat Par Maa — posting copy

## YouTube Shorts

Title: Maa Hospital Mein Thi… Toh Neeche Kaun Tha? | Hindi Horror #Shorts

Description:
Raat ko Aarav chhat par kapde lene gaya. Neeche se maa ki awaaz aayi—phir usi maa ka phone aa gaya.

Ek kalpanik Hindi horror kahaani, 2D animation aur alag character voices ke saath.

SUBSCRIBE KAREIN AUR INSTAGRAM AUR FACEBOOK PE FOLLOW KAREIN!

#HindiHorror #HorrorShorts #ChhatParMaa #AnimatedHorror #Shorts

Pinned comment: Tum Aarav ki jagah hote, toh phone waali maa par bharosa karte ya neeche se aati awaaz par?

## Instagram Reels

Caption:
Maa hospital mein thi… phir neeche se kaun bula raha tha? 🔴
Aur jab Aarav ne dobara chhat ki taraf dekha, rassi khaali thi.

Tum kis awaaz par bharosa karte? 👇

SUBSCRIBE KAREIN AUR INSTAGRAM AUR FACEBOOK PE FOLLOW KAREIN! LINK IN BIO.

Kalpanik horror kahaani.
#HindiHorror #HorrorReels #AnimatedHorror #ChhatParMaa #ScaryStories

Use LINK IN BIO only after adding the relevant link to the profile.

## Facebook Reels

Title: Chhat Par Maa | Neeche Kaun Bula Raha Tha?

Caption:
Raat ki chhat. Hawa bilkul band. Sirf laal saari hil rahi thi.
Tabhi maa ka phone aaya: “Main hospital mein hoon.”

Aarav ko kiski baat sunni chahiye thi? Apna jawab comments mein likhiye.

SUBSCRIBE KAREIN AUR INSTAGRAM AUR FACEBOOK PE FOLLOW KAREIN!

Yeh ek kalpanik animated horror kahaani hai.
#HindiHorror #HorrorStory #AnimatedHorror #ChhatParMaa
