# AAKHRI AAHAT — DETAILED PRODUCTION & ANIMATION WORKFLOW

**Version:** 2.0 (expanded from v1.1)  
**Updated:** 5 November 2026  
**Project name:** Aakhri Aahat — **internal documentation and publishing only**  
**Format:** Original Hindi/Hinglish 2D cartoon horror shorts (YouTube Shorts, Instagram Reels, Facebook Reels)  
**Scope:** Story, art direction, characters, visual storytelling, *actual moving animation*, camera, effects, sound, thumbnails, 4K export, asset management, verification.  
**Intentionally excluded:** All calls-to-action: copy, end-card design, speech, motion, and production.

> **Creative standard:** The output should feel like a deliberately directed, professionally animated *short horror film*, **not** a slideshow of static pictures with zoom/pan transitions. A shot succeeds because the characters and world visibly act and react, not merely because the camera moves.

## 0. Decisions already agreed vs. technical recommendations

**Confirmed project decisions:** Original horror stories; clean and consistent flat 2D cartoon look; dark cinematic atmosphere; 60–90 s target; 9:16; 4K vertical target where genuinely supported; characters identical across scenes and thumbnails; purposeful walking, body-weight shifts, arm swings, head turns, blinking, breathing, eyelines, expressions, trembling/recoil, hand/object interactions, mouth movement/lip-sync where applicable; moving environments and camera; synchronized location-specific SFX; strong story hook and ending; 9:16 story-matched cartoon thumbnails; no in-video branding; separate drafts/tests from approved files.

**New implementation recommendations in this v2.0:** Suggested animation timing, character-rig organization, frame-rate options, concrete camera movement recipes, QA pass/fail criteria and production templates. These are guidance, not claims that all older videos already implement them.

---

## 1. Non-negotiable creative and technical rules

| Area | Standard |
|---|---|
| Style | Original, professional **flat/stylized 2D cartoon motion animation**; cinematic horror framing |
| Runtime | Usually **60–90 seconds**; no padding to reach a number |
| Screen | **Vertical 9:16**, composed for phone viewing |
| Export target | **2160 × 3840** vertical 4K, provided source materials and tools justify it |
| Audio/language | Hindi or natural Hinglish; expressive narration/dialogue; clear SFX and ambience |
| Motion | **Visible character acting plus physical and environmental movement** whenever the story calls for it |
| Continuity | One locked visual identity per character across *every* shot and the matching thumbnail |
| Branding in video | **ABSOLUTELY NO “Aakhri Aahat,” other channel name, brand logo, watermark, branded title, brand overlay or substitute branding anywhere within a video frame** |
| Thumbnail | Use the *actual story’s* character design; 9:16; black/crimson/off-white base; readable short hook; no channel branding |
| Ownership | Original artwork and stories; no direct copying of protected character designs |
| CTA | **Out of scope for this guide; do not insert one into this workflow or its templates** |

**Brand-free frame inspection:** Check the first frame, every scene, environmental signs/phone screens/posters, any title card, and the very last frame. Internal filenames, project documentation and platform metadata may contain the project name; **video pixels may not**.

## 2. Story structure and retention

Build the film around **one clear mystery** that escalates visibly. Use narration to advance meaning, and animation to make key facts *seen* rather than merely described.

| Approximate position in story | Purpose | Visual directive |
|---|---|---|
| **0–3 s** | Hook / impossible detail | Show motion immediately: disturbing object, character reaction, anomalous movement, unusual framing |
| **3–15 s** | Who/where/why it matters | Establish location and character with purposeful acting and 1–2 readable visual cues |
| **15–35 s** | Rising suspicion | A character notices, checks, approaches, calls, walks or manipulates evidence |
| **35–55 s** | Pressure and consequence | Faster decisions, stronger body reactions; contrast active movement with motivated stillness |
| **55–80 s** | Reveal/reversal | Clear visual proof; control camera, edit rhythm and sound so the audience understands it |
| **Last story beat** | After-effect | Leave a memorable image or implication; avoid rushing away before viewers register it |

These beats scale to the actual 60–90-second running time. Avoid long introductory logos, exposition-only static scenes, repeated shots and visual information unrelated to the mystery.

**Script-to-visual rule:** Every narration sentence should map to a shot that *shows an event, clue, decision, change or reaction*. If the frame can be removed without losing story information or emotion, revise it.

---

## 3. Art direction: what the video should actually look like

### 3.1 Style lock

- **2D cartoon figures**, readable silhouettes, consistent line thickness and restrained clean shading.
- Dark cinematic mood through **lighting, negative space, focal contrast, silhouettes and composition**; never make essential action too dark to read on a phone.
- Keep background drawing style, character outlines, texture and shadow softness compatible; avoid inserting photorealistic rooms behind flat cartoon people without intentional stylization.
- Black/crimson/off-white are the **thumbnail design language**, not a rule that every story location must be permanently red and black. Choose story-specific scene colors while retaining coherent horror art direction.
- Make one source-of-truth **style board** with: 2–3 approved scene frames, color palette, line/shadow treatment, lighting examples, depth layers, and negative examples.
- Define source-light logic per scene (lamp, phone screen, hallway light, moonlight) and maintain its direction across shot reversals.

### 3.2 Shot composition in 9:16

- Put the main face/object large enough to understand on a mobile screen. Use close-ups for tiny props, phone messages, subtle emotions and scares.
- Use foreground/midground/background to create depth, but do not overfill the narrow canvas.
- Maintain a **clear focal hierarchy**: what should the viewer look at *first*, *second*, and *last*?
- Reserve space for any necessary subtitles; keep faces and critical props out of common app interface overlay zones. Verify in actual platform previews; safe areas vary by app and UI.
- Keep consistent eyelines, screen direction, camera axis, object position and doorway orientation across cuts.
- Avoid frequent sudden changes in framing scale with no story purpose.

### 3.3 Environment design

Prepare each location as a reusable **layered set**:

1. **Background:** far wall, sky, distant street, corridor end.
2. **Midground:** character plane, desk, chair, doors, lift, bus seats.
3. **Foreground:** doorframe, hanging wire, railing, passing shadow.
4. **Practical-light layer:** lamp, monitor, torch, signage glow.
5. **FX layer:** fog, dust, rain, drifting shadows, flicker, reflections.
6. **Occlusion/mattes:** correct hiding when character walks behind or in front of set pieces.

Create a location map showing where doors, windows, props, lights and characters stand. Reuse the same model and layout when returning to the room; do **not** regenerate a contradictory background for each angle.

### 3.4 Visual storytelling

- Show a **cause → reaction → consequence** sequence. Example: phone rings → character turns/hesitates → hand reaches for phone → receiver lifts → facial reaction.
- Prefer one strong supernatural anomaly per visual beat; build audience attention toward it.
- Reveal through staging: partial silhouette, reflection, door gap, delayed turn, then clear proof at the intended moment.
- Deliberate darkness and silence can build suspense, but they must be *motivated*, not cover for missing animation.

---

## 4. Character design: consistent identity in every frame

### 4.1 Character sheet required before production

Lock the following for each significant character:

| Property | Record precisely |
|---|---|
| Identity | Fictional character ID, narrative role, approximate age presentation |
| Head/face | Head shape, eye size/spacing, eyebrows, nose, ear, mouth shape, cheek/jaw contour |
| Hair | Hairline, silhouette, parting, length, colors, texture |
| Skin | Base tone and shadow/light variations |
| Body | Head-to-body proportion, torso shape, shoulder width, limb lengths, hands and feet |
| Outfit | Exact shirt/jacket color, collar, sleeves, buttons, shoes, accessories, wear marks |
| Props | Named items, which hand holds them, size relative to body |
| Style | Outline width, shadow approach, highlight approach, edge quality |
| Angles | Front, 3/4 left/right, profile left/right and back as needed |
| Expression library | Neutral, concerned, suspicious, fear, shock, dread, determination, speech shapes |

Include an **on-model turnaround** and **expressions sheet** before scene illustrations. Save a reference PNG/character-layer source with a character ID and approved version.

### 4.2 Absolute consistency rules

- One character must not change face shape, eye design, hair, skin color, nose, body build, clothing, shoes or accessory positions between shots unless the story explicitly causes the change.
- Lighting may change perceived color, but the underlying palette/identity stays locked.
- Do not change a character's apparent age or illustration style during a close-up or emotional moment.
- Right/left hand continuity, jewelry, watches, bags and objects must match across reverse angles.
- The thumbnail must show **that exact character** with the same drawing style—not a new interpretation of that character.
- Prefer **reusable rigged layered artwork** over re-generating a whole person independently for each shot. If frames are separately generated, compare each against the master sheet before acceptance.

### 4.3 Required layer/rig plan (recommended)

Keep manipulable parts separate when possible:

```text
Character_<ID>/
  Head/
    Face_Base
    Hair_Front / Hair_Back
    Left_Eye / Right_Eye / Eyelids / Pupils
    Eyebrows
    Mouth_Shapes
    Head_Shadow
  Torso / Neck / Pelvis
  Left_Upper_Arm / Left_Forearm / Left_Hand
  Right_Upper_Arm / Right_Forearm / Right_Hand
  Left_Thigh / Left_Shin / Left_Foot
  Right_Thigh / Right_Shin / Right_Foot
  Outfit_Details / Accessories
  Prop_Contacts / Contact_Shadows
```

Set pivot points at anatomically sensible joints; avoid arms swiveling from odd positions or floating hands. Turnaround angles may need redrawn art rather than rotating a flat face unnaturally.

---

## 5. ACTUAL moving character animation — mandatory execution standard

**Not enough:** a static drawing with a slow zoom, wiggle, fade, flashing filter or panning background.  
**Required:** when actions occur in the story, the character must **visibly perform the action** with believable preparation, motion, weight, and settling.

### 5.1 Four components of motion in each animated shot

1. **Character performance:** acting in face, eyes, head, torso, limbs and hands as needed.
2. **Object interaction:** a phone is grabbed, door handle rotates, light is switched, footsteps contact ground, clothing follows movement.
3. **Environment response:** chair shifts, shadow moves, dust reacts, door swings, monitor glows, lamp flickers if scripted.
4. **Camera choreography:** intentional push-in, tracking, pan, reveal or hold, complementing the actor.

Not every shot needs all four simultaneously. However **motion must not consist only of item 4** throughout the film.

### 5.2 Minimum animation actions by narrative situation

| Story action | What must visibly move | What to avoid |
|---|---|---|
| Walking | Alternating legs; foot placement/contact; hip/torso weight shift; arm counter-swing; head/body follow-through | Sliding a rigid body sideways while feet float |
| Stopping | Deceleration; foot plant; shoulders/torso settle | Instant freeze with no weight |
| Looking toward a noise | Eye direction first or coordinated eye/head turn; posture shift | Moving only the camera toward the noise |
| Fear/reaction | Brows, eyelids, pupils, mouth, shoulders, breathing, recoil/lean/tremble chosen to fit moment | A facial sticker swapping expression while body remains rigid |
| Talking | Timed mouth shapes coordinated to audible speech; eye focus, subtle head/gesture changes | Repetitive open/closed mouth unrelated to syllables |
| Taking a phone | Arm reach → hand approach → finger/grip contact → phone lift → wrist/elbow adjustments | Phone teleporting into hand |
| Opening a door | Reach → hand on handle → handle turn → door arc → body passes through → shadow/lighting updates | Door simply cuts to open |
| Sitting/rising | Hips and knees move, feet bear weight, body lowers/rises, seat/cloth settles | Body pops between two positions |
| Turning around | Eyes/head lead; shoulders, torso and hips follow; foot pivot when needed | A flat cut-out abruptly flips |
| Trembling | Small irregular limb/shoulder motion with maintained pose; restrained facial micro-motion | Global screen shake replacing character acting |
| Shadow/entity movement | Direction, spatial source, silhouette change and interaction with set | Random spooky effect with no spatial logic |

### 5.3 Performance progression

For a meaningful action, animate four phases:

**Anticipation → Action → Follow-through → Settle/Reaction**

Example: character answers a ringing telephone:

- Anticipation: eyes flick to receiver; face tightens; torso leans slightly.
- Action: shoulder rotates; forearm extends; fingers contact receiver; receiver lifts from cradle.
- Follow-through: wrist reorients; head tilts as receiver reaches ear; cord reacts where present.
- Reaction: eyelids/brows change; breathing or hand tension responds to unheard voice.

For a fright: **perceive → register → recoil/freeze → choose action**, with a micro-pause to let the audience read fear.

### 5.4 Idle animation while someone is on screen

Use subtle, organic movement so a long-held shot is not dead:

- Small chest/shoulder breathing motion.
- Natural blinking (not identical intervals for every character).
- Minor eye search or gaze stabilization.
- Small head/neck adjustments and posture shifts.
- Hair, sleeves or accessories moving *only when physically justified*.

Avoid constant bobbing, exaggerated blinking and random body movement; scared characters may deliberately hold still. **Motivated stillness** is allowed, but only after a clear action/reaction and for a narrative purpose.

### 5.5 Walking-cycle quality gate

Before accepting a walking shot, check these tests:

- Both feet alternately support body weight; planted foot does not slide unnaturally.
- Knees bend and ankles/feet orient correctly on contact and passing poses.
- The body's center of gravity changes; torso is not rigidly carried across screen.
- Arms counter-swing naturally, modified when carrying a bag/phone/light.
- Character moves through **the same floor perspective** as the background and casts consistent contact shadow.
- Walk speed matches traveled screen distance and audible footsteps.
- Character accelerates and decelerates sensibly around turns or stops.

### 5.6 Lip-sync and dialogue

- Where a **visible character is speaking**, animate mouth shapes linked to timing of the actual voice track; use an appropriate phoneme/viseme set rather than one repeated open-close cycle.
- Emotional speaking affects brows, eyes, cheeks, head angle and gesture timing.
- When the voice is **off-screen narration**, do **not** falsely lip-sync a silent character; animate listening, acting and reactions instead.
- When a voice comes from a phone or another room, clarify source by framing, prop motion and sound treatment.
- Pause mouth movement when the words stop.

### 5.7 Motion timing and spacing (recommended, not historical fixed settings)

- Establish **one timeline frame rate**, e.g. 24 or 30 fps, and keep animation and export consistent. Choose based on production needs, not arbitrary upconversion.
- Animate pose-to-pose with clear key poses and in-betweens; use easing for believable acceleration/settling.
- Let rapid startled actions be snappier than slow investigative moves; vary rhythm intentionally.
- Avoid uniform mechanical interpolation on every body part; offset head, shoulders, hands and secondary motion as appropriate.
- An intentionally held reaction can be stronger than a nonstop animation loop, provided it is staged and timed.
- Check for frame-to-frame shape drift, jitter, popping lines or facial identity changes.

---

## 6. Camera animation and cinematic movement

A moving camera helps tell the story, but **does not substitute for character acting**.

| Move | Use for | Practical execution |
|---|---|---|
| Slow push-in | Suspicion, realization, internal fear | Gently approach subject with stable perspective; end on readable expression/clue |
| Pan/reframe | Character follows noise or notices object | Lead gaze; reveal target after a beat |
| Lateral track | Walking down hallway, approach to door | Match character speed; shift depth layers consistently |
| Parallax move | Enhance scene depth | Foreground moves more than background; retain spatial integrity |
| Tilt | Reveal unusual height/position | Use sparingly and motivate by character eyeline |
| Locked shot | Suspense, something moves *within* composition | Character/background must carry the visual beat |
| Fast impact/recoil | Sudden scare | Brief intentional displacement if justified; avoid random shake |
| Reveal via occlusion | Hide/reveal entity or clue | Move camera or actor behind doorframe/post with correct matte layering |

**Camera QC:** No unexplained scale pumps; no warped geometry; no accidental crop of face/object; no simultaneous exaggerated camera shake and chaotic character motion; never lose the audience's sense of where the character is.

## 7. Environment / background animation

The location is not a motionless wallpaper. Animate only elements supported by the scene:

- **Office:** fluorescent flicker, rotating fan, subtle monitor pulse, chair roll, phone cord, blind movement, paper disturbance.
- **Hallway/lift:** light dropouts, indicator changes, doors opening/closing on hinges/rails, floor reflections, cast shadows.
- **Street/rain:** rain layers at different depths, puddle impact, passing headlights, occasional wind movement.
- **Night bus:** window scenery drifting with vehicle speed, subtle body suspension, seat vibration, road light sweeps.
- **Haunted room:** shadow passage, moving curtain, door handle motion, slight dust in light beam, object vibration linked to event.

**Physics/continuity:** Flicker affects the objects it illuminates; moving door changes shadows/occlusion; moving character casts a corresponding contact shadow; rain and other particles obey the selected view's depth and direction. Never let ambience obscure the clue or character expression.

---

## 8. Shot design and scene visualization — detailed procedure

Create a shot card **before** illustrating or animating. Every shot must specify:

```markdown
SHOT ID:
Scene / story beat:
Time range (start-end) / target duration:
Narration/dialogue exactly as approved:
What the viewer must understand:
Location + reference background:
Characters + locked asset IDs:
Shot size / camera angle / 9:16 focal point:
Foreground / midground / background arrangement:
Lighting sources, direction, color and shadow:
Initial character pose and eye-line:
ACTUAL CHARACTER ACTION: (what physically moves, in order)
Object/prop interaction:
Environment movement and reactions:
Camera animation: (type, direction, when it begins/ends)
Key poses + approximate timeline:
Sound: VO, ambience, action SFX, horror cue, silence:
Exit frame / transition / next shot continuity:
Negative constraints: (no brand, no style drift, no slideshow, etc.)
Review result: APPROVED / REVISE / BLOCKED
```

### Example only: illustrated office telephone scare (not a claim about a final cut)

**Length: 6 seconds; 9:16; stylized office at night.** A fictional worker in a burgundy shirt is alone next to a desk phone and empty chair.

| Time | Character/prop acting | Camera / environment | Sound |
|---|---|---|---|
| 0.0–0.8 s | Fingers pause mid-task; eyes shift to phone | Static medium shot; monitor glows | First phone ring over office hum |
| 0.8–1.7 s | Head turns; shoulders follow; character leans | Gentle push-in begins | Second ring; small chair creak |
| 1.7–3.0 s | Arm extends, hand grips receiver; receiver visibly leaves cradle | Camera holds action readable | Pick-up click; ring stops exactly on lift |
| 3.0–4.2 s | Hand moves receiver to ear; jaw tightens; breath catches | Small highlight from monitor changes on face | Faint line hiss or whisper |
| 4.2–5.2 s | Eyebrows rise, eyelids open, hand tightens; torso recoils slightly | Push-in ends on expressive close framing | Controlled low stinger, then reduced ambience |
| 5.2–6.0 s | Eyes dart toward empty chair; body freezes *after* reaction | Cut/reframe toward chair as next scene begins | Chair movement cue timed with reveal |

**Why this works:** five seconds contain *causal, staged movement* rather than six seconds of a still illustration with a zoom. Every action has eye direction, pose change, physical contact and timed audio.

### Example negative constraints for scene-creation prompts

> Same on-model character throughout; no random costume/face changes; no photorealistic character replacements; no cut-out sliding in place of walking; no frozen figures with camera-only zoom; no morphing hands or missing fingers; no teleporting props; no inconsistent door/window layout; no unmotivated shake or repetitive idle loop; no brand text, logos or watermark anywhere in the frame.

---

## 9. Production pipeline with approval gates

| Stage | Concrete deliverable | Gate before proceeding |
|---|---|---|
| 1. Original premise | One-sentence hook, mystery, reveal | Understandable and distinctive |
| 2. Script | Time-coded narration/dialogue, visible beats | 60–90 s target; hook/reveal work |
| 3. Art bible | Style board, scene palette, set layout | 2D cartoon visual language approved |
| 4. Character lock | Turnaround, expression sheet, outfit and props | Each character has stable asset ID |
| 5. Shot list | Timings, framing, action, movement, SFX | Every shot has a story purpose |
| 6. Animatic | Rough timed storyboard and scratch audio | Pacing and continuity verified |
| 7. Layered art | Rig-ready characters, props, 3D-like depth layers in 2D | Shapes, proportions, masks checked |
| 8. Blocking | Main action poses, staging, camera paths | **There is visible character acting** |
| 9. Animation polish | In-betweens, blinks, gestures, lip-sync, secondary motion | No sliding, floating or morphing |
| 10. Environment/FX | Light behavior, shadows, parallax, moving objects | Physical continuity and legibility |
| 11. Voice and sound | Narration, sync SFX, layered room tone, suspense | Effects strike on actual animation events |
| 12. Edit and finish | Completed story cut, transitions, grade, optional subtitles | Hook/reveal and mobile readability |
| 13. QC | Frame/shot review plus watch-through | Brand-free, consistent, no technical faults |
| 14. Verified export | MP4, measured dimensions/FPS/duration/audio | File actually opens and has target specs |
| 15. Thumbnail and package | Character-matched cover, post copy, final folder | Correctly named approved assets |
| 16. Publish / learn | Verified links and platform analytics if available | Never label a file published without evidence |

**Review two cuts:** (a) a **muted picture-only watch**—can the viewer tell what physical actions occur? (b) an **eyes-closed audio listen**—are scene events and tension understandable? Then check their synchronization together.

## 10. Sound design tied to physical animation

- Preferred narration tone from prior discussion: **Viraj — deep, suspenseful, mysterious**, when that voice is available and appropriate. Avoid treating this as proof any recorded master uses it.
- Character actions need **location-specific, on-frame SFX**: shoe contacts, door latch, metal rail, receiver pickup, glass, paper, cloth, keys, lift motors, bus vibration.
- Layer steady ambience beneath: office fan, distant traffic, HVAC, night insects, hum, rain, room-tone decay.
- Use deliberate silence/reduced ambience around a reveal; do not fill every gap with noise.
- Build horror through proximity, sudden absence of background sound, subtle whispers or restrained stingers—not constant high-volume jumps.
- Duck music/SFX enough for narration intelligibility. Verify on phone speakers and headphones.
- Confirm sound exactly matches **the visible contact point** (foot lands, hand lifts receiver, door clicks shut).
- If a shot or sample was intentionally produced silent, **preserve that silence**; do not invent sound merely to fill a track.

### Audio-to-action cue sheet

```markdown
Shot ID | Timecode | Visual contact/action | Cue name | Sound source distance |
Cue starts | Cue peaks / action frame | Cue ends | Voice overlap? | QC result
```

## 11. Subtitles and on-screen story information

- Add captions **only when required by the agreed film specification**; do not assume every project needs them.
- Use natural Hindi/Hinglish aligned to spoken words; verify spelling and display duration.
- Keep text in safe viewing areas and avoid covering expressions, clues, props or faces.
- Diegetic story text (messages, clocks, room numbers, warnings) must be readable long enough to register; animate the *interaction* around it rather than relying on long text screens.
- No in-video channel branding of any kind, including text hidden in scene props.

## 12. Thumbnail rules — preserve the approved direction

- Format: **9:16**, designed for YouTube Shorts/Instagram/Facebook previews.
- Use **the actual story protagonist or figure**, matching on-model face, hair, clothes, proportions, outline and shading.
- Approved reference direction: **Attendance — “OFFICE MEIN KAUN?”** with Nikhil in a burgundy shirt and lanyard, phone in hand, frightened next to an empty office chair. **This references the approved style, not a default protagonist for other stories.**
- Use strong emotion, one story-specific clue/mystery prop, uncluttered composition, short bold hook.
- Main palette: black, crimson red and off-white, with high mobile-size readability.
- Keep face and hook centrally crop-safe; examine actual platform preview crops.
- **No brand name, logo, subtitles, or promotional overlays on thumbnails.**
- Do not use image designs that falsely promise an event absent from the video.

## 13. 4K export and file verification

| Setting | Recommended target |
|---|---|
| Aspect | Vertical 9:16 |
| Master resolution | **2160 × 3840** when practical from appropriately detailed sources |
| Alternative | 1080 × 1920 vertical when 4K is not genuinely supportable |
| Timeline / export FPS | Match chosen working rate (commonly 24/25/30 fps); keep it consistent |
| Delivery container | MP4 |
| Codec | H.264 or H.265 if editor/platform support is confirmed |
| Audio | AAC stereo, intelligible, no clipping |
| Length | Normally 60–90 s, unless story needs otherwise |

- Don't call an upscaled low-resolution slideshow a polished 4K animation. Export dimensions alone do not prove visual detail or character motion.
- Inspect using media metadata: **width, height, frame rate, duration, audio presence**, and visually watch the entire file.
- Inspect first/last frames for branding, glitch, unfinished black frame or an abrupt story cut.
- Scrub frame-by-frame around character face/hand/prop transitions, action beats, lighting flashes, subtitle start/end and scare cuts.
- Check for stutter, visual artifacts, flickering line work, wobbling eyes and morphing character identity.

## 14. Strict pass/fail visual & motion quality checklist

### Design
- [ ] Art style is consistently flat/stylized 2D cartoon (no accidental switch to photorealism).
- [ ] Each location has clear layout, depth layers, logical light direction and readable focal point.
- [ ] Scary scenes stay legible on a mobile screen.
- [ ] Wardrobe, props and set geometry are continuous.

### Character
- [ ] Face, eyes, hair, silhouette, outfit and proportions match the approved character sheet.
- [ ] Both close-ups and distant shots depict the exact same person.
- [ ] Character match is retained in the thumbnail.
- [ ] Hands/limbs remain anatomically coherent and make proper contact with objects.

### Actual animation
- [ ] **Character visibly performs each scripted action** rather than being translated as a rigid cut-out.
- [ ] Walking includes foot contact, legs, weight transfer, arms and grounding shadows.
- [ ] Eye direction and head turns support perception and reaction.
- [ ] Fear and other emotions involve expression **and** posture/body behavior.
- [ ] Visible speech uses timed mouth shapes; off-screen narration does not create false lip movement.
- [ ] Reach/grasp/lift/release of props is physically and temporally continuous.
- [ ] Subtle idle animation is present when useful and restrained when stillness is intentional.
- [ ] Camera, background and secondary FX complement rather than replace subject motion.
- [ ] There is no looping pose, foot sliding, teleporting object, floating wrist, morphing face or sudden character scale drift.

### Cinematic visuals and sound
- [ ] Every shot has a focal point and communicates new information, emotion or suspense.
- [ ] Camera movements are motivated, controlled and consistent with the set.
- [ ] Shadows, practical light changes, reflections and parallax behave logically.
- [ ] Action SFX land on the corresponding motion; room tone/ambience matches the location.
- [ ] Narration is clear; any deliberate silence remains deliberate.
- [ ] The final reveal is visible, coherent and well-paced.

### Branding and exclusions
- [ ] **Zero “Aakhri Aahat” or other channel/brand text, marks, logos, or watermarks anywhere in video frames.**
- [ ] First, middle and final video frames all pass the no-branding inspection.
- [ ] No CTA material has been added to this documented workflow or its production prompts.

### Delivery
- [ ] Final MP4 plays fully and matches the promised resolution, orientation, FPS and duration.
- [ ] Source animations do not look like still slideshows even when the sound is muted.
- [ ] Thumbnail is on-model and truthful to the finished story.
- [ ] Only approved files are placed in the approved-unposted folder.
- [ ] Publication status is based on verified links, not assumptions.

**Release blocker:** If core character action is missing, if characters visibly change design, if any channel branding is found inside video, or if the supposed 4K file fails metadata/visual verification, **do not approve**. Revise and review again.

---

## 15. Project structure and packaging rules

```text
Aakhri_Aahat/
├── 01_Production/
│   └── <Story_ID>/
│       ├── 01_Script_And_Timing/
│       ├── 02_Art_Bible_And_Character_Locks/
│       ├── 03_Shot_Cards_And_Animatic/
│       ├── 04_Layered_Characters_And_Props/
│       ├── 05_Backgrounds_And_Depth_Layers/
│       ├── 06_Animation_Scenes/
│       ├── 07_Voice_Ambience_SFX/
│       ├── 08_Editing_Projects/
│       ├── 09_Drafts_Tests/
│       └── 10_QC_Reports/
├── 02_Unposted_Approved/
│   ├── <Story_ID>_4K_9x16_v01.mp4
│   ├── <Story_ID>_Thumbnail_9x16_v01.jpg
│   └── <Story_ID>_Publishing_Metadata.md
├── 03_Published/
│   └── <Story_ID>/
└── 04_Internal_Style_References/
    ├── Character_And_Visual_Style_Bible.md
    └── Thumbnail_Style_Guide.md
```

- Keep **test files and draft scenes outside** `02_Unposted_Approved`.
- Put only verified final master and matching thumbnail in that approved-unposted area.
- Keep editable source files, animation layers and character sheets in `01_Production` so future fixes do not require recreating characters.
- File version numbers must change when the final film/thumbnail changes; avoid accidental overwrites.
- Future project workflow should **package** approved video and thumbnail together, but storage automation is **not implied to be operational** merely because it is documented here. Verify the destination and actual file write.
- Brand name is permitted in **internal folder names** and publishing metadata, not embedded in video frames.

### Previously discussed unposted stories — verify real files

| Story | Video export checked | Animation QA checked | Matching thumbnail checked | Publication checked |
|---|---|---|---|---|
| Ek Floor Neeche | [ ] | [ ] | [ ] | [ ] |
| Seat 18 A | [ ] | [ ] | [ ] | [ ] |
| Aakhri Diya | [ ] | [ ] | [ ] | [ ] |
| Doosra Helmet | [ ] | [ ] | [ ] | [ ] |
| Attendance | [ ] | [ ] | [ ] | [ ] |

*These were reported in the earlier project discussion. Their current physical presence, exact animation quality, actual 4K export metadata and upload status are not independently established by this document.*

---

## 16. Reusable production prompt specification

Use this template to brief an animator or image/video-generation stage. **Do not treat one generated frame as a complete animated shot.**

```markdown
PROJECT: [internal name]
STORY: [fictional story title]
SHOT ID / TIME: [shot #, seconds]
FORMAT: 9:16 vertical, target 2160x3840 master
VISUAL STYLE: consistent professional flat 2D cartoon cinematic horror
CHARACTER LOCK: [approved ID and exact reference-sheet version]
CHARACTER APPEARANCE: [face, hair, skin, proportions, clothes, props]
LOCATION LOCK: [approved set ID, geometry, prop placement, time of day]
SCENE COMPOSITION: [wide/medium/close, angle, focal target, depth planes]
LIGHTING: [sources, direction, intensity, color, shadow behaviour]
FIRST POSE: [precise pose and eye-line]
ACTING / BODY MOTION: [step-by-step physical motion and key poses]
FACE / EYES / MOUTH: [emotion, blink, gaze, speech-related lip-sync]
PROP CONTACT: [when/where hands touch props and how props move]
ENVIRONMENT ANIMATION: [exact moving objects and physical reactions]
CAMERA ANIMATION: [movement type, timing, beginning/end frame]
SECONDARY MOTION: [clothes, hair, shadows, reflections where justified]
VOICE / SFX: [line timing and audible events tied to motion]
LAST POSE / NEXT SHOT: [matching continuity into next scene]
NEGATIVE CONSTRAINTS: no character drift, no rigid sliding, no slideshow,
 no morphing limbs, no prop teleportation, no mismatched light,
 no brand name/logo/watermark anywhere on screen
OUTPUT / CHECK: [layered animation clip, duration, FPS, approvals]
```

## 17. Reusable shot approval worksheet

```markdown
# Shot quality review — [Story ID / Shot ID]
- Script beat and intended emotion:
- Character sheet version:
- Background/set version:
- Timed shot duration:
- Acting key poses present? YES / NO
- Eyes/head/body/limbs move as required? YES / NO / NOT NEEDED
- Feet and prop contacts physically correct? YES / NO / NOT NEEDED
- Lip-sync correctly assigned? YES / NO / NOT NEEDED
- Environment reacts consistently? YES / NO / NOT NEEDED
- Camera motivated and readable? YES / NO
- Sound synchronized to actions? YES / NO
- Identity, outfit and props continuous? YES / NO
- Mobile visual legibility? YES / NO
- Any in-video brand/logo/watermark? YES (BLOCK) / NO
- Any slideshow-like camera-only sequence? YES (REVISE) / NO
- Result: APPROVE / REVISE / BLOCK
- Exact corrective actions:
```

## 18. Final project handoff record

```markdown
# STORY: [Title]
- Production stage: concept / animatic / animation / QC / approved-unposted / published
- Central hook and final reveal:
- Character lock IDs + approved sheets:
- Location/set design IDs:
- Shot list with durations:
- Motion/action review completion:
- Voice used (if any):
- SFX timing sheet:
- Master filename, measured pixel size, FPS and length:
- Picture-motion QA result:
- Branding-inspection result: ZERO in-video branding required
- Thumbnail filename + character match:
- Approved folder path:
- Publication URLs (only if verified):
- Main issue to fix in next film:
```

**Final production principle:** The signature look is **consistent 2D cartoon characters physically acting in a cinematic, reactive horror world**. The camera, lighting and sound amplify the acting; they must never conceal a lack of animation. **No channel branding in the video. No CTA instructions in this workflow.**
