# AAKHRI AAHAT — PRODUCTION WORKFLOW

**Version:** 1.1  
**Updated:** 5 November 2026  
**Project:** Aakhri Aahat  
**Scope:** Story development, animation, sound, thumbnails, 4K exports, file management and publishing.  
**Excluded:** End-screen calls to action and their scripting, design, voice, and animation.

> **Purpose:** Use this checklist for every new Aakhri Aahat horror reel to keep the storytelling, animation, visual identity, files and publishing assets consistent.

---

## 1. Core project settings

| Item | Approved direction |
|---|---|
| Internal project / channel name | **Aakhri Aahat** (for folders, internal records and platform publishing only) |
| In-video branding | **PROHIBITED:** Do not show “Aakhri Aahat”, any channel/brand name, logo or branded watermark anywhere in the video |
| Genre | Original Hindi horror / mystery / supernatural suspense |
| Target length | **60–90 seconds** |
| Platforms | YouTube Shorts, Instagram Reels, Facebook Reels |
| Orientation | **9:16 vertical** |
| Export goal | **4K vertical (2160 × 3840)** when the source assets and tools support it |
| Animation | Clean, professional **2D cartoon motion graphics** |
| Tone | Cinematic, atmospheric, mysterious, suspenseful |
| Spoken language | Hindi / natural Hinglish as appropriate to each script |
| Characters | Consistent face, hair, clothing, body proportions and drawing style within each film |
| Main thumbnail palette | Black, crimson red and off-white |
| Artwork | Original; do not copy copyrighted characters or reference designs directly |

### Non-negotiable: No brand name inside the video

- **Never display “Aakhri Aahat”** within the video, including opening frames, title cards, backgrounds, props, scene overlays, lower-thirds, corner watermarks, credits or end frames.
- **Never insert the project/channel logo** or any substitute branding within the video.
- Keep the story visually immersive and free of channel labels. The story title may appear only if needed for storytelling; it must not serve as channel branding.
- It is fine to use **Aakhri Aahat** for internal folder names, project documentation and platform account metadata. These are **not** on-screen video content.
- Before approval, watch the exported video end-to-end and check that no brand name or logo appears on any frame.
- This rule concerns **in-video branding**. It does not add any CTA instructions; CTA production is explicitly out of scope.

**Technical caveat:** 4K is the export target, not proof that any previously created file has true 4K resolution. Verify each file's properties before marking it complete.

## 2. Story and retention workflow

Each film should hold attention by making the viewer want the answer to one specific mystery.

### Suggested 60–90 second pacing

| Timing | What should happen | Quality requirement |
|---|---|---|
| **0–3 s** | Start with a strange image, statement, sound or impossible event | Immediate hook; avoid slow introductions |
| **3–15 s** | Introduce the character, location and problem | Viewers understand what is at stake |
| **15–35 s** | Escalate the mystery with visual evidence or an unsettling discovery | New information; no repetitive dialogue |
| **35–55 s** | Build tension through consequences, a choice or a false explanation | Strong momentum and clear causal logic |
| **55–80 s** | Deliver the main reveal or reversal | Surprise must still make sense |
| **Final story seconds** | Finish on a memorable image, sound or implication | Clear ending, optionally one chilling unanswered question |

*These are flexible guides. Adjust timing to the actual 60–90 second runtime rather than padding scenes.*

### Script checklist

- [ ] Premise is original and understandable in one sentence.
- [ ] Opening contains a hook in the first 3 seconds.
- [ ] Main character has a clear immediate goal or problem.
- [ ] Each scene adds suspense, information or a meaningful change.
- [ ] Dialogue/narration sounds natural when spoken aloud.
- [ ] Reveal follows from clues planted earlier.
- [ ] Final story beat lands without being rushed.
- [ ] Script fits the target runtime when read at an appropriate pace.

## 3. Character and visual consistency

Create a compact **character sheet** before scene production:

- Character name and narrative role.
- Age range / appearance (only fictional, story-relevant details).
- Face shape, hairstyle, facial hair (if any), skin tone and expression range.
- Clothing, accessories and distinct props.
- Body proportions, outline thickness, shading and color palette.
- Front, 3/4 and side views where needed.

**Per-scene rules:**

- Keep the same character identity, outfit and proportions unless the script requires a change.
- Preserve continuity of objects, location layout, light direction and time of day.
- Prefer purposeful movement: camera push-ins, parallax, eye/head movement, hand gestures, moving shadows and environmental effects.
- Avoid accidental morphing, flicker, inconsistent anatomy, distorted hands and abrupt scale changes.
- Use dark cinematic lighting without hiding plot-critical details on a phone screen.

## 4. Scene-by-scene production pipeline

1. **Concept:** Write a one-line premise, central mystery and final reveal.
2. **Script:** Divide into timed narration/dialogue and scene beats.
3. **Storyboard:** Specify subject, composition, action, camera movement, lighting and transition for each shot.
4. **Asset plan:** List backgrounds, characters, facial expressions, props and effects required.
5. **Character lock:** Approve reference character designs before generating all scenes.
6. **Asset creation:** Produce original art matching the established 2D cartoon style.
7. **Animation:** Add controlled camera and character motion. Preserve continuity across cuts.
8. **Voice recording:** Capture clean, expressive narration and dialogue, paced to the storyboard.
9. **Sound design:** Add room tone, ambiance, location sounds, object sounds and restrained suspense cues.
10. **Edit:** Align shots, story, voice, subtitles (if used) and effects to the target runtime.
11. **Quality review:** Check story clarity, sound levels, text safe zones, character consistency, final reveal, and absence of in-video brand names/logos.
12. **Export:** Produce the platform-ready master and inspect the rendered file.
13. **Thumbnail:** Create or finalize a matching cover based on the *final* video appearance.
14. **Package:** Store the approved video and thumbnail together with publishing metadata.
15. **Publish:** Upload only after the asset checklist is complete; verify the platform post separately.

## 5. Sound and editing standards

- Voice must remain understandable above music and sound effects.
- Use location-appropriate ambiance (office hum, lift motor, night traffic, corridor reverb, footsteps, door movement, phone sounds, etc.).
- Place sound effects exactly on their visual action, not vaguely near it.
- Use silence and reduced music deliberately to increase suspense before a reveal.
- Avoid constant loud jump scares or distracting effects.
- Check that dialogue is not clipped and the exported mix plays well on phone speakers.
- Avoid dead air and unmotivated shots that weaken the 60–90 second pacing.

## 6. Approved thumbnail workflow

**Latest approved direction:** A **9:16 cartoon thumbnail that matches the actual video's character design**, superseding the earlier detailed graphic-novel approach.

### Design rules

- Use the protagonist or main figure from *that specific story*; do not reuse one default character for unrelated videos.
- Match the video’s hairstyle, clothing, face, proportions and flat 2D drawing treatment.
- Give the character a powerful, relevant expression (fear, shock, suspicion, alarm).
- Include one clear story-specific mystery element, such as a telephone, empty chair, room number or eerie silhouette.
- Use a black/crimson-red base with large, high-contrast off-white or red text.
- Keep the hook **short and bold**, ideally one compact question or mystery statement.
- Keep key text and the face inside the central crop-safe area for platform previews.
- Avoid clutter, long sentences, unrelated elements and misleading imagery.
- Do **not** include channel logos, subtitles or promotional overlays on the thumbnail.

### Approved visual reference

**Attendance — “OFFICE MEIN KAUN?”**: Nikhil in a burgundy shirt and lanyard, holding a telephone and looking frightened beside an empty office chair. This is the *style reference*, not a character template for other films.

### Thumbnail acceptance checks

- [ ] Actual video character and thumbnail character visibly match.
- [ ] Expression and mystery are understandable at mobile size.
- [ ] Hook reads clearly in a small preview.
- [ ] Subject and text are not clipped by common feed crops.
- [ ] Visual accurately represents the story.
- [ ] Final thumbnail exported and named alongside its video.

## 7. Video export and verification

### Target delivery profile

| Setting | Target |
|---|---|
| Orientation | 9:16 vertical |
| Preferred resolution | **2160 × 3840** (vertical 4K), if supported |
| Alternate working delivery | 1080 × 1920 vertical when 4K is impractical |
| Runtime | Usually 60–90 seconds |
| Container | MP4 as a broadly compatible delivery format |
| Video codec | H.264 or H.265 according to editor and platform requirements |
| Audio | AAC stereo, clean non-clipping mix |
| Frame rate | Match the production timeline; use one consistent frame rate |

**Before claiming a 4K export is ready:** inspect the actual file resolution, duration, frame rate, playback, audio, end frame, and file size. Simply enlarging low-resolution artwork does not make it genuinely detailed 4K content.

## 8. Project folders and file naming

Use one recognizable project folder with a **shared location for approved, unposted exports and their matching thumbnails**.

```text
Aakhri_Aahat/
├── 01_Production/
│   └── <Story_Name>/
│       ├── Script/
│       ├── Storyboard/
│       ├── Characters/
│       ├── Scenes/
│       ├── Voice_and_SFX/
│       └── Edit_Project/
├── 02_Unposted_Approved/
│   ├── <Story_Name>_4K_9x16.mp4
│   ├── <Story_Name>_Thumbnail_9x16.jpg
│   └── <Story_Name>_Publishing_Metadata.md
├── 03_Published/
│   └── <Story_Name>/
└── 04_Brand_References/
    └── Thumbnail_Style_Guide.md
```

### Save rules for every new project

- Only place **approved final exports** in `02_Unposted_Approved`.
- Keep each video's approved thumbnail next to the video; use matching story names.
- Keep test renders, drafts and experimental images in the story's production folder, **not** the approved unposted folder.
- After publishing, document publication details and move/copy files to `03_Published` according to the chosen archive policy.
- Do not overwrite a prior final without tracking the new version.
- **Important:** These are organization instructions, not evidence that a physical folder or an automated save mechanism exists. Saving files requires a connected destination or an explicit file operation in the working environment.

## 9. Reported unposted story checklist

The previous conversation listed five unposted projects for matching thumbnail and video packaging. Their actual exports, thumbnail files and 4K properties should be checked directly before treating them as verified.

| Story | Verify 4K video | Verify matching thumbnail | Confirm publishing status |
|---|---|---|---|
| Ek Floor Neeche | [ ] | [ ] | [ ] |
| Seat 18 A | [ ] | [ ] | [ ] |
| Aakhri Diya | [ ] | [ ] | [ ] |
| Doosra Helmet | [ ] | [ ] | [ ] |
| Attendance | [ ] | [ ] | [ ] |

## 10. Pre-publication quality-control checklist

### Story and creative
- [ ] Strong opening hook and clear suspense progression.
- [ ] Viewers can follow the story without confusing jumps.
- [ ] Reveal is logical, surprising and visually understandable.
- [ ] Duration is intentional; there is no padding.

### Visuals
- [ ] Character designs are consistent in every shot.
- [ ] No flicker, visual artifacts, malformed anatomy or contradictory props.
- [ ] Framing works in vertical format on mobile.
- [ ] **No “Aakhri Aahat” brand name, other channel name, logo or watermark appears anywhere in the video** (including the beginning and final frame).
- [ ] Text/captions, if used, remain readable and in safe zones.

### Audio
- [ ] Speech is clean and intelligible.
- [ ] Sound cues align with actions.
- [ ] Music/ambience supports rather than masks the story.
- [ ] No clipping, abrupt sound cuts or accidental silence.

### Delivery and packaging
- [ ] Final MP4 opens, plays all the way through and has the intended resolution.
- [ ] Thumbnail uses actual video character design and a bold story hook.
- [ ] Approved video and matching thumbnail are saved together.
- [ ] Title, description/caption, hashtags and tags are prepared per platform.
- [ ] Tests and drafts remain outside the approved unposted folder.
- [ ] Upload URL and publication time are recorded **only after verification**.

## 11. Publishing and performance feedback loop

1. Prepare platform-specific title, caption/description and relevant hashtags/tags without revealing the final twist unnecessarily.
2. Confirm the uploaded video has correct orientation, audio, captions (if used) and cover crop.
3. Record actual post URLs and dates rather than assuming a completed export was published.
4. Review early audience retention (especially first 3 seconds), average watch time, completion rate and comments when the platforms provide those metrics.
5. For the next project, improve the weakest point: hook, pacing, story comprehension, visual polish or audio clarity.

---

## 12. Reusable project record

Copy this block for each new story:

```markdown
# STORY: <Title>

- Stage: Concept / Script / Production / Review / Approved-Unposted / Published
- Core mystery:
- First-3-second hook:
- Main character / design reference:
- Target runtime:
- Scene list + timestamps:
- Key audio cues:
- Final reveal:
- Final video filename:
- Resolution / FPS / duration verified:
- Thumbnail hook text:
- Thumbnail filename:
- Creative approval date:
- Approved folder location:
- YouTube link (if actually published):
- Instagram link (if actually published):
- Facebook link (if actually published):
- Main improvement for next story:
```

**Guiding principle:** Each reel produced for the Aakhri Aahat project should feel like a compact, original horror film—with a gripping hook, coherent build-up, distinctive reveal, consistent cartoon visuals and a thumbnail that genuinely reflects the finished video.
