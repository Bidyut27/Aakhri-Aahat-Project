# Aakhri Aahat — approved thumbnail preference

User approved the revised Attendance thumbnail (OFFICE MEIN KAUN?) as the default direction for future videos.

- Use vertical 9:16 thumbnails for YouTube, Instagram and Facebook.
- Match the actual video's flat 2D cartoon character designs: face, hair, clothing, proportions and drawing style. Use video frames as references.
- Keep black and crimson red as the main palette, with readable off-white/red hook text.
- Show a strong facial expression and a story-specific object or mystery in a clear, uncluttered composition.
- Use a short, bold hook; keep important content within crop-safe central space.
- Do not add Aakhri Aahat branding, subtitles, or subscribe/follow CTA to thumbnails.
- This approved cartoon direction supersedes the earlier detailed graphic-novel thumbnail style.

Attendance reference: Nikhil in burgundy shirt and lanyard holding a telephone, frightened beside an empty office chair; text OFFICE MEIN KAUN?. Future stories use their own characters and settings, not Nikhil by default.
