# Chhat Par Maa — script

Original fictional horror story. Runtime: 74 seconds.

0.4s — narrator

रात को आरव छत पर कपड़े लेने गया।

Raat ko Aarav chhat par kapde lene gaya.

5.5s — below

बेटा, मेरी लाल साड़ी भी ले आना।

Beta, meri laal saari bhi le aana.

11.2s — narrator

हवा बिल्कुल बंद थी। फिर भी लाल साड़ी हिल रही थी।

Hawa bilkul band thi. Phir bhi laal saari hil rahi thi.

18.5s — narrator

वह हाथ बढ़ाने ही वाला था, कि माँ का फ़ोन आया।

Woh haath badhaane hi waala tha, ki maa ka phone aaya.

24.3s — phone

मैं अस्पताल में हूँ। पापा के पास आज रात रुकूँगी। दरवाज़ा अंदर से बंद कर लेना।

Main hospital mein hoon. Papa ke paas aaj raat rukoongi. Darwaaza andar se band kar lena.

34.5s — narrator

आरव ने सीढ़ियों की तरफ देखा।

Aarav ne seedhiyon ki taraf dekha.

39.0s — below

बेटा, फ़ोन वाली की बात मत सुनना।

Beta... phone waali ki baat mat sunna.

44.0s — narrator

उसने झट से छत का दरवाज़ा बंद कर दिया।

Usne jhat se chhat ka darwaaza band kar diya.

49.5s — phone

लाल साड़ी उतारी तो नहीं?

Laal saari utaari toh nahi?

54.0s — narrator

आरव मुड़ा। रस्सी खाली थी।

Aarav muda. Rassi khaali thi.

59.5s — narrator

उसके पीछे गीले पैरों की आहट आई।

Uske peechhe geele pairon ki aahat aayi.

66.5s — presence

मैं खुद उतर आई।

Main khud utar aayi.

