from pathlib import Path
from PIL import Image,ImageDraw
import subprocess, math
R=Path(__file__).parent
im=Image.open('generated_images/exec-d1c83544-8031-4ade-acba-1c13aaec7a68.png').convert('RGB').resize((1080,1920),Image.Resampling.LANCZOS)
# Animate groups over their original positions; the approved typography stays intact.
groups=[(120,475,.12),(485,700,1.35),(710,1045,2.15),(1050,1530,3.15),(1560,1740,4.65)]
def frame(t):
 out=im.copy()
 for y1,y2,start in groups:
  a=max(0,min(1,(t-start)/.38));a=a*a*(3-2*a)
  if a<1:
   band=im.crop((70,y1,960,y2));dark=Image.new('RGB',band.size,'#070709')
   out.paste(Image.blend(dark,band,a),(70,y1))
 # A discreet moving glint on the existing lower badge border after its reveal.
 if 5.1<t<6.1:
  d=ImageDraw.Draw(out);x=245+570*(t-5.1)
  d.line((x,1595,min(x+30,865),1595),fill='#FF6171',width=3)
 if t<.16:out=Image.blend(Image.new('RGB',out.size,'#070709'),out,t/.16)
 return out
p=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','30','-i','pipe:0','-an','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-threads','4',str(R/'visual.mp4')],stdin=subprocess.PIPE)
for n in range(225):p.stdin.write(frame(n/30).tobytes())
p.stdin.close();assert p.wait()==0
frame(6.5).save(R/'check.jpg')
