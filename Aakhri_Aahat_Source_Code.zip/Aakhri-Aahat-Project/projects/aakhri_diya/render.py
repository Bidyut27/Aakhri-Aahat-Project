"""Aakhri Diya: exactly 1800 frames at 30 fps. Native flat 2D geometry, 4K master."""
from pathlib import Path
import math,json,sys,subprocess
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from scipy.io import wavfile
import primitives as g
from primitives import C,limb,ease,lerp
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
g.SCALE=3 if '--4k' in sys.argv else 1.5
W,H=int(720*g.SCALE),int(1280*g.SCALE);FPS=30;DURATION=60
P={'bg':'#0B0B0D','wall':'#222226','floor':'#343236','edge':'#797577','red':'#C62828','light':'#FF625A','white':'#F5F0E6','skin':'#BD957F','grey':'#aaa29e'}
T=json.loads((ROOT/'timeline.json').read_text()) if (ROOT/'timeline.json').exists() else []
audio_path=ROOT/'audio/Viraj_Synced.wav'
if audio_path.exists():
 sr,v=wavfile.read(audio_path);v=v.astype(float)/32768
else:sr=48000;v=np.zeros(sr*60)
FONT_CACHE={}
def txt(c,xy,s,size=26,col=None,bold=False,mono=False):
 key=(round(size*c.s*g.SCALE),bold,mono)
 if key not in FONT_CACHE:
  path='/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf' if mono else ROOT/'fonts'/('Mukta-ExtraBold.ttf' if bold else 'Mukta-Regular.ttf')
  FONT_CACHE[key]=ImageFont.truetype(str(path),max(1,key[0]))
 c.d.text(c.pt(xy),s,font=FONT_CACHE[key],fill=col or P['white'],anchor='mm')
def amplitude(t):
 a=int(max(0,t)*sr);b=min(len(v),a+1200)
 return min(1,float(np.sqrt(np.mean(v[a:b]**2)))*10) if b>a else 0
def plane(c,x,y,s=1):
 c=c.group(x,y,s);c.poly([(-87,0),(-34,-10),(-7,-58),(8,-58),(6,-8),(76,-4),(93,0),(75,5),(8,11),(4,39),(-9,39),(-22,12),(-77,9)],'#d0c8bf')
 c.poly([(-73,0),(-89,-22),(-102,-22),(-87,7)],P['red'])
 for xx in [-55,-39,-23,-7,9,25,41]:c.ellipse((xx,-3,xx+5,1),'#414147')

def actor(c,x,y,s,t,kind='son',pose='idle',gaze=0,speak=False,reach=None,smile=False,age=0):
 c=c.group(x,y,s);walk=pose=='run';bob=abs(math.sin(t*10))*5 if walk else math.sin(t*2.4)*1.4;c=c.group(0,-bob)
 dad=kind=='dad';staff=kind=='staff';grey=dad or age>.5
 shirt='#908986' if dad else '#9b2835' if staff else '#762938';trouser='#323137' if dad else '#1b1a20'
 c.ellipse((-61,-9,61,10),'#0c0b10')
 for xx,sign in [(-23,1),(23,-1)]:
  swing=math.sin(t*10)*30*sign if walk else (5*math.sin(t*2) if pose=='recoil' else 0)
  knee=(xx+swing*.5,-71-abs(swing)*.25);foot=(xx+swing,-13)
  limb(c,(xx,-136),knee,trouser,26);limb(c,knee,foot,trouser,22)
  c.round((foot[0]-16,-21,foot[0]+24,-2),5,'#bcb6aa');c.rect((foot[0]-16,-6,foot[0]+24,-1),'#6c6769')
 c.round((-48,-257,48,-133),13,shirt)
 if dad:
  for yy in [-239,-212,-183,-153]:c.line([(-43,yy),(43,yy)],'#6e6869',2)
  for xx in [-24,0,24]:c.line([(xx,-251),(xx,-139)],'#6e6869',2)
  c.rect((15,-224,35,-202),'#a69d94')
 elif staff:
  c.poly([(-15,-255),(12,-255),(0,-196)],P['white']);c.line([(-19,-249),(0,-180),(21,-249)],'#4e1d28',4)
  c.round((17,-225,37,-211),2,P['white'])
 else:
  c.line([(-18,-251),(-8,-216)],'#ad7479',3);c.line([(18,-251),(8,-216)],'#ad7479',3)
  c.round((-29,-182,29,-151),5,'#50242e');c.line([(-25,-179),(25,-179)],'#8b5158',2)
 # articulated shoulders, elbows and hands, with explicit contact targets
 for sign in [-1,1]:
  hand=(sign*57,-147);el=(sign*67,-201)
  if walk:el=(sign*64,-202+sign*math.sin(t*10)*32);hand=(sign*42,-161+sign*math.sin(t*10)*47)
  if dad and sign==-1:el=(-68,-204);hand=(-72,-182)
  if pose=='bang':hand=(sign*82,-300-12*math.sin(t*15));el=(sign*83,-222)
  if pose=='recoil':el=(sign*79,-207);hand=(sign*93,-250)
  if reach is not None and sign==1:hand=reach;el=((44+hand[0])*.5+18,(-238+hand[1])*.5+33)
  limb(c,(sign*45,-239),el,shirt,21);limb(c,el,hand,P['skin'],16)
  if pose in ['bang','touch'] or reach is not None and sign==1:
   c.ellipse((hand[0]-9,hand[1]-12,hand[0]+9,hand[1]+10),P['skin'])
   for j in range(3):c.line([(hand[0]-7+j*6,hand[1]-4),(hand[0]-7+j*6,hand[1]-19)],P['skin'],4)
 if dad and pose!='bang':plane(c,-84,-173,.38)
 # face, eyes, eyelids, brows, jaw and mouth response to the voice envelope
 hx=3*math.sin(t*1.5)+gaze*5;head=c.group(hx,-289)
 c.rect((hx-12,-282,hx+12,-250),P['skin'])
 head.ellipse((-34,-65,34,10),P['skin']);head.ellipse((-39,-34,-29,-14),P['skin']);head.ellipse((29,-34,39,-14),P['skin'])
 hair='#a9a3a0' if dad else tuple(round(lerp(a,b,age)) for a,b in zip((23,21,26),(169,163,160)))
 head.poly([(-33,-27),(-35,-57),(-13,-72),(18,-69),(34,-51),(33,-36),(20,-48),(-21,-48),(-25,-26)],hair)
 if staff:head.round((-40,-62,-28,14),7,'#20171e')
 for xx in [-12,12]:
  worried=pose in ['bang','recoil','scared','write']
  head.line([(xx-6,-37-(3 if worried and xx<0 else 0)),(xx+6,-37-(3 if worried and xx>0 else 0))],'#51413d',2)
  if t%4.1>3.93:head.line([(xx-4,-26),(xx+4,-26)],'#362d2d',2)
  else:
   head.ellipse((xx-5,-31,xx+5,-22),'#e5d9cd');head.ellipse((xx-2+gaze*2,-29,xx+2+gaze*2,-23),'#29242a')
 head.line([(1,-24),(5,-14),(0,-12)],'#99715f',2)
 mouth=amplitude(t) if speak else 0
 if mouth>.08:head.ellipse((-7,-4,7,1+mouth*11),'#48282c')
 elif smile:head.line([(-10,-4),(-4,0),(4,0),(10,-4)],'#74504a',2)
 else:head.line([(-8,-3),(8,-3 if pose!='scared' else 0)],'#74504a',2)
 if grey:
  for yy in [-43,-40]:head.line([(-12,yy),(12,yy)],'#997f72',1)
  head.line([(-25,-16),(-18,-11)],'#997f72',1);head.line([(18,-11),(25,-16)],'#997f72',1)
  head.line([(-21,-1),(-12,10),(12,10),(22,-2)],'#aca198',3)


def diya(c,x,y,t,s=1,lit=True,blow=0):
 c=c.group(x,y,s)
 c.ellipse((-43,-8,43,20),'#9d4931');c.poly([(-42,4),(42,4),(25,30),(-23,30)],'#722c28')
 c.ellipse((-37,-7,37,10),'#dd8a4a');c.ellipse((-30,-3,30,7),'#5e2f24');c.line([(0,0),(2,-12)],'#eee2be',3)
 if lit:
  w=2*math.sin(t*17);h=40+4*math.sin(t*13)
  c.poly([(0,-9),(-13,-26),(-9+w,-42),(4+blow*32,-h-20),(11+w,-33),(10,-17)],'#ff9e3d')
  c.poly([(0,-11),(-6,-24),(3+blow*17,-45),(7,-24)],'#fff1b2')
 else:
  for i in range(3):
   yy=-18-i*22-(t*19%22);xx=math.sin(t*2+i)*9
   c.line([(xx-3,yy+14),(xx+5,yy),(xx,yy-13)],'#6a5c62',2)

def garland(c):
 for i in range(28):
  x=70+i*22;y=175+58*math.sin(i/27*math.pi)
  c.ellipse((x-9,y-9,x+9,y+9),'#9b462a' if i%3 else '#c27b3a')

def room(c,t,opened=0,dark=False):
 c.rect((0,0,720,1280),'#171419' if dark else '#292126')
 c.poly([(0,930),(720,930),(720,1280),(0,1280)],'#201a20')
 for x in range(-400,1200,160):c.line([(360,800),(x,1280)],'#3a2c32',2)
 for y in [961,1040,1150]:c.line([(0,y),(720,y)],'#3a2c32',2)
 c.rect((283,265,643,945),'#6a4546');c.rect((299,281,627,931),'#09090d')
 right=627-opened*270
 c.poly([(299,281),(right,281+opened*50),(right,931-opened*35),(299,931)],'#38272f' if not dark else '#20191f')
 for yy in [322,596]:
  c.poly([(316,yy),(right-18,yy+opened*35),(right-18,yy+240-opened*20),(316,yy+240)],'#4e3339' if not dark else '#2b1e25')
 c.ellipse((right-47,597,right-34,610),'#bca084')
 c.rect((34,337,214,654),'#665157');c.rect((46,349,202,642),'#101118')
 for xx in [98,151]:c.line([(xx,350),(xx,641)],'#51434a',5)
 c.line([(45,490),(203,490)],'#51434a',5)
 if not dark:
  for j in range(3):
   phase=(t*.4+j*.31)%1;r=phase*49;cx=88+j*43;cy=420+(j%2)*110
   if phase<.85:
    for k in range(10):
     a=k*math.pi/5;c.line([(cx+math.cos(a)*r*.65,cy+math.sin(a)*r*.65),(cx+math.cos(a)*r,cy+math.sin(a)*r)],'#af4e49',2)
 garland(c)
 c.line([(250,96),(265,165),(247,239)],'#433039',2)

def mother(c,x,y,s,t):
 c=c.group(x,y,s)
 c.ellipse((-66,-5,68,15),'#0b0a0f')
 c.poly([(-39,-255),(35,-255),(67,-2),(-64,-2)],'#7e3942')
 c.poly([(-34,-253),(-7,-245),(53,-4),(27,-4)],'#ae6e5e')
 c.round((-13,-281,14,-249),5,P['skin'])
 c.ellipse((-35,-338,36,-260),'#342930');c.ellipse((-26,-329,27,-269),P['skin'])
 c.poly([(-32,-324),(0,-345),(32,-327),(28,-307),(0,-327),(-28,-305)],'#9a8b85')
 for xx in [-10,12]:c.line([(xx-3,-302),(xx+3,-302)],'#4b3234',2)
 c.ellipse((-2,-319,3,-314),'#a51f34');c.line([(-7,-281),(8,-281)],'#754845',2)
 limb(c,(-32,-239),(-60,-191),'#7e3942',22);limb(c,(-60,-191),(-33,-167),P['skin'],15)
 hx=78+8*math.sin(t*1.3);hy=-182
 limb(c,(30,-239),(64,-204),'#7e3942',22);limb(c,(64,-204),(hx,hy),P['skin'],15)
 diya(c,hx,hy-12,t,.65)

def portrait(c,x,y,s=1,mom=False):
 c=c.group(x,y,s);c.round((-89,-125,89,125),5,'#846044');c.rect((-77,-113,77,113),'#c5aa8d')
 c.poly([(-65,111),(-44,38),(40,38),(68,111)],'#653b45');c.ellipse((-42,-81,42,47),'#2b2027');c.ellipse((-30,-64,31,28),'#b18c7d')
 c.poly([(-34,-57),(0,-88),(35,-53),(11,-59),(-21,-39)],'#91827e' if mom else '#201b21')
 for xx in [-12,12]:c.ellipse((xx-3,-25,xx+3,-20),'#34252d')
 c.line([(-9,8),(0,12),(10,8)],'#704b4d',2)
 # Memorial flower garland; no dates or extra text.
 for i in range(21):
  a=i/20*math.pi;xx=-92*math.cos(a);yy=-70+167*math.sin(a)
  c.ellipse((xx-9,yy-9,xx+9,yy+9),'#bf7940' if i%2 else '#864232')

def shadow(c,x,y,s,t,bend=0):
 c=c.group(x,y,s);c=c.group(bend*40,0)
 c.poly([(-43,-292),(37,-298),(100,-20),(55,10),(-86,4)],'#09090c')
 c.ellipse((-48,-383,44,-278),'#09090c')
 for j in range(8):
  xx=-50+j*13;c.poly([(xx,-335),(xx+12,-335),(xx+24+8*math.sin(t*2+j),-204-j%3*22),(xx+10,-250)],'#09090c')
 limb(c,(-35,-275),(-83,-161),'#09090c',19);limb(c,(34,-275),(74,-165),'#09090c',19)
 if bend>.4:c.line([(14,-317),(26,-315)],'#8b333d',3)

def phone(c,t,u):
 c.round((166,286,554,952),30,'#090b10','#79666e',5);c.round((184,316,536,919),16,'#20222b')
 txt(c,(360,399),'MAA',49,P['white'],True);txt(c,(360,459),'Saved voice message',24,'#b4a7ab')
 c.ellipse((299,502,421,624),'#65303c');c.poly([(348,539),(348,590),(385,564)],P['white'])
 for i in range(29):
  h=10+36*abs(math.sin(i*1.9+t*4));xx=213+i*10;c.line([(xx,719-h),(xx,719+h)],P['light'] if i/29<u else '#6d5a64',4)
 c.line([(219,828),(501,828)],'#74626a',3);c.ellipse((213+282*u,821,227+282*u,835),P['white'])
 # Thumb taps play, then rests on the side.
 k=ease(min(1,u*5));c.round((504,721,577,1013),31,P['skin']);c.round((lerp(390,518,k),lerp(548,760,k),lerp(438,565,k),lerp(660,861,k)),20,P['skin'])

def outro(c,t):
 c.rect((0,0,720,1280),P['bg']);c.line([(90,223),(630,223)],P['red'],4)
 txt(c,(360,375),'SUBSCRIBE',78,P['red'],True);txt(c,(360,462),'karein',45)
 txt(c,(360,658),'FACEBOOK',56,P['white'],True);txt(c,(360,724),'aur',29)
 txt(c,(360,791),'INSTAGRAM',56,P['white'],True);txt(c,(360,912),'pe FOLLOW karein',44,P['light'],True)
 diya(c,360,1070,t,.8)

def frame(t):
 im=Image.new('RGB',(W,H),P['bg']);c=C(im)
 if t>=54:outro(c,t);return im
 z=1+.022*math.sin(t*.1)**2;c=C(im,360*(1-z),650*(1-z),z)
 if t<7:
  room(c,t);mother(c,176,984,1.4,t)
  for x in [385,465,545]:diya(c,x,989,t,.75,lit=(t<3 or x==465))
 elif t<16:
  room(c,t);mother(c,174,1000,1.55,t);diya(c,472,962,t,1.12)
  if t>11:shadow(c,471,892,.8,t)
 elif t<22:
  room(c,t,dark=True);portrait(c,352,598,1.9)
  if t>19:
   c.rect((0,240,720,980),'#20191f');portrait(c,360,587,1.9,True)
  diya(c,360,977,t,1.3)
 elif t<26:
  room(c,t,dark=t>=24.5);u=ease((t-22)/2)
  actor(c,170+u*60,1070,1.6,t,pose='scared',gaze=1,reach=(122,-150))
  diya(c,460,842,t,1.4,lit=t<24.5,blow=ease((t-24)/.5))
  if 24<t<24.5:c.line([(300,702),(360,737),(450,788)],'#b29b91',2)
 elif t<30:
  room(c,t,opened=ease((t-27)/3)*.12,dark=True);actor(c,140,1090,1.3,t,pose='recoil',gaze=1)
  diya(c,460,964,t,1.1,False)
  c.ellipse((448,500,452,504),'#b04b53');c.ellipse((476,500,480,504),'#b04b53')
 elif t<35:
  room(c,t,dark=True);phone(c,t,(t-30)/5)
 elif t<43:
  room(c,t,dark=True);shadow(c,464,921,1.5,t,bend=ease((t-38)/5)*.25)
  # Visual memory of the flame containing the shadow.
  diya(c,456,972,t,1.8)
  c.round((45,295,229,445),12,'#20222b');txt(c,(137,335),'MAA',27,P['white'],True)
  for i in range(12):
   h=7+12*abs(math.sin(i+t*6));c.line([(75+i*11,387-h),(75+i*11,387+h)],'#c68489',3)
 elif t<48:
  room(c,t,opened=ease((t-46)/1.5),dark=t<44.8)
  shake=math.sin(t*32)*2.5
  actor(c,193,1091,1.5,t,pose='scared',gaze=1,reach=(165+shake,-156))
  diya(c,463+shake,850,t,1.5,lit=t>=44.8)
  # Match moves to the wick with visible ignition.
  hx=lerp(595,466,ease((t-43)/1.7));hy=816+shake
  if t<45.4:
   c.line([(hx+40,hy+38),(hx,hy)],'#c6a378',5);c.ellipse((hx-4,hy-5,hx+5,hy+5),'#d67d42')
   if t>43.7:c.poly([(hx-7,hy),(hx-10,hy-15),(hx+3,hy-34),(hx+9,hy-10)],'#ffb04e')
 else:
  room(c,t,opened=1,dark=t>=52.8)
  shadow(c,lerp(512,444,ease((t-48)/4)),1106,2.2,t,bend=ease((t-49)/3))
  actor(c,286,1108,1.7,t,pose='scared',gaze=lerp(1,-1,ease((t-50)/2)),reach=(78,-201))
  diya(c,423,761,t,1.45,lit=t<52.8,blow=ease((t-52.2)/.6))
  if t>=53.3:im=Image.new('RGB',(W,H),P['bg'])
 c=C(im);r=next((r for r in T if r['start']<=t<r['end']),None)
 if r:
  lines=r['caption'].split('\n');h=44*len(lines)+36;c.round((32,1177-h,688,1177),10,P['bg'])
  for i,line in enumerate(lines):txt(c,(360,1177-h+35+i*44),line,32,P['white'])
 return im

def preview():
 times=[2,10,17.5,20.5,24,28,32,39,45.5,47.8,51.5,56]
 sheet=Image.new('RGB',(1200,730),P['bg']);d=ImageDraw.Draw(sheet)
 for i,t in enumerate(times):
  im=frame(t);im.save(OUT/f'qa_{t}.jpg',quality=90);x=i%6*200;y=i//6*365
  sheet.paste(im.resize((200,356)),(x,y));d.text((x+7,y+349),str(t)+'s',fill='white')
 sheet.save(OUT/'contact_sheet.jpg',quality=92)

def render():
 name='Aakhri_Diya_4K.mp4' if '--4k' in sys.argv else 'Aakhri_Diya_1080p.mp4'
 p=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{W}x{H}','-framerate','30','-i','pipe:0','-i',str(ROOT/'audio/Final_Mix.wav'),'-c:v','libx264','-threads','4','-preset','veryfast','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-movflags','+faststart','-t','60',str(OUT/name)],stdin=subprocess.PIPE)
 for i in range(1800):
  p.stdin.write(frame(i/30).tobytes())
  if i%150==0:print(f'{i/30:.0f}/60 seconds rendered',flush=True)
 p.stdin.close();assert p.wait()==0;print('Complete',flush=True)
if __name__=='__main__':
 if '--preview' in sys.argv:preview()
 if '--render' in sys.argv:render()
