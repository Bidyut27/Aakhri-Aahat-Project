# Aakhri Diya

Original fictional Diwali horror short. 60 seconds, vertical 9:16, 30 fps.

## Deliverables
- Aakhri_Diya_4K.mp4: 2160 x 3840 master
- Aakhri_Diya_1080p.mp4: 1080 x 1920 sharing copy
- Aakhri_Diya_Hinglish.srt: plain Roman Hindi subtitles
- Thumbnail_9x16.png: approved black/red illustrated cover

## Story
After his mother's death, Rohan extinguishes the diya she always left outside a closed room. A voice resembling his dead sister calls from inside. His mother's saved message explains what the flame contained. He relights it, but the room is empty. Someone behind him blows it out.

## Rebuild
Python 3, ffmpeg, Pillow, NumPy, SciPy are required.
Run `python prepare.py` then `python render.py --4k --render`.
Run `python render.py --preview` for a visual contact sheet.
Run `python render.py --render` for native 1080p.

## Edit controls
`prepare.py`: source narration cuts, pauses, caption wording, original synthesized SFX and mix.
`render.py`: editable 2D scenes, characters, animated limbs, flame, match, door, shadows, fireworks and end card.
`timeline.json`: final caption timing. `edit.json`: source-to-timeline scene map.
`audio/Viraj_original.mp3`: generated Hindi voice, Viraj - Deep, Suspenseful and Mysterious, ElevenLabs eleven_v4.
`audio/Viraj_Synced.wav`: original-speed narration with cinematic pauses.
`audio/Music_and_Effects.wav`: original synthesized effects/ambience stem.
`audio/Final_Mix.wav`: stereo mix, 48 kHz, 60 seconds, peak at or below -1.5 dBFS before encoding.
`audio/word_timings.json`: timing reference from transcription; bracketed directions are not subtitle text.
`fonts/`: bundled Mukta fonts and license. DejaVu fonts are used only by optional unused primitives.

## Creative standards
Black/red palette; regular-weight centered off-white subtitles without word highlighting. No channel name on screen. End card: SUBSCRIBE, FACEBOOK, INSTAGRAM, FOLLOW in bold uppercase. Thumbnail style is a detailed illustration; video uses flat 2D motion graphics.

## QA
1800 frames / 30 fps = exactly 60 seconds. Caption bounds and segment duration checks run before export. Audio timing and peak checks in output/qa_audio.json. Full decode and file metadata checked after rendering.
