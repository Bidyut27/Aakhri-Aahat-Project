from pathlib import Path
import json,subprocess
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter,sosfilt
from scipy.ndimage import uniform_filter1d,maximum_filter1d
ROOT=Path(__file__).resolve().parent;SR=48000
SEG=[(0,5.6,0,7,'hook'),(5.6,13.2,7,16,'mother'),(13.2,18.57,16,22,'memorial'),(18.57,20.65,22,26,'blow'),(20.65,23.2,26,30,'whisper'),(23.2,26.42,30,35,'phone'),(26.42,32.81,35,43,'warning'),(32.81,37.05,43,48,'relight'),(37.05,39.7,48,54,'reveal'),(39.7,None,54,60,'outro')]
CAPS=[(0.16,1.2,'Maa kehti thi...'),(1.52,3.92,'Diwali par saare diye\nbujha dena...'),(3.96,5.4,'Bas ek chhodkar.'),(5.84,9.76,'Har saal, band kamre ke bahar\nwoh ek diya jalati thi.'),(9.8,12.92,'Kehti, teri behen ko\nandhere se darr lagta hai.'),(13.36,16.56,'Lekin meri behen das saal\npehle mar chuki thi.'),(16.6,18.56,'Is saal Maa bhi nahi rahi.'),(18.58,20.64,'Maine aakhri diya bujha diya.'),(20.71,22.72,'Bhaiya... ab main\nbahar aa jaun?'),(23.328,26.4,'Ghabrakar maine Maa ka\naakhri voice message khola.'),(26.44,28.32,'Woh teri behen nahi hai.'),(28.4,29.84,'Jab tak diya jalta hai...'),(29.92,32.8,'Woh uski parchhai se\nbahar nahi aa sakti.'),(32.82,35.76,'Maine kaanpte haathon se\ndiya dobara jalaya.'),(35.8,37.04,'Kamra khaali tha.'),(37.11,38.24,'Mere peechhe...'),(38.32,39.44,'Kisi ne phoonk maari.'),(39.92,43.44,'Subscribe karein aur Facebook,\nInstagram pe follow karein.')]
def stamp(t):
 n=round(t*1000);return f'{n//3600000:02}:{n//60000%60:02}:{n//1000%60:02},{n%1000:03}'
def main():
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(ROOT/'audio/Viraj_original.mp3'),'-af','loudnorm=I=-18:TP=-3:LRA=9','-ar',str(SR),'-ac','1',str(ROOT/'audio/voice_normalized.wav')],check=True)
 _,v=wavfile.read(ROOT/'audio/voice_normalized.wav');v=v.astype(float)/32768;voice=np.zeros(SR*60);edits=[]
 for a,b,start,end,scene in SEG:
  b=b if b is not None else len(v)/SR;dest=start+.12
  # Build in extra silence before the final whispered line and CTA.
  if scene=='reveal':dest=49.4
  if scene=='outro':dest=54.7
  clip=v[round(a*SR):round(b*SR)].copy();fade=min(96,len(clip)//2);clip[:fade]*=np.linspace(0,1,fade);clip[-fade:]*=np.linspace(1,0,fade)
  assert dest+len(clip)/SR<=end+.001,(scene,dest,len(clip)/SR,end)
  at=round(dest*SR);voice[at:at+len(clip)]=clip
  edits.append(dict(source_start=a,source_end=b,start=start,end=end,scene=scene,voice_start=dest))
 def mapped(t):
  for r in edits:
   if r['source_start']<=t<=r['source_end']:return r['voice_start']+t-r['source_start']
  return 59
 rows=[dict(start=mapped(a),end=mapped(b),caption=cap) for a,b,cap in CAPS]
 (ROOT/'timeline.json').write_text(json.dumps(rows,indent=2));(ROOT/'edit.json').write_text(json.dumps(edits,indent=2))
 n=len(voice);t=np.arange(n)/SR;rng=np.random.default_rng(409);fx=np.zeros((n,2))
 def add(at,sound,pan=0):
  i=round(at*SR);k=min(len(sound),n-i)
  if i<0 or k<=0:return
  fx[i:i+k,0]+=sound[:k]*(1-.35*pan);fx[i:i+k,1]+=sound[:k]*(1+.35*pan)
 def tone(d,f,amp):
  q=np.arange(round(d*SR))/SR;return amp*np.sin(2*np.pi*f*q)*np.exp(-q*4)*np.minimum(1,q*180)
 def noise(d,lo,hi,amp):
  q=np.arange(round(d*SR))/SR;x=sosfilt(butter(2,[lo,hi],btype='bandpass',fs=SR,output='sos'),rng.standard_normal(len(q)));return x*amp*np.sin(np.pi*q/d)**2
 # Distant firecrackers and balcony ambience, deliberately removed at the first extinction.
 for at in [1.1,3.4,6.5,8.7,11.4,15.5,18.6,21.5]:
  q=np.arange(round(.8*SR))/SR;burst=sosfilt(butter(2,1900,fs=SR,output='sos'),rng.standard_normal(len(q)))*.13*np.exp(-q*11)
  add(at,burst,(-1)**round(at)*.65);add(at+.14,burst*.25,-.5)
 air=sosfilt(butter(2,700,fs=SR,output='sos'),rng.standard_normal(n))*.012
 tension=.012*np.sin(2*np.pi*49*t)+.006*np.sin(2*np.pi*73.6*t)
 bed=np.column_stack([air+tension,np.roll(air,470)+tension])
 env=np.ones(n);env[(t>=24.5)&(t<30)]=.15;env[t>=52.2]=0;bed*=env[:,None]
 # Cloth and steps, ceramic contact, breath, latch, phone tap, match strike and ignition.
 for at in [7.5,8.2,22.3,23.0]:add(at,tone(.19,100,.08)+noise(.19,300,1900,.025),-.45)
 add(9.1,tone(.35,830,.035),.4)
 for at in [24.25,52.3]:add(at,noise(.65,230,4200,.12),.1)
 add(27,tone(.24,210,.08),.6);add(27.1,noise(1.2,130,740,.07),.65)
 add(30.8,tone(.08,1100,.025));add(31,noise(.25,700,4000,.025))
 add(43.65,noise(.32,1100,8000,.12),.45);add(44.75,noise(.25,350,2100,.06),.4)
 add(46.1,noise(1.1,100,700,.055),.7)
 # Low impact on the revealed empty room and shadow; no overpowering jump-scare spike.
 add(48.5,tone(1.1,43,.12),-.15)
 lo,hi=round(mapped(26.44)*SR),round(mapped(32.8)*SR)
 voice[lo:hi]=.3*voice[lo:hi]+.9*sosfilt(butter(2,[300,3200],btype='bandpass',fs=SR,output='sos'),voice[lo:hi])
 activity=maximum_filter1d((np.abs(voice)>.012).astype(float),size=9601);duck=uniform_filter1d(.8-.5*activity,size=6001)
 mix=voice[:,None]+bed*duck[:,None]+fx*.72;mix*=min(1,.84/max(np.max(np.abs(mix)),1e-9));mix[-4800:]*=np.linspace(1,0,4800)[:,None]
 for name,data in [('Viraj_Synced',voice),('Music_and_Effects',bed+fx*.72),('Final_Mix',mix)]:wavfile.write(ROOT/f'audio/{name}.wav',SR,(np.clip(data,-1,1)*32767).astype(np.int16))
 (ROOT/'output/Aakhri_Diya_Hinglish.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(r["start"])} --> {stamp(r["end"])}\n{r["caption"]}' for i,r in enumerate(rows))+'\n')
 (ROOT/'output/qa_audio.json').write_text(json.dumps(dict(duration=60,samples=len(mix),peak_dbfs=float(20*np.log10(np.max(np.abs(mix)))),voice_speed_changed=False,finite=bool(np.isfinite(mix).all())),indent=2))
 print('60 seconds, natural voice speed, peak',20*np.log10(np.max(np.abs(mix))))
if __name__=='__main__':main()
