# Ginti Mat Karna — Edit Map

| Start | End | Scene | Caption |
|---:|---:|---|---|
| 0.00 | 2.75 | road | Raat ki aakhri bus mein... |
| 2.75 | 5.40 | seven | Conductor Ravi ne / passengers gine. |
| 5.40 | 7.14 | count | SAAT. |
| 7.14 | 9.44 | tickets | Usne saat ticket kaate. |
| 9.44 | 13.24 | money | Lekin paise... / aath logon ke aaye. |
| 13.24 | 17.23 | warning | Ravi dobara ginne utha... / driver ne haath pakad liya. |
| 17.23 | 21.20 | warning | Mod nikalne tak... / GINTI MAT KARNA. |
| 21.20 | 23.97 | child | Peeche se ek bachche / ki awaaz aayi. |
| 23.97 | 26.74 | child | Uncle... mera ticket? |
| 26.74 | 29.58 | child | Aakhri seat par / ek ladka baitha tha. |
| 29.58 | 33.30 | eight | Ravi ne aathva / passenger add kiya. |
| 33.30 | 36.28 | eight | Machine par likha aaya... / Total passengers... |
| 36.28 | 37.43 | nine | NAU. |
| 37.43 | 38.83 | appear9 |  |
| 38.83 | 41.68 | ten | Usne CANCEL dabaya. / DAS. |
| 41.68 | 43.08 | appear10 |  |
| 43.08 | 45.36 | eleven | Phir dabaya. / GYAARAH. |
| 45.36 | 49.69 | appear11 | Har beep ke saath... / ek khaali seat bhar rahi thi. |
| 49.69 | 52.15 | run | Ravi driver ki / taraf bhaaga. |
| 52.15 | 55.09 | empty | Driver ki seat / KHAALI THI. |
| 55.09 | 57.48 | empty | Bus phir bhi / chal rahi thi. |
| 57.48 | 59.30 | child | Peeche baitha / bachcha bola... |
| 59.30 | 62.77 | child | Uncle... driver ko / kyun gina? |
| 62.77 | 65.97 | final | Ticket machine se / aakhri parchi nikli. |
| 65.97 | 69.38 | final | AGLA DRIVER: RAVI |
