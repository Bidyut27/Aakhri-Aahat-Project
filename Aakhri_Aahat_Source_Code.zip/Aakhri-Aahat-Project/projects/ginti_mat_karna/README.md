# Ginti Mat Karna — Aakhri Aahat

Original 72-second Hindi supernatural horror short, delivered as vertical flat 2D motion graphics.

## Finished production

- 2160 × 3840 native geometric master, 30 fps, H.264/AAC.
- 1080 × 1920 viewing copy.
- Hindi narration and dialogue in the approved **Viraj — Deep, Suspenseful and Mysterious** voice.
- Hinglish captions, original procedural music, engine rumble, ticket-machine beeps, printer noise, footsteps and low impacts.
- Speech preserves its generated pitch and speed. Extra pauses provide time for visual reveals.

## Story

Conductor Ravi counts seven passengers on the last bus, but receives fares for eight. The driver warns him not to count again before the bend. A child asks for a ticket. Adding the eighth passenger makes the machine display nine; pressing cancel raises the count again. Empty seats fill. The driver disappears while the bus keeps moving. A final ticket names Ravi as the next driver.

## Editable project

This is a Python animation project, not an After Effects or Premiere file. All source geometry and audio inputs are bundled. No paid audio regeneration is required to rebuild it.

- `render.py`: original bus artwork, character rig, passenger positions, camera movement and video export.
- `primitives.py`: resolution-independent drawing helpers.
- `prepare.py`: phrase synchronization and original synthesized sound design.
- `timeline.json`: narration source boundaries, final scene times and captions.
- `Narration_Hindi.txt`: complete Hindi script with voice-performance cues.
- `audio/Viraj_original.mp3`: ElevenLabs source take.
- `audio/word_timings.json`: returned timing data.
- `audio/Viraj_Synced.wav`: isolated synchronized voice.
- `audio/Music_and_Effects.wav`: separate background track.
- `audio/Final_Mix.wav`: finished 48 kHz stereo mix.
- `output/Ginti_Mat_Karna_Hinglish.srt`: timed captions.
- `output/contact_sheet.jpg`: scene review sheet.
- `output/qa_audio.json`: runtime, peak and finite-sample checks.
- `Edit_Map.md`: readable shot timing map.

## Rebuild

Requires Python 3.12, Pillow, NumPy, SciPy, FFmpeg with libx264, and DejaVu Sans fonts. Update font paths in `primitives.py` for other systems.

```bash
python prepare.py
python render.py --preview
python render.py --render --4k
ffmpeg -i output/Ginti_Mat_Karna_4K.mp4 -vf scale=1080:1920 -c:v libx264 -crf 20 -preset fast -c:a copy -movflags +faststart output/Ginti_Mat_Karna_1080p.mp4
```

Scene geometry is authored in 720 × 1280 logical coordinates and rasterized at three times that resolution for the 4K master, including fonts. The viewing copy is downscaled from the finished master.

## Continuity and animation

The twelve bus seats have fixed positions. Seven are occupied initially. The eighth passenger is the child on the last row. The next three passengers are tinted shadow figures. The driver is visually distinct from Ravi through his cap, moustache and lack of ticket satchel.

Animation includes jointed limbs, running, blinking, subtle body motion, moving scenery, steering-wheel motion, button presses, rising passenger silhouettes and a printing receipt. Dialogue uses narration rather than phoneme lip-sync.

## Voice provenance

Voice ID: F8IvasoAdpDhOjLm5YBm. Model: eleven_v4. Source take: 5IjOcPzoWa5Q4QERMfVS. Flow: cJf7bptUNzof1WkPguiI.
