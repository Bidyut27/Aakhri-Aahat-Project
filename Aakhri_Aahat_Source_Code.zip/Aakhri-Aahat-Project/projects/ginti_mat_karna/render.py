"""Original flat 2D short. python prepare.py; python render.py --preview; python render.py --render --4k."""
from pathlib import Path
import json, math, sys, subprocess
from PIL import Image,ImageDraw
import primitives as g
from primitives import C,limb,ease,lerp
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
g.SCALE=3 if '--4k' in sys.argv else 1.5
W,H=int(720*g.SCALE),int(1280*g.SCALE);FPS=30
P={'bg':'#0b1722','wall':'#2d444a','dark':'#152a32','line':'#83948c','cream':'#e6dfbf','gold':'#cfad68','skin':'#bb8a66','khaki':'#a19470','red':'#dd806b','mint':'#99bbb0'}
ROWS=json.loads((ROOT/'timeline.json').read_text()) if (ROOT/'timeline.json').exists() else []
DURATION=ROWS[-1]['end']+3 if ROWS else 70

def trees(c,b,t):
 x,y,w,h=b;c.rect((x,y,x+w,y+h),'#102735')
 # Flat forest silhouettes travel behind clipped window glass.
 for i in range(7):
  xx=x+((i*83-t*74)%(w+90))-45
  if x+18<xx<x+w-18:
   c.line([(xx,y+h),(xx,y+22)],'#29454d',8)
   c.poly([(max(x,xx-27),y+h*.6),(xx,y+15),(min(x+w,xx+27),y+h*.6)],'#29454d')
 c.line([(x,y+h*.78),(x+w,y+h*.78)],'#3c555b',2)

def ravi(c,x,y,s,t,pose='idle',driver=False):
 c=c.group(x,y,s);walk=pose=='run';bob=abs(math.sin(t*9))*5 if walk else math.sin(t*2)*1.5;c=c.group(0,-bob)
 c.ellipse((-62,-9,62,10),'#0c2028')
 for xx,sign in [(-22,1),(22,-1)]:
  swing=math.sin(t*9)*27*sign if walk else 0
  limb(c,(xx,-129),(xx+swing/2,-68),'#4e5448',28);limb(c,(xx+swing/2,-68),(xx+swing,-14),'#4e5448',25)
  c.round((xx+swing-17,-21,xx+swing+25,-2),5,'#19292a')
 c.round((-47,-250,47,-128),12,P['khaki'])
 c.line([(0,-231),(0,-137)],'#786e51',2)
 for xx in [-34,12]:c.rect((xx,-215,xx+22,-193),'#797357');c.ellipse((xx+9,-210,xx+12,-207),P['cream'])
 if not driver:
  c.poly([(-35,-246),(-25,-250),(43,-143),(32,-136)],'#4d4438')
  c.round((16,-158,73,-92),6,'#625142',P['gold'],2);c.rect((21,-150,68,-135),'#74604b')
  c.round((-15,-195,13,-151),4,'#132832',P['mint'],1)
 swing=math.sin(t*9)*23 if walk else 0
 for sign in [-1,1]:
  a=(sign*45,-232);b=(sign*62,-187+sign*swing);d=(sign*56,-145+sign*swing)
  if pose=='point' and sign==1:b=(83,-236);d=(105,-274)
  if pose=='grab' and sign==-1:b=(-94,-210);d=(-130,-205)
  if pose=='steer':b=(sign*69,-205);d=(sign*59,-229)
  limb(c,a,b,P['khaki'],22);limb(c,b,d,P['skin'],17)
 c.rect((-12,-273,12,-243),P['skin']);c.ellipse((-34,-343,34,-270),P['skin'])
 c.poly([(-34,-311),(-34,-337),(-13,-350),(23,-344),(35,-326),(24,-326),(-19,-330),(-24,-307)],'#16282e')
 if driver:
  c.round((-39,-351,37,-331),6,'#6b705c');c.rect((-44,-335,44,-327),'#92947b')
  c.poly([(-13,-289),(0,-293),(13,-289),(15,-283),(0,-286),(-15,-283)],'#23312e')
 for xx in [-11,12]:
  c.line([(xx-6,-316),(xx+5,-312 if pose=='run' else -316)],'#493e31',2)
  if t%4.2>4.05:c.line([(xx-3,-305),(xx+3,-305)],'#19282a',2)
  else:c.ellipse((xx-3,-309,xx+3,-303),'#19282a')
 c.line([(1,-303),(4,-296),(0,-295)],'#8e654e',2)
 if pose in ['run','scared']:c.ellipse((-5,-287,6,-278),'#4c3b31')
 else:c.line([(-7,-283),(8,-283)],'#6e4e38',2)

def passenger(c,x,y,s,index=0,ghost=False,child=False,motion=0):
 c=c.group(x,y+math.sin(motion*1.8)*1.2,s);col=['#787e71','#665e6b','#687f84','#a28d68','#64706e','#947e71','#6b7484'][index%7]
 if ghost:col='#344f50'
 if child:col='#9c7658'
 c.round((-42,-94,42,-5),19,col)
 skin='#708e81' if ghost else P['skin'];c.ellipse((-25,-150,25,-92),skin)
 c.poly([(-25,-119),(-26,-142),(-10,-155),(16,-153),(27,-136),(22,-127),(15,-140),(-18,-137)],'#14282e')
 for xx in [-9,9]:
  if not ghost and motion%4.6>4.4:c.line([(xx-2,-124),(xx+2,-124)],'#26332e',2)
  else:c.ellipse((xx-2,-126,xx+2,-122),P['cream'] if ghost else '#26332e')
 c.line([(-6,-109),(6,-109)],'#4f6359' if ghost else '#76513d',2)

def aisle(c,t,count=7,child=False,reveal=0):
 c.rect((0,0,720,1280),P['wall'])
 c.poly([(0,0),(720,0),(507,218),(213,218)],'#485957')
 c.poly([(0,1280),(720,1280),(474,530),(246,530)],'#6b7061')
 c.line([(246,530),(0,1280)],'#adb29a',3);c.line([(474,530),(720,1280)],'#adb29a',3)
 trees(c,(249,269,222,170),t*.55)
 c.rect((238,253,483,451),None,'#91a197',7)
 # Twelve seats. Occupied seats are assigned fixed indexes, count stays visually auditable.
 slots=[]
 for row in range(6):
  ss=.55+row*.15;yy=490+row*105;xx=260-row*31
  for side in [0,1]:slots.append((xx if side==0 else 720-xx,yy,ss))
 # Child is fixed on the furthest right seat, initially empty.
 order=[0,2,3,4,5,6,7,1,8,9,10,11]
 occupied={order[k]:k for k in range(min(count,12))}
 for k,(xx,yy,ss) in enumerate(slots):
  if k%2==0:
   wx=15;wy=300+(k//2)*100
   trees(c,(wx,wy,107,75),t);c.rect((wx-3,wy-3,wx+110,wy+78),None,'#718982',3)
  else:
   wx=598;wy=300+(k//2)*100
   trees(c,(wx,wy,107,75),t);c.rect((wx-3,wy-3,wx+110,wy+78),None,'#718982',3)
  cc=c.group(xx,yy,ss)
  cc.round((-51,-68,51,23),10,'#203b40','#658379',3)
  cc.line([(-42,21),(-42,59)],'#132a31',7);cc.line([(42,21),(42,59)],'#132a31',7)
  if k in occupied:
   n=occupied[k];passenger(c,xx,yy+(reveal if n==count-1 and n>=8 else 0),ss,index=n,ghost=n>=8,child=n==7,motion=t+n*.25)
  cc.round((-54,-48,54,15),8,'#37574f','#6d8b79',2)
  cc.line([(-43,-31),(43,-31)],'#7f9581',2)
 # poles and hanging grips
 for xx in [160,560]:
  c.line([(xx,170),(xx,1040)],'#a0aea0',6)
 for xx in [220,300,420,500]:
  c.line([(xx,145),(xx,200)],'#a8b4a6',3);c.round((xx-12,198,xx+12,233),7,None,'#a8b4a6',4)
 c.rect((315,132,405,143),P['cream'])
 c.round((264,474,456,518),5,'#162e36');c.txt((360,496),'LAST SERVICE',15,P['gold'])

def road(c,t):
 c.rect((0,0,720,1280),'#0c1b29');c.ellipse((530,136,595,201),'#bac5b0')
 for i in range(22):
  xx=(i*127)%720;yy=(i*67)%560;c.ellipse((xx,yy,xx+2,yy+2),'#667f85')
 c.poly([(325,640),(397,640),(720,1280),(0,1280)],'#364a51')
 for i in range(7):
  u=((i/7+t*.23)%1);yy=640+u*u*640;ww=3+u*9;c.poly([(360-ww,yy),(360+ww,yy),(360+ww+3,yy+18+u*60),(360-ww-3,yy+18+u*60)],'#a6b098')
 for side in [0,1]:
  for i in range(6):
   u=((i/6+t*.13)%1);yy=580+u*650;x=220-u*240 if side==0 else 500+u*240
   c.poly([(x-30-u*40,yy),(x,yy-100-u*100),(x+30+u*40,yy)],'#1c3940')
 # bus frontal silhouette and moving suspension
 cc=c.group(360,987+math.sin(t*5)*3,.95)
 cc.round((-186,-522,186,35),36,'#8c9a88','#b6b69b',4)
 cc.rect((-166,-405,166,-184),'#18323e');cc.line([(0,-404),(0,-185)],'#9eaa98',6)
 cc.round((-142,-489,142,-435),5,'#19313a');cc.txt((0,-463),'LAST BUS',27,P['gold'])
 for xx in [-143,143]:cc.ellipse((xx-23,-69,xx+23,-25),P['cream'])
 cc.rect((-167,-153,167,-113),'#ac7054');cc.rect((-167,-105,167,-90),'#dfc99b')
 cc.round((-74,-31,74,1),3,'#243a3e');cc.txt((0,-14),'NIGHT SERVICE',12,P['cream'])
 for xx in [-171,151]:cc.rect((xx,25,xx+20,63),'#111e29')
 c.txt((360,212),'AAKHRI BUS',32,P['cream']);c.txt((360,263),'11:58 PM',21,P['mint'],mono=True)

def machine(c,t,count=7,press=False,receipt=False,u=0):
 c.rect((0,0,720,1280),P['dark'])
 for i in range(5):c.line([(0,230+i*190),(720,350+i*190)],'#28434b',2)
 c.poly([(103,1280),(158,750),(519,750),(620,1280)],'#765342')
 cc=c.group(0,0)
 cc.round((142,340,578,996),32,'#263c45','#7d928f',4)
 cc.round((164,371,556,593),13,'#acc0a4');cc.txt((360,416),'TOTAL PASSENGERS',22,'#304b42')
 cc.txt((360,507),str(count-1 if press and u<.28 else count).zfill(2),86,'#24483f',mono=True)
 cc.rect((219,321,501,344),'#0b1821')
 for row in range(3):
  for col in range(3):
   x=186+col*118;y=635+row*78;cc.round((x,y,x+101,y+60),9,'#546b6d','#81928a',2);cc.txt((x+50,y+30),str(row*3+col+1),27,P['cream'],mono=True)
 cc.round((186,887,405,956),10,P['red'] if press else '#9a6253');cc.txt((295,922),'CANCEL',25,P['cream'])
 cc.round((420,887,522,956),10,'#5a8672');cc.txt((471,922),'+',37,P['cream'])
 # fingers and pressed thumb are actual moving geometry
 cc.round((126,683,187,899),24,P['skin'])
 tx=lerp(565,337,ease(min(1,u*3))) if press else 565;ty=lerp(760,922,ease(min(1,u*3))) if press else 760
 cc.round((tx-32,ty-52,tx+35,ty+77),28,P['skin']);cc.line([(tx-16,ty-23),(tx+22,ty-23)],'#966e52',2)
 if receipt:
  h=lerp(90,260,ease(u*2));y=321-h
  cc.poly([(222,y),(238,y+7),(254,y),(270,y+7),(286,y),(302,y+7),(318,y),(334,y+7),(350,y),(366,y+7),(382,y),(398,y+7),(414,y),(430,y+7),(446,y),(462,y+7),(478,y),(495,y+7),(495,326),(222,326)],P['cream'])
  if h>240:
   cc.txt((360,y+57),'FINAL TICKET',18,'#526451',mono=True);cc.line([(243,y+90),(477,y+90)],'#8b967d',2)
   cc.txt((360,y+135),'AGLA DRIVER',25,'#263c37');cc.txt((360,y+203),'RAVI',48,'#863f34',mono=True)

def ledger(c,t):
 c.rect((0,0,720,1280),'#223b42');c.round((62,248,658,984),16,'#726f59')
 for i in range(7):
  x=102+(i%4)*137;y=306+(i//4)*162;c.rect((x,y,x+108,y+136),P['cream']);c.txt((x+54,y+28),'TICKET',13,'#34463d');c.txt((x+54,y+73),str(i+1).zfill(2),31,'#34463d',mono=True)
 c.txt((360,707),'7 TICKETS',29,P['cream'])
 for i in range(8):
  xx=127+(i%4)*155;yy=798+(i//4)*96;c.ellipse((xx-31,yy-31,xx+31,yy+31),P['gold'],'#e9d39e',3);c.txt((xx,yy),'1',28,'#6e6046',mono=True)
 c.txt((360,203),'KIRAYA AATH LOGON KA',25,P['cream'])

def cabin(c,t,empty=False):
 c.rect((0,0,720,1280),'#263c45');c.round((46,179,674,746),20,'#0d202e','#82958e',7)
 c.poly([(309,461),(414,461),(649,731),(69,731)],'#314c56')
 for i in range(5):
  q=((i/5+t*.3)%1);yy=461+q*q*270;c.rect((357-q*4,yy,364+q*4,yy+10+q*23),'#bcc4aa')
 for side in [0,1]:
  for i in range(5):
   q=(i/5+t*.13)%1;x=256-q*211 if side==0 else 464+q*210;yy=454+q*235
   c.poly([(x-25,yy),(x,yy-80-q*100),(x+25,yy)],'#1d3941')
 c.line([(360,187),(360,742)],'#81928a',5)
 c.round((68,794,350,1114),28,'#1a3038','#657c76',5);c.round((88,812,330,1060),25,'#405b54')
 c.rect((174,1050,247,1220),'#142932')
 if not empty:ravi(c,226,1190,1.4,t,'steer',True)
 c.poly([(382,750),(698,750),(720,934),(391,934)],'#526c69')
 c.round((427,784,658,880),14,'#182e36')
 for xx in [474,604]:
  c.ellipse((xx-36,795,xx+36,867),'#8fa393');c.line([(xx,831),(xx+22*math.sin(t),809)],'#273e39',3)
 c.ellipse((113,753,348,953),None,'#172a2e',17)
 angle=.12*math.sin(t*1.7)
 for a in [0,2.094,4.189]:
  c.line([(230,853),(230+108*math.cos(a+angle),853+91*math.sin(a+angle))],'#172a2e',10)
 c.ellipse((211,837,249,872),'#8b9b8a')
 c.txt((550,939),'ENGINE ON',16,P['mint'],mono=True)
 c.line([(99,688),(288,653)],'#829a97',4);c.line([(417,687),(604,650)],'#829a97',4)

def childshot(c,t):
 c.rect((0,0,720,1280),'#1a303b');trees(c,(84,212,552,324),t)
 c.rect((75,200,645,547),None,'#81998d',9);c.line([(360,206),(360,539)],'#81998d',7)
 c.round((100,708,620,1023),33,'#43675b','#8aa18b',5)
 passenger(c,365,967,3.1,child=True,motion=t)
 c.round((110,939,610,1038),23,'#365447','#76917a',4)
 c.txt((360,155),'LAST ROW',20,P['mint'],mono=True)

def warning(c,t):
 cabin(c,t)
 # A medium shot of the two people, joined hands clearly in the foreground.
 ravi(c,496,1115,1.65,t,'scared')
 c.line([(155,835),(267,834),(383,812)],P['skin'],31)
 c.ellipse((356,791,401,835),P['skin'])
 c.line([(394,814),(435,853)],P['skin'],24)
 c.txt((360,141),'GINTI MAT KARNA',29,P['gold'])

def frame(t):
 im=Image.new('RGB',(W,H),P['bg']);c=C(im)
 if t>=ROWS[-1]['end']:
  c.txt((360,407),'GINTI',73,P['cream']);c.txt((360,491),'MAT KARNA',65,P['red']);c.line([(287,586),(433,586)],P['mint'],3)
  c.txt((360,678),'AAKHRI AAHAT',30,P['cream']);c.txt((360,737),'Aakhri sawaari... kaun?',22,P['mint']);return im
 row=next(r for r in ROWS if r['start']<=t<r['end']);idx=ROWS.index(row);first=last=idx;sc=row['scene']
 while first>0 and ROWS[first-1]['scene']==sc:first-=1
 while last+1<len(ROWS) and ROWS[last+1]['scene']==sc:last+=1
 local=t-ROWS[first]['start'];u=local/(ROWS[last]['end']-ROWS[first]['start']);z=1+.025*ease(u);c=C(im,360*(1-z),620*(1-z),z)
 if sc=='road':road(c,t)
 elif sc in ['seven','count']:
  aisle(c,t,7);ravi(c,363,1094,.86,t,'point')
  if sc=='count':c.round((275,246,445,330),10,'#102934');c.txt((360,286),'07',52,P['gold'],mono=True)
 elif sc=='tickets':machine(c,t,7)
 elif sc=='money':ledger(c,t)
 elif sc=='warning':warning(c,t)
 elif sc=='child':childshot(c,t)
 elif sc=='eight':machine(c,t,8,False)
 elif sc in ['nine','ten','eleven']:
  n={'nine':9,'ten':10,'eleven':11}[sc];machine(c,t,n,sc!='nine',u=u)
 elif sc in ['appear9','appear10','appear11']:
  n=int(sc[6:]);aisle(c,t,n,reveal=20*(1-ease(local/.35)));c.round((275,246,445,330),10,'#102934');c.txt((360,286),str(n).zfill(2),52,P['red'],mono=True)
 elif sc=='run':
  aisle(c,t,11);ravi(c,360,1110,lerp(.65,1.6,ease(u)),t,'run')
 elif sc=='empty':cabin(c,t,True)
 elif sc=='final':machine(c,t,11,receipt=True,u=u)
 c=C(im);c.txt((360,1100 if sc=='final' else 50),'AAKHRI AAHAT',14,'#a1b5ae')
 if sc not in ['final','road']:c.line([(52,88),(52+616*t/DURATION,88)],'#76988f',2)
 if row.get('caption') and sc!='final':
  lines=row['caption'].split('\n');h=len(lines)*43+35;c.round((34,1162-h,686,1162),12,'#0c1d27')
  for i,line in enumerate(lines):c.txt((360,1162-h+35+i*43),line,27,P['cream'])
 return im

def preview():
 sheet=Image.new('RGB',(1080,math.ceil(len(ROWS)/6)*346),P['bg']);d=ImageDraw.Draw(sheet)
 for i,r in enumerate(ROWS):
  im=frame((r['start']+r['end'])/2);im.save(OUT/f'qa_{i:02}.jpg',quality=86);x=i%6*180;y=i//6*346
  sheet.paste(im.resize((180,320)),(x,y));d.text((x+5,y+324),f'{i:02} {r["scene"]}',fill='white')
 sheet.save(OUT/'contact_sheet.jpg',quality=90)

def render():
 name='Ginti_Mat_Karna_4K.mp4' if '--4k' in sys.argv else 'Ginti_Mat_Karna_1080p.mp4'
 p=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{W}x{H}','-framerate',str(FPS),'-i','pipe:0','-i',str(ROOT/'audio/Final_Mix.wav'),'-c:v','libx264','-threads','4','-preset','veryfast','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-movflags','+faststart','-t',str(DURATION),str(OUT/name)],stdin=subprocess.PIPE)
 for i in range(math.ceil(DURATION*FPS)):
  p.stdin.write(frame(i/FPS).tobytes())
  if i%(FPS*5)==0:print(f'{i/FPS:.0f}/{DURATION:.1f} seconds rendered',flush=True)
 p.stdin.close();assert p.wait()==0;print('Complete',flush=True)

if __name__=='__main__':
 if '--preview' in sys.argv:preview()
 if '--render' in sys.argv:render()
