"""Phrase alignment and original procedural score. No speed/pitch changes to Viraj."""
from pathlib import Path
import json,subprocess,math
import numpy as np
from scipy.io import wavfile
from scipy.ndimage import uniform_filter1d,maximum_filter1d
from scipy.signal import butter,sosfilt
ROOT=Path(__file__).resolve().parent;SR=48000
# source start, scene, caption, pause after phrase
CUTS=[
 (0,'road','Raat ki aakhri bus mein...',.5),
 (2.0,'seven','Conductor Ravi ne\npassengers gine.',.35),
 (4.3,'count','SAAT.',.8),
 (5.24,'tickets','Usne saat ticket kaate.',.4),
 (7.14,'money','Lekin paise...\naath logon ke aaye.',1.0),
 (9.94,'warning','Ravi dobara ginne utha...\ndriver ne haath pakad liya.',.25),
 (13.68,'warning','Mod nikalne tak...\nGINTI MAT KARNA.',1.0),
 (16.65,'child','Peeche se ek bachche\nki awaaz aayi.',.2),
 (19.22,'child','Uncle... mera ticket?',.65),
 (21.34,'child','Aakhri seat par\nek ladka baitha tha.',.3),
 (23.88,'eight','Ravi ne aathva\npassenger add kiya.',.3),
 (27.3,'eight','Machine par likha aaya...\nTotal passengers...',0),
 (30.28,'nine','NAU.',.45),
 (30.98,'ten','Usne CANCEL dabaya.\nDAS.',.45),
 (33.38,'eleven','Phir dabaya.\nGYAARAH.',.45),
 (35.21,'appear11','Har beep ke saath...\nek khaali seat bhar rahi thi.',.8),
 (38.74,'run','Ravi driver ki\ntaraf bhaaga.',.7),
 (40.5,'empty','Driver ki seat\nKHAALI THI.',1.1),
 (42.34,'empty','Bus phir bhi\nchal rahi thi.',.7),
 (44.026,'child','Peeche baitha\nbachcha bola...',.25),
 (45.605,'child','Uncle... driver ko\nkyun gina?',1.3),
 (47.77,'final','Ticket machine se\naakhri parchi nikli.',.4),
 (50.565,'final','AGLA DRIVER: RAVI',1.5),
]

def stamp(t):
 n=round(t*1000);return f'{n//3600000:02}:{n//60000%60:02}:{n//1000%60:02},{n%1000:03}'

def main():
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(ROOT/'audio/Viraj_original.mp3'),'-af','loudnorm=I=-18:TP=-3:LRA=9','-ar',str(SR),'-ac','1',str(ROOT/'audio/voice_normalized.wav')],check=True)
 _,v=wavfile.read(ROOT/'audio/voice_normalized.wav');v=v.astype(float)/32768
 rows=[];pos=.25
 for i,(a,sc,cap,pause) in enumerate(CUTS):
  b=CUTS[i+1][0] if i+1<len(CUTS) else len(v)/SR
  rows.append(dict(start=pos if i else 0,end=pos+b-a+pause,voice_start=pos,source_start=a,source_end=b,scene=sc,caption=cap));pos+=b-a+pause
  if sc in ['nine','ten']:
   rows.append(dict(start=pos,end=pos+1.4,voice_start=None,source_start=None,source_end=None,scene='appear9' if sc=='nine' else 'appear10',caption=''));pos+=1.4
 duration=math.ceil((pos+3)*30)/30;n=round(duration*SR);voice=np.zeros(n)
 for r in rows:
  if r['source_start'] is None:continue
  clip=v[round(r['source_start']*SR):round(r['source_end']*SR)].copy();k=min(96,len(clip)//2)
  clip[:k]*=np.linspace(0,1,k);clip[-k:]*=np.linspace(1,0,k);i=round(r['voice_start']*SR);voice[i:i+len(clip)]+=clip
 t=np.arange(n)/SR;rng=np.random.default_rng(711)
 # Engine rumble, quiet wind and an original two-note suspense bed.
 engine=.019*np.sin(2*np.pi*44*t)+.012*np.sin(2*np.pi*88.4*t)
 wind=sosfilt(butter(2,350,fs=SR,output='sos'),rng.standard_normal(n))*.026
 drone=.013*np.sin(2*np.pi*65.4*t)*( .7+.3*np.sin(t*.35))+.008*np.sin(2*np.pi*98.5*t)
 bed=np.column_stack([engine+wind+drone,engine+np.roll(wind,1500)+drone]);fx=np.zeros((n,2))
 def add(at,sound,pan=0):
  i=round(at*SR);k=min(len(sound),n-i)
  if i<0 or k<1:return
  fx[i:i+k,0]+=sound[:k]*(1-pan*.25);fx[i:i+k,1]+=sound[:k]*(1+pan*.25)
 def beep():
  q=np.arange(int(SR*.18))/SR;return .085*(np.sin(2*np.pi*1340*q)+.35*np.sin(2*np.pi*2010*q))*np.minimum(1,q*180)*np.exp(-q*18)
 def impact(d=.5):
  q=np.arange(int(SR*d))/SR;return .12*np.sin(2*np.pi*(78*q-37*q*q))*np.exp(-q*12)
 for r in rows:
  sc=r['scene'];a,b=r['start'],r['end']
  if sc in ['nine','ten','eleven']:
   at=a if sc=='nine' else a+.28*(b-a);add(at,beep())
  if sc in ['appear9','appear10','appear11']:add(a,impact(.6))
  if sc=='tickets':
   q=np.arange(int(SR*.7))/SR;add(a+.2,.035*np.sin(2*np.pi*120*q)*np.sin(2*np.pi*27*q))
  if sc=='run':
   for at in np.arange(a+.1,b-.1,.28):add(at,impact(.18),math.sin(at*8))
  if sc=='final' and r['source_start']==47.77:
   q=np.arange(int(SR*1.3))/SR;s=.022*rng.standard_normal(len(q))+.025*np.sin(2*np.pi*130*q);add(a+.15,s*np.sin(np.pi*q/1.3)**2)
 # Keep the engine moving under the empty driver seat, then silence the bed for the ticket.
 final=next(r['start'] for r in rows if r['scene']=='final');bed*=np.clip((final-t)/.65,0,1)[:,None]
 add(rows[-1]['end']+.01,impact(.8))
 activity=maximum_filter1d((np.abs(voice)>.015).astype(float),size=9601);duck=uniform_filter1d(.8-.45*activity,size=6001)
 mix=voice[:,None]+bed*duck[:,None]+fx*.7;mix*=min(1,.84/max(np.max(np.abs(mix)),1e-9))
 for name,data in [('Viraj_Synced',voice),('Music_and_Effects',bed+fx*.7),('Final_Mix',mix)]:wavfile.write(ROOT/f'audio/{name}.wav',SR,(np.clip(data,-1,1)*32767).astype(np.int16))
 (ROOT/'timeline.json').write_text(json.dumps(rows,indent=2))
 caps=[r for r in rows if r['caption']]
 (ROOT/'output/Ginti_Mat_Karna_Hinglish.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(r["start"])} --> {stamp(r["end"])}\n{r["caption"]}' for i,r in enumerate(caps))+'\n')
 (ROOT/'output/qa_audio.json').write_text(json.dumps(dict(duration=duration,peak_dbfs=float(20*np.log10(np.max(np.abs(mix)))),finite=bool(np.isfinite(mix).all()),voice_speed_changed=False),indent=2))
 print('Duration:',duration,'Peak dBFS:',20*np.log10(np.max(np.abs(mix))),flush=True)

if __name__=='__main__':main()
