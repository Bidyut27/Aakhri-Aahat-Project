from pathlib import Path
import json,subprocess
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter,sosfilt
from scipy.ndimage import uniform_filter1d,maximum_filter1d
ROOT=Path(__file__).resolve().parent;SR=48000
SEG=[(0,5.7,0,7,'hook'),(5.7,9.7,7,12,'pickup'),(9.7,19.9,12,24,'ride'),(19.9,21.75,24,28,'warning'),(21.75,26.9,28,35,'hands'),(26.9,31.15,35,41,'brake'),(31.15,34.5,41,46,'question'),(34.5,41.6,46,54,'reveal'),(41.6,None,54,60,'outro')]
CAPS=[(0.08,1.52,'Main bike taxi chalata hoon.'),(2.08,3.76,'Us raat passenger bola...'),(3.8,5.44,'Doosra helmet\nkhaali mat chhodna.'),(6,9.44,'Raat 1 baje, maine use\nsunsaan hospital se uthaya.'),(9.92,13.2,'Usne poochha, pichhli sawaari\nbhi yahin chhodi thi?'),(13.44,15.28,'Haan. Tumhe kaise pata?'),(15.36,16.88,'Usne helmet pehna tha?'),(17.28,19.68,'Nahi. Boli, paas hi jaana hai.'),(20.149,21.52,'Toh woh abhi utri nahi.'),(21.84,23.76,'Sheeshe mein ek hi helmet tha.'),(24.08,25.52,'Lekin meri kamar par...'),(25.6,26.747,'Chaar haath the.'),(26.96,28.24,'Maine brake lagaya.'),(28.28,31.12,'Passenger utarkar helmet\npichhli seat par rakh gaya.'),(31.2,33.36,'Bola, ise pehna rehne dena.'),(33.44,34.48,'Kaun pehnega?'),(34.52,36.16,'Usne mere peechhe dekha.'),(36.2,38.48,'Khaali helmet dheere se\nupar utha.'),(38.56,39.92,'Phir uska strap...'),(39.973,41.28,'Apne aap band ho gaya.'),(41.84,45.26,'Subscribe karein aur Facebook,\nInstagram pe follow karein.')]
def stamp(t):
 n=round(t*1000);return f'{n//3600000:02}:{n//60000%60:02}:{n//1000%60:02},{n%1000:03}'
def main():
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(ROOT/'audio/Viraj_original.mp3'),'-af','loudnorm=I=-18:TP=-3:LRA=9','-ar',str(SR),'-ac','1',str(ROOT/'audio/voice_normalized.wav')],check=True)
 _,v=wavfile.read(ROOT/'audio/voice_normalized.wav');v=v.astype(float)/32768;voice=np.zeros(SR*60);edits=[]
 for a,b,start,end,scene in SEG:
  b=b if b is not None else len(v)/SR;dest=start+.12
  # Build in extra silence before the final whispered line and CTA.
  if scene=='outro':dest=54.7
  clip=v[round(a*SR):round(b*SR)].copy();fade=min(96,len(clip)//2);clip[:fade]*=np.linspace(0,1,fade);clip[-fade:]*=np.linspace(1,0,fade)
  assert dest+len(clip)/SR<=end+.001,(scene,dest,len(clip)/SR,end)
  at=round(dest*SR);voice[at:at+len(clip)]=clip
  edits.append(dict(source_start=a,source_end=b,start=start,end=end,scene=scene,voice_start=dest))
 def mapped(t):
  for r in edits:
   if r['source_start']<=t<=r['source_end']:return r['voice_start']+t-r['source_start']
  return 59
 rows=[dict(start=mapped(a),end=mapped(b),caption=cap) for a,b,cap in CAPS]
 (ROOT/'timeline.json').write_text(json.dumps(rows,indent=2));(ROOT/'edit.json').write_text(json.dumps(edits,indent=2))
 n=len(voice);t=np.arange(n)/SR;rng=np.random.default_rng(409);fx=np.zeros((n,2))
 def add(at,sound,pan=0):
  i=round(at*SR);k=min(len(sound),n-i)
  if i<0 or k<=0:return
  fx[i:i+k,0]+=sound[:k]*(1-.35*pan);fx[i:i+k,1]+=sound[:k]*(1+.35*pan)
 def tone(d,f,amp):
  q=np.arange(round(d*SR))/SR;return amp*np.sin(2*np.pi*f*q)*np.exp(-q*4)*np.minimum(1,q*180)
 def noise(d,lo,hi,amp):
  q=np.arange(round(d*SR))/SR;x=sosfilt(butter(2,[lo,hi],btype='bandpass',fs=SR,output='sos'),rng.standard_normal(len(q)));return x*amp*np.sin(np.pi*q/d)**2
 # Original synthesized motor, road, wind and restrained tension bed.
 speed=np.ones(n);speed[t<9.7]=.25;speed[(t>=35)&(t<36.3)]=np.clip((36.3-t[(t>=35)&(t<36.3)])/1.3,.1,1);speed[t>=36.3]=0
 phase=2*np.pi*np.cumsum(38+speed*30)/SR
 motor=(.016*np.sin(phase)+.009*np.sin(2*phase)+.006*np.sin(3.03*phase))*(.5+.5*speed)
 motor[t>=36.3]=0
 road=sosfilt(butter(2,[150,1800],btype='bandpass',fs=SR,output='sos'),rng.standard_normal(n))*.014*speed
 tension=.01*np.sin(2*np.pi*47*t)+.005*np.sin(2*np.pi*70.8*t)
 bed=np.column_stack([motor+road+tension,motor+np.roll(road,830)+tension])
 bed[t>=51.5]=0
 # Passenger footsteps, jacket rustle, mounting click, controlled braking.
 for at in [7.4,8,8.6,37.2,37.8]:add(at,tone(.18,105,.075)+noise(.18,350,1700,.025),-.5)
 for at in [9.5,37,38.7]:add(at,noise(.3,700,4800,.045),-.3)
 add(9.7,tone(.06,1600,.06)+noise(.06,1000,7000,.1),-.3)
 q=np.arange(round(1.0*SR))/SR
 add(35.25,.035*np.sin(2*np.pi*(1100*q-280*q*q))*np.sin(np.pi*q)**2+noise(1,600,5000,.05),.5)
 add(39.2,tone(.17,210,.07),-.4)
 # Soft reveal hit as the second pair of hands arrives, tension removed before buckle.
 add(31.1,tone(.8,43,.12))
 add(48.2,noise(1.6,90,600,.03),-.3)
 add(52.6,tone(.08,1800,.085)+noise(.08,1500,9000,.18))
 activity=maximum_filter1d((np.abs(voice)>.012).astype(float),size=9601);duck=uniform_filter1d(.8-.5*activity,size=6001)
 mix=voice[:,None]+bed*duck[:,None]+fx*.72;mix*=min(1,.84/max(np.max(np.abs(mix)),1e-9));mix[-4800:]*=np.linspace(1,0,4800)[:,None]
 for name,data in [('Viraj_Synced',voice),('Music_and_Effects',bed+fx*.72),('Final_Mix',mix)]:wavfile.write(ROOT/f'audio/{name}.wav',SR,(np.clip(data,-1,1)*32767).astype(np.int16))
 (ROOT/'output/Doosra_Helmet_Hinglish.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(r["start"])} --> {stamp(r["end"])}\n{r["caption"]}' for i,r in enumerate(rows))+'\n')
 (ROOT/'output/qa_audio.json').write_text(json.dumps(dict(duration=60,samples=len(mix),peak_dbfs=float(20*np.log10(np.max(np.abs(mix)))),voice_speed_changed=False,finite=bool(np.isfinite(mix).all())),indent=2))
 print('60 seconds, natural voice speed, peak',20*np.log10(np.max(np.abs(mix))))
if __name__=='__main__':main()
