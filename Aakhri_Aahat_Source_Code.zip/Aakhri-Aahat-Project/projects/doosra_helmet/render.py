"""Doosra Helmet: exactly 1800 frames at 30 fps. Native flat 2D geometry, 4K master."""
from pathlib import Path
import math,json,sys,subprocess
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from scipy.io import wavfile
import primitives as g
from primitives import C,limb,ease,lerp
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
g.SCALE=3 if '--4k' in sys.argv else 1.5
W,H=int(720*g.SCALE),int(1280*g.SCALE);FPS=30;DURATION=60
P={'bg':'#0B0B0D','wall':'#222226','floor':'#343236','edge':'#797577','red':'#C62828','light':'#FF625A','white':'#F5F0E6','skin':'#BD957F','grey':'#aaa29e'}
T=json.loads((ROOT/'timeline.json').read_text()) if (ROOT/'timeline.json').exists() else []
audio_path=ROOT/'audio/Viraj_Synced.wav'
if audio_path.exists():
 sr,v=wavfile.read(audio_path);v=v.astype(float)/32768
else:sr=48000;v=np.zeros(sr*60)
FONT_CACHE={}
def txt(c,xy,s,size=26,col=None,bold=False,mono=False):
 key=(round(size*c.s*g.SCALE),bold,mono)
 if key not in FONT_CACHE:
  path='/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf' if mono else ROOT/'fonts'/('Mukta-ExtraBold.ttf' if bold else 'Mukta-Regular.ttf')
  FONT_CACHE[key]=ImageFont.truetype(str(path),max(1,key[0]))
 c.d.text(c.pt(xy),s,font=FONT_CACHE[key],fill=col or P['white'],anchor='mm')
def amplitude(t):
 a=int(max(0,t)*sr);b=min(len(v),a+1200)
 return min(1,float(np.sqrt(np.mean(v[a:b]**2)))*10) if b>a else 0

def helmet(c,x,y,s=1,red=True,empty=False,t=0,closed=True):
 c=c.group(x,y,s);col='#aa293a' if red else '#30313a'
 c.ellipse((-53,-64,53,48),col,'#d15a63' if red else '#79727a',3)
 c.round((-37,-37,39,43),17,'#0b0c12' if empty else P['skin'])
 c.line([(-44,-27),(-30,-47),(28,-47),(45,-25)],'#ec8b87' if red else '#aaa0a3',3)
 c.line([(-45,22),(-41,52)],'#1d1921',9);c.line([(46,22),(42,52)],'#1d1921',9)
 if empty:
  u=ease((t-51.8)/.8) if not closed else 1
  a=lerp(-31,-3,u);b=lerp(31,3,u)
  c.line([(-41,48),(a,75)],'#aba3a4',6);c.line([(42,48),(b,75)],'#aba3a4',6)
  c.round((a-8,69,a+5,80),2,'#bc3c4b');c.round((b-5,69,b+7,80),2,'#77727c')
 else:
  c.line([(-41,42),(-20,60),(20,60),(42,42)],'#16141b',6)

def face(c,x,y,t,s=1,passenger=False,scared=False,talk=False,headgear=True,gaze=0):
 c=c.group(x,y,s)
 if headgear:helmet(c,0,0,1,passenger)
 else:
  c.ellipse((-35,-55,35,45),P['skin']);c.poly([(-34,-16),(-35,-45),(-16,-65),(19,-63),(36,-38),(29,-21),(17,-38),(-22,-31)],'#17141b')
 for xx in [-14,14]:
  c.line([(xx-7,-15-(3 if xx<0 and scared else 0)),(xx+7,-15-(3 if xx>0 and scared else 0))],'#4a3437',3)
  if t%4.2>4.04:c.line([(xx-5,-5),(xx+5,-5)],'#35282d',2)
  else:
   c.ellipse((xx-7,-10,xx+7,3),'#f1e3d1');c.ellipse((xx-2+gaze*3,-7,xx+3+gaze*3,1),'#25212b')
 c.line([(1,1),(5,12),(0,14)],'#976f60',2)
 mouth=amplitude(t) if talk else .3 if scared else 0
 if mouth>.1:c.ellipse((-7,24,7,28+mouth*13),'#44242c')
 else:c.line([(-8,26),(8,26)],'#76504d',2)
 if scared:c.line([(29,11),(33,20)],'#e4bdad',2)

def street(c,t,moving=True,hospital=False):
 c.rect((0,0,720,1280),'#101118');c.ellipse((568,95,619,146),'#a89e9d')
 offset=t*65 if moving else 0
 for j in range(7):
  x=(j*137-offset*.22)%1000-140;h=150+(j%3)*59
  c.rect((x,475-h,x+116,684),'#24212a')
  for xx in [x+23,x+63]:
   for yy in range(int(495-h),620,61):c.rect((xx,yy,xx+20,yy+28),'#49343f' if j%3 else '#796052')
 if hospital:
  c.rect((60,245,660,735),'#38303a');c.rect((86,274,635,354),'#191921');txt(c,(360,316),'HOSPITAL',43,P['white'],True)
  c.rect((277,458,449,735),'#101218');c.line([(363,459),(363,730)],'#736671',3)
  for xx in [103,495]:
   for yy in [390,535]:c.rect((xx,yy,xx+111,yy+83),'#141921');c.line([(xx,yy+41),(xx+111,yy+41)],'#574651',3)
  c.poly([(225,448),(502,448),(470,417),(259,417)],'#7b293b')
 c.rect((0,741,720,1280),'#26232b');c.rect((0,711,720,751),'#766570');c.rect((0,717,720,735),'#443941')
 for j in range(5):
  x=(j*210-offset*2)%1100-200;c.poly([(x,1097),(x+112,1097),(x+152,1123),(x+33,1123)],'#95878a')
 for j in range(3):
  x=(j*400-offset*.7)%1200-200
  c.line([(x,719),(x,221),(x+72,221)],'#625663',7);c.ellipse((x+45,219,x+94,235),'#d1aaa1')
  c.poly([(x+56,238),(x-38,710),(x+212,710),(x+86,238)],'#211c25')

def wheel(c,x,y,t,moving=True):
 c.ellipse((x-79,y-79,x+79,y+79),'#0a0b10','#797079',7);c.ellipse((x-55,y-55,x+55,y+55),'#27272e','#ae9da0',4)
 for k in range(8):
  a=k*math.pi/4+(t*7 if moving else 0);c.line([(x,y),(x+53*math.cos(a),y+53*math.sin(a))],'#887c87',3)
 c.ellipse((x-12,y-12,x+12,y+12),'#c2acac')

def bike(c,t,passenger=True,moving=True,extra=False,helmet_on_seat=False,rise=0):
 bob=math.sin(t*22)*1.5 if moving else 0;c=c.group(0,bob)
 # Wheels, chassis, engine, mudguards, controls.
 wheel(c,170,980,t,moving);wheel(c,548,980,t,moving)
 c.line([(170,980),(269,852),(405,852),(548,980),(340,980),(269,852)],'#8f737e',12)
 c.line([(170,980),(340,980)],'#79727b',12)
 c.round((284,898,386,977),14,'#59545d');
 for yy in range(908,969,12):c.line([(296,yy),(376,yy)],'#25222b',4)
 c.poly([(365,811),(445,805),(469,853),(388,883),(333,853)],'#9b2a3b');c.line([(379,821),(435,817)],'#e16a72',4)
 c.round((182,814,372,838),9,'#12131a','#6d5a65',3)
 c.line([(492,760),(548,980)],'#ac919a',13);c.line([(445,744),(497,753),(511,775)],'#a48e99',7)
 c.line([(486,754),(467,682)],'#a48e99',4);c.round((438,662,484,692),8,'#625c6b','#b294a0',3)
 c.ellipse((491,782,534,836),'#dfc8aa');c.round((124,845,163,864),4,'#e34454')
 c.line([(172,1003),(310,1003)],'#a197a1',12)
 # Rider leans toward controls; joints absorb road vibration.
 limb(c,(358,797),(426,872),'#28232e',35);limb(c,(426,872),(392,951),'#28232e',30);c.round((366,942,423,962),6,'#b4a39d')
 c.poly([(338,632),(413,628),(423,791),(359,825),(321,800)],'#702938')
 c.line([(372,641),(377,764)],'#a3525f',3)
 c.round((368,604,397,641),7,P['skin']);face(c,383,565,t,1.12,scared=extra,gaze=1,talk=14<t<16 or 20<t<24)
 limb(c,(410,657),(448,713),'#702938',25);limb(c,(448,713),(494,750),P['skin'],18)
 c.ellipse((482,742,508,761),P['skin'])
 if passenger:
  limb(c,(247,802),(280,891),'#39313a',34);limb(c,(280,891),(244,964),'#39313a',28);c.round((221,953,270,972),6,'#8a7c7c')
  c.poly([(209,610),(279,605),(301,799),(238,822),(196,794)],'#958578')
  c.line([(244,626),(254,780)],'#64545a',2);face(c,244,543,t,1.05,passenger=True,gaze=1,talk=12<t<14 or 17<t<20 or 24<t<28)
  limb(c,(275,635),(307,743),'#958578',23);limb(c,(307,743),(362,766),P['skin'],17)
 if extra:
  for yy in [774,804]:
   c.round((330,yy,383,yy+14),7,'#897c88');
   for j in range(3):c.line([(350+j*8,yy+3),(353+j*8,yy+11)],'#514653',1)
 if helmet_on_seat:helmet(c,246,770-rise,1,True,True,t,False)

def standing(c,x,y,t,hand=(65,-140),talk=False):
 c=c.group(x,y)
 for xx in [-22,22]:
  limb(c,(xx,-142),(xx,-15),'#3a313c',27);c.round((xx-14,-18,xx+26,0),5,'#9a8985')
 c.round((-43,-264,43,-139),12,'#958578');c.line([(0,-250),(0,-151)],'#60515a',2)
 c.round((-13,-289,13,-260),5,P['skin']);face(c,0,-321,t,1,passenger=True,headgear=False,gaze=-1,talk=talk)
 limb(c,(-39,-244),(-62,-187),'#958578',22);limb(c,(-62,-187),(-54,-144),P['skin'],16)
 limb(c,(40,-242),(hand[0]*.65,-196),'#958578',22);limb(c,(hand[0]*.65,-196),hand,P['skin'],16)

def mirror_shot(c,t):
 street(c,t);c.line([(124,1000),(284,800)],'#9e8590',24)
 c.round((57,300,662,820),83,'#111219','#ab6574',13);c.round((80,324,638,796),65,'#3b303d')
 # Only the ordinary passenger is visible in the mirror.
 c.poly([(179,790),(210,542),(459,542),(521,790)],'#8d7a72');face(c,346,493,t,2.55,passenger=True,gaze=-.6)
 c.line([(112,375),(152,345)],'#7e6778',5)

def hands_shot(c,t):
 c.rect((0,0,720,1280),'#19171e');c.poly([(132,184),(561,184),(622,1045),(95,1045)],'#712b3c')
 c.line([(355,203),(361,997)],'#ad5262',5);c.round((218,731,503,917),22,'#542334')
 # Two ordinary hands, then two unmistakably separate spectral hands.
 for side in [-1,1]:
  xx=144 if side<0 else 475;yy=500
  c.round((xx-95,yy-34,xx+92,yy+34),24,P['skin']);c.round((xx-15,yy-53,xx+48,yy-11),16,P['skin'])
  for j in range(4):c.line([(xx+side*20,yy-20+j*14),(xx+side*78,yy-20+j*14)],'#95695f',2)
 u=ease((t-31)/.65)
 for side in [-1,1]:
  xx=lerp(-100,180,u) if side<0 else lerp(820,468,u);yy=650
  c.round((xx-97,yy-31,xx+97,yy+31),24,'#a69ba9');c.round((xx-18,yy-50,xx+46,yy-9),16,'#a69ba9')
  for j in range(4):c.line([(xx+side*20,yy-20+j*13),(xx+side*77,yy-20+j*13)],'#615566',2)

def outro(c,t):
 c.rect((0,0,720,1280),P['bg']);c.line([(90,223),(630,223)],P['red'],4)
 txt(c,(360,375),'SUBSCRIBE',78,P['red'],True);txt(c,(360,462),'karein',45)
 txt(c,(360,658),'FACEBOOK',56,P['white'],True);txt(c,(360,724),'aur',29)
 txt(c,(360,791),'INSTAGRAM',56,P['white'],True);txt(c,(360,912),'pe FOLLOW karein',44,P['light'],True)

def frame(t):
 im=Image.new('RGB',(W,H),P['bg']);c=C(im)
 if t>=54:outro(c,t);return im
 if t<7:
  street(c,t,False,True);bike(c,t,False,False,helmet_on_seat=True)
  standing(c,134,963,t,hand=(110,-174),talk=t>3)
 elif t<12:
  street(c,t,False,True);bike(c,t,False,False)
  u=ease((t-7)/2);standing(c,lerp(95,226,u),976,t,hand=(58,-211))
  if t>9.7:
   # Cut to mounted passenger, continuity keeps the red helmet.
   street(c,t,True,True);bike(c,t,True,True)
  else:helmet(c,lerp(153,244,u),lerp(765,565,u),1,True,True,t)
 elif t<28:
  street(c,t);bike(c,t,True,True)
 elif t<30.7:mirror_shot(c,t)
 elif t<35:hands_shot(c,t)
 elif t<41:
  u=ease((t-35)/1.3);street(c,t,not t>36.3)
  if t<37:bike(c,t,True,t<36.3)
  else:
   bike(c,t,False,False)
   k=ease((t-37)/2);standing(c,lerp(240,118,k),lerp(967,1050,k),t,hand=(lerp(20,118,k),-190))
   helmet(c,246,lerp(564,770,ease((t-37)/2.2)),1,True,True,t,False)
 elif t<46:
  street(c,t,False);bike(c,t,False,False,helmet_on_seat=True)
  standing(c,118,1050,t,hand=(124,-200),talk=t<43.4)
 elif t<50.5:
  street(c,t,False);bike(c,t,False,False,helmet_on_seat=True,rise=210*ease((t-47.8)/2.2))
  standing(c,118,1050,t,hand=(124,-200))
 else:
  street(c,t,False);c.rect((0,0,720,1280),'#121016')
  # Close-up: empty opening remains visibly empty as both buckle halves join.
  c.round((93,966,625,1016),18,'#38303c','#6e4b5c',3)
  helmet(c,360,590,3.6,True,True,t,False)
  if t>53.3:im=Image.new('RGB',(W,H),P['bg'])
 c=C(im);r=next((r for r in T if r['start']<=t<r['end']),None)
 if r:
  lines=r['caption'].split('\n');h=44*len(lines)+36;c.round((32,1177-h,688,1177),10,P['bg'])
  for i,line in enumerate(lines):txt(c,(360,1177-h+35+i*44),line,32,P['white'])
 return im

def preview():
 times=[3,8.5,11,18,25,29,33,38,42,49,52.8,56]
 sheet=Image.new('RGB',(1200,730),P['bg']);d=ImageDraw.Draw(sheet)
 for i,t in enumerate(times):
  im=frame(t);im.save(OUT/f'qa_{t}.jpg',quality=90);x=i%6*200;y=i//6*365
  sheet.paste(im.resize((200,356)),(x,y));d.text((x+7,y+349),str(t)+'s',fill='white')
 sheet.save(OUT/'contact_sheet.jpg',quality=92)

def render():
 name='Doosra_Helmet_4K.mp4' if '--4k' in sys.argv else 'Doosra_Helmet_1080p.mp4'
 p=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{W}x{H}','-framerate','30','-i','pipe:0','-i',str(ROOT/'audio/Final_Mix.wav'),'-c:v','libx264','-threads','4','-preset','veryfast','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-movflags','+faststart','-t','60',str(OUT/name)],stdin=subprocess.PIPE)
 for i in range(1800):
  p.stdin.write(frame(i/30).tobytes())
  if i%150==0:print(f'{i/30:.0f}/60 seconds rendered',flush=True)
 p.stdin.close();assert p.wait()==0;print('Complete',flush=True)
if __name__=='__main__':
 if '--preview' in sys.argv:preview()
 if '--render' in sys.argv:render()
