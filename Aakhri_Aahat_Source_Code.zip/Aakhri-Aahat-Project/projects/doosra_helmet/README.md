# Doosra Helmet

Original fictional Hindi horror short. 60 seconds, 30 fps, vertical 9:16.

## Deliverables
- output/Doosra_Helmet_4K.mp4 — native 2160 x 3840 render
- output/Doosra_Helmet_1080p.mp4 — 1080 x 1920 sharing version
- output/Doosra_Helmet_Hinglish.srt — plain centered Roman Hindi captions
- Thumbnail_9x16.png — illustrated black/crimson cover
- output/Doosra_Helmet_Social_Media.md — YouTube, Instagram and Facebook copy

## Rebuild
Python 3 with Pillow, NumPy and SciPy, plus ffmpeg.
Run `python prepare.py` then `python render.py --4k --render`.
For native 1080p use `python render.py --render`.
For scene previews use `python render.py --preview`.

## Editable components
- render.py: original flat 2D geometry and animation, jointed riding/standing poses, helmet, buckle, wheels, mirror and hand reveal.
- primitives.py: drawing helpers.
- prepare.py: source audio cuts, pauses, Roman Hindi caption wording, original synthesized motor, road, brake, footsteps, clothing, buckle and tension bed.
- timeline.json and edit.json: caption timing and source-to-final audio mapping.
- Narration_Hindi.txt: final Hindi narration with performance directions.
- audio/word_timings.json: timing reference; bracketed directions are not captions.
- audio/Viraj_original.mp3: ElevenLabs eleven_v4, Viraj - Deep, Suspenseful and Mysterious.
- audio/Viraj_Synced.wav: original-speed voice with edited pauses.
- audio/Music_and_Effects.wav and audio/Final_Mix.wav: 48 kHz stereo stems/mix.
- fonts/: Mukta fonts and open font license.

## Creative standards
Black/crimson palette. Regular-weight, off-white captions without highlights. No channel name on screen. SUBSCRIBE, FACEBOOK, INSTAGRAM and FOLLOW are bold on the closing card. Cover is a detailed illustration; movie is flat 2D motion graphics.

## Story staging
The rider collects a passenger from an empty hospital. An unsettling conversation leads to a mirror close-up, then four hands around his waist. After braking, the passenger leaves the red helmet on the rear seat. It rises while visibly empty, and its buckle joins by itself. A short silence leads into the six-second closing card.

## Verification
Caption bounds, segment lengths and audio peak checked before render. Final video checks: exactly 1800 frames at 30 fps, 60-second duration, correct vertical dimensions, full ffmpeg decode without errors.
