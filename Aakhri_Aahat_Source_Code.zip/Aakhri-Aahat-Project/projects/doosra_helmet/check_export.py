from pathlib import Path
import subprocess,json,zipfile
root=Path(__file__).resolve().parent
reports=[]
for name in ['Doosra_Helmet_4K.mp4','Doosra_Helmet_1080p.mp4']:
 p=root/'output'/name
 r=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)]))
 video=next(s for s in r['streams'] if s['codec_type']=='video')
 assert float(r['format']['duration'])==60
 assert video['nb_frames']=='1800'
 assert video['r_frame_rate']=='30/1'
 assert video['width']*16==video['height']*9
 subprocess.run(['ffmpeg','-v','error','-i',str(p),'-f','null','-'],check=True)
 reports.append(dict(file=name,duration=60,frames=1800,width=video['width'],height=video['height'],decode='passed'))
(root/'output/export_checks.json').write_text(json.dumps(reports,indent=2))
print(json.dumps(reports,indent=2))
