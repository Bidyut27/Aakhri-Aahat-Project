# Chhat Par Maa

74-second original fictional Hindi horror short. Vertical 9:16, 24 fps.

## Deliverables

- Native 2160 × 3840 MP4 and 1080 × 1920 MP4, AAC stereo.
- Matching 2160 × 3840 thumbnail, plain Hinglish SRT and posting copy.
- Editable Python scene rig, timeline, voice sources and bundled Mukta fonts.

## Reproduce

Requires Python 3.10+, FFmpeg on PATH, and the packages in requirements.txt.

```bash
pip install -r requirements.txt
python render.py --render --4k
python render.py --render
python thumbnail.py
```

The supplied MP3 clips allow offline rendering. `python voices.py` regenerates speech through Edge TTS and requires internet access. It replaces voice clips/timing; inspect scene and caption timing after regenerating. Narrator: hi-IN-MadhurNeural. Female dialogue: hi-IN-SwaraNeural. No ElevenLabs calls or credits are used by this project.

## Animation and audio

Articulated procedural 2D animation: walking limbs, hand reach, phone poses, eye direction, cloth movement, hinged door and appearing footprints. This is a rigged cartoon production, not traditional hand-drawn frame-by-frame animation. Scene cuts and camera framing are controlled in render.py.

The mother is heard over a filtered phone line; the impersonating voice receives stairwell echoes. Footsteps, cloth, ring, door slam and wet steps are synthesized locally with NumPy/SciPy. Dialogue and effects are mixed separately before export. Subtitles are phrase-timed from the measured voice durations, not word-aligned. Story video contains no CTA or branding.

Font license is included in fonts/. The story is fictional and should not be described as a real incident.
