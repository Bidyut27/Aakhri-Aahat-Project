from pathlib import Path
import math
from PIL import ImageFont
import primitives as g
from primitives import C,limb,ease,lerp
ROOT=Path(__file__).resolve().parent
INK='#101c26'; SKIN='#ba896c'; LIGHT='#ddb193'; SHADE='#875c50'; FONT={}
def txt(c,xy,text,size=25,fill='#eee9df',bold=False):
 k=(round(size*c.s*g.SCALE),bold)
 if k not in FONT:FONT[k]=ImageFont.truetype(str(ROOT/'fonts'/('Mukta-Bold.ttf' if bold else 'Mukta-Regular.ttf')),max(1,k[0]))
 c.d.text(c.pt(xy),text,font=FONT[k],fill=fill,anchor='mm',stroke_width=0)

def E(t,a,b):return ease((t-a)/(b-a))

def mix(a,b,v):return tuple(lerp(x,y,v) for x,y in zip(a,b))

def outlined(c,pts,col,w=2):
 c.poly(pts,col);c.line(pts+[pts[0]],INK,w)

def stroke(c,a,b,col,w):limb(c,a,b,INK,w+4);limb(c,a,b,col,w)

def arm(c,shoulder,hand,side=1):
 # Analytic two-link inverse kinematics keeps wrists attached to targets.
 dx,dy=hand[0]-shoulder[0],hand[1]-shoulder[1];d=max(.01,math.hypot(dx,dy));L=65
 d=min(d,129);mid=((shoulder[0]+hand[0])/2,(shoulder[1]+hand[1])/2)
 h=math.sqrt(max(0,L*L-d*d/4)); elbow=(mid[0]-side*dy/max(d,1)*h,mid[1]+side*dx/max(d,1)*h)
 stroke(c,shoulder,elbow,'#713346',28);stroke(c,elbow,hand,SKIN,20)
 c.line([mix(elbow,hand,.08),mix(elbow,hand,.23)],'#c3a19a',4)
 return hand

def hand(c,x,y,raised=False,grip=False):
 c.ellipse((x-11,y-12,x+11,y+13),SKIN,INK,2)
 if raised:
  for i in range(4):
   xx=x-8+i*5;end=y-25-(3 if i in (1,2) else 0)
   stroke(c,(xx,y-5),(xx-2+i,end),LIGHT,4)
  stroke(c,(x+7,y+3),(x+17,y-7),SKIN,5)
 else:
  for i in range(3):c.line([(x-5+i*5,y+1),(x-6+i*5,y+8)],SHADE,1)

def head(c,x,y,t,fear=0,look=0,smile=0,talk=0):
 c=c.group(x,y)
 c.ellipse((-45,-13,-28,19),SKIN,INK,2);c.ellipse((29,-13,44,19),SHADE,INK,2)
 outlined(c,[(-36,-51),(-17,-68),(19,-65),(37,-40),(35,26),(18,49),(-8,51),(-32,31)],SKIN)
 c.poly([(16,-61),(36,-40),(35,26),(18,49),(4,49),(20,22),(23,-23)],SHADE)
 c.poly([(-31,8),(-23,32),(-5,45),(15,42),(29,22),(32,33),(17,50),(-8,51),(-30,30)],'#634e49')
 outlined(c,[(-39,-9),(-47,-43),(-31,-68),(-3,-77),(18,-86),(37,-73),(42,-48),(34,-27),(24,-42),(3,-48),(-15,-32),(-30,-34),(-29,-7)],'#18222b')
 c.line([(-35,-49),(-14,-60),(9,-65),(26,-70)],'#3a4650',3)
 c.line([(-30,-58),(-4,-69),(19,-76)],'#4b5059',2)
 blink=1-E(t%4.8,4.60,4.68)+E(t%4.8,4.72,4.80)
 for xx in (-16,16):
  if blink<.4:c.line([(xx-10,-11),(xx+10,-11)],INK,3)
  else:
   c.ellipse((xx-11,-20-fear*2,xx+11,-4+fear*4),'#e8e5d8',INK,2)
   gx=xx+look*5;c.ellipse((gx-4,-18,gx+4,-5),'#172d34');c.ellipse((gx-2,-17,gx,-13),'#f4f2e8')
  c.line([(xx-11,-26-fear*5),(xx,-30-fear*5),(xx+9,-26)],'#24242a',4)
 c.line([(2,-8),(7,8),(-1,11)],SHADE,2)
 if smile>.1:
  c.line([(-14,25),(-7,29+smile*4),(5,29+smile*4),(17,22)],'#392b32',3)
  if talk>.1:c.ellipse((-7,28,8,30+talk*11),'#35252e')
 elif talk>.08 or fear>.6:
  c.ellipse((-9,24,10,28+max(talk*15,fear*9)),'#35252e',INK,1)
 else:c.line([(-10,29),(1,27),(11,29)],'#573e3c',2)
 for xx,yy in [(-23,23),(-18,29),(-13,35),(-7,40),(5,40),(13,36),(23,26)]:c.line([(xx,yy),(xx+1,yy+3)],'#38343a',1)
 if fear>.6:
  c.poly([(31,-12),(27,4),(31,10),(35,5)],'#b7d1cd')

def phone(c,x,y,angle=0):
 # Rotated polygon keeps the phone rigid during the fall.
 def tr(a,b):return (x+a*math.cos(angle)-b*math.sin(angle),y+a*math.sin(angle)+b*math.cos(angle))
 outlined(c,[tr(-14,-29),tr(14,-29),tr(14,29),tr(-14,29)],'#14232c',2)
 c.poly([tr(-10,-23),tr(10,-23),tr(10,21),tr(-10,21)],'#517b80')
 c.ellipse((*tr(-3,12),*tr(3,18)),'#d25155') if abs(angle)<.01 else None