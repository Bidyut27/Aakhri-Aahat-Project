"""Chhat Par Maa. Native Python 2D, 74 seconds, 24 fps. No generated video.
Run voices.py once, then render.py --render --4k or --render for 1080p.
"""
from pathlib import Path
import math,json,sys,subprocess,uuid
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter,sosfilt
from PIL import Image,ImageDraw,ImageFont
import primitives as g
from primitives import C,ease,lerp,limb
from rig import head,hand,outlined,stroke,phone,txt,E,mix
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
g.SCALE=3 if '--4k' in sys.argv else 1.5
W,H=int(720*g.SCALE),int(1280*g.SCALE);FPS=24;DUR=74;SR=48000
INK='#111a2b';IVORY='#f0e5cd';RED='#a52d45';GOLD='#c7a462'
T=json.loads((ROOT/'timeline.json').read_text());CAP=[]
for q in T:
 parts=q['subtitle'].split('|');weights=[len(s) for s in parts];total=sum(weights);start=q['start']
 for s,n in zip(parts,weights):
  length=q['duration']*n/total;CAP.append((start,start+length,s));start+=length

def poly(c,pts,col):outlined(c,pts,col,2)
def limb2(c,a,b,col,w):stroke(c,a,b,col,w)
def aarav(c,x,y,s,t,pose='idle',fear=.25,look=0):
 c=c.group(x,y,s);walk=pose=='walk';phase=t*7.4
 bob=abs(math.sin(phase))*3 if walk else math.sin(t*2)*1
 c.ellipse((-52,-4,60,10),'#121f2b')
 for sign in (-1,1):
  swing=math.sin(phase)*22*sign if walk else 0
  hip=(sign*19,-146);knee=(sign*21+swing*.5,-76-abs(swing)*.2);foot=(sign*23+swing,-12)
  limb2(c,hip,knee,'#344450',28);limb2(c,knee,foot,'#263542',24)
  c.round((foot[0]-15,-20,foot[0]+26,0),6,'#162130',INK,2);c.line([(foot[0]-11,-4),(foot[0]+22,-4)],'#8b8c80',2)
 c=c.group(0,-bob)
 poly(c,[(-42,-273),(35,-276),(44,-159),(26,-145),(-35,-146),(-44,-169)],'#a57c41')
 c.poly([(25,-271),(35,-276),(44,-159),(26,-145),(24,-195)],'#765735')
 c.line([(-26,-175),(0,-183),(28,-172)],'#d3ab65',2)
 c.rect((-12,-297,13,-272),'#ba896c')
 poly(c,[(-19,-275),(-1,-259),(-13,-242),(-29,-271)],'#cfaa66')
 poly(c,[(18,-277),(-1,-259),(13,-243),(28,-271)],'#d6b474')
 c.line([(0,-258),(1,-151)],'#d6b474',2)
 for yy in (-227,-201,-175):c.ellipse((-1,yy,3,yy+4),'#e4c895')
 c.round((14,-241,32,-221),2,'#8a6739');c.line([(15,-237),(31,-237)],'#d3ad6b',2)
 left=(-49,-144);right=(49,-144)
 if walk:left=(-52,-161+math.sin(phase)*17);right=(52,-161-math.sin(phase)*17)
 if pose in ('reach','freeze'):
  v=E(t,18,20);right=mix(right,(108,-307),v);left=(-49,-151)
 if pose in ('phone','turn','fear','slam'):
  left=(-55,-309)
 if pose=='slam':right=(120,-248)
 if pose=='fear':right=(75,-246)
 # Explicit elbow placement for readable action and hand contact.
 for sign,h in [(-1,left),(1,right)]:
  sh=(sign*36,-261)
  elbow=(sign*53,-204)
  if h[1]<-280:elbow=(sign*79,-232)
  if pose=='slam' and sign==1:elbow=(76,-240)
  limb2(c,sh,elbow,'#a57c41',25);limb2(c,elbow,h,'#ba896c',18)
  c.line([mix(elbow,h,.08),mix(elbow,h,.22)],'#d6b474',4)
  hand(c,*h,raised=pose in ('reach','freeze','fear') and sign==1)
 if pose in ('phone','turn','fear','slam'):phone(c,left[0],left[1]-4)
 head(c,look*7,-325,t,fear,look)

def sky(c,t):
 c.rect((-200,-200,1000,1400),'#101b30')
 for i in range(35):
  xx=(i*117+23)%780;yy=(i*71)%430
  c.ellipse((xx,yy,xx+1.4,yy+1.4),'#708895' if i%3 else '#b1b8b4')
 c.ellipse((545,118,627,200),'#b7c8bc');c.ellipse((563,109,640,188),'#101b30')
 # Fixed distant skyline: no wind animations anywhere except the sari.
 for i in range(13):
  x=-40+i*67;top=400-(i*37)%145
  c.rect((x,top,x+61,595),'#1a293b');c.rect((x-3,top-4,x+64,top+3),'#2a3b4a')
  for row in range(4):
   for col in range(2):
    if (i+row+col)%3==0:c.rect((x+12+col*24,top+24+row*33,x+23+col*24,top+38+row*33),'#8c805a')
 c.poly([(-100,626),(820,626),(820,1400),(-100,1400)],'#354653')
 for yy in (665,720,800,910,1075,1300):c.line([(-100,yy),(820,yy)],'#536270',1)
 for i in range(-4,10):c.line([(360+(i-3)*50,626),(360+(i-3)*220,1400)],'#465865',1)
 c.rect((-100,540,820,629),'#445967');c.rect((-100,535,820,548),'#7d8b88')
 c.line([(-100,625),(820,625)],'#18283a',4)
 # Water tank, pipe, aerial and quiet laundry establish a lived-in roof.
 c.line([(585,423),(585,526),(613,526),(613,624)],'#6a7f84',8)
 c.round((518,358,670,510),30,'#172938','#536c74',2)
 for yy in (388,419,450,482):c.line([(525,yy),(663,yy)],'#3c5361',3)
 c.ellipse((518,346,670,380),'#304957','#0e1c2d',2)
 c.line([(440,400),(440,285)],'#68838c',3)
 for yy in (303,323,343):c.line([(418,yy),(462,yy)],'#68838c',2)

def stair(c,t,close=0):
 # Door pivots about its left hinge; space beyond remains dark.
 poly(c,[(25,365),(233,355),(252,770),(20,793)],'#53606b')
 c.rect((47,403,217,765),'#101726');c.poly([(47,765),(217,765),(253,840),(22,840)],'#202633')
 for i in range(5):
  y=670+i*24;c.poly([(49,y),(214,y),(220,y+15),(43,y+15)],'#393640');c.line([(45,y+15),(220,y+15)],'#6c5454',2)
 c.rect((48,408,214,500),'#211e2b')
 op=1-close;w=154*(1-op*.9);dy=op*35
 poly(c,[(47,403),(47+w,403+dy),(47+w,766-dy),(47,766)],'#42313a')
 c.line([(57,420),(40+w,420+dy),(40+w,740-dy)],'#816465',2)
 if w>45:
  c.line([(w+20,587),(w+3,587)],'#c8ae79',4)
 c.round((84,371,137,391),5,'#b19055');c.ellipse((102,389,119,409),'#e2cb8d')
 c.poly([(109,408),(54,520),(191,519)],'#58494a')

def sari(c,t,x=340,y=350,scale=1,empty=False):
 c=c.group(x,y,scale)
 c.line([(-95,0),(310,-15)],'#a7aaa0',3)
 c.line([(-92,0),(-92,430)],'#647d86',7);c.line([(307,-15),(307,420)],'#647d86',7)
 # A still towel beside visibly moving sari.
 poly(c,[(203,-12),(272,-13),(272,160),(203,159)],'#8f9e9a')
 for xx in (214,263):c.line([(xx,-10),(xx,159)],'#b7b9aa',2)
 if not empty:
  sway=math.sin(t*2.1)*15+math.sin(t*3.2)*4
  pts=[(5,-4),(152,-9)]
  pts += [(152+math.sin(t*2.1+i*.6)*i*2.8,-9+i*28) for i in range(1,12)]
  pts += [(8+math.sin(t*2.1+i*.6)*i*2.8,-4+i*28) for i in range(11,-1,-1)]
  poly(c,pts,RED)
  for off in (25,58,91,124):
   c.line([(off+math.sin(t*2.1+i*.6)*i*2.8,i*28-5) for i in range(12)],'#cd4b59' if off%2 else '#762b45',3)
  c.line([(8+sway,284),(150+sway,281)],GOLD,10)
  c.line([(8+sway,295),(150+sway,292)],'#ebc480',2)
  for i in range(9):c.ellipse((17+i*15+sway,279,21+i*15+sway,283),'#efd09b')
 for xx in (17,140):
  angle=math.sin(t*3)*4 if empty else 0
  c.line([(xx,-15),(xx+angle,9)],GOLD,7);c.line([(xx,-15),(xx,9)],'#e0c28a',2)

def rooftop(c,t,empty=False):
 sky(c,t);stair(c,t,E(t,45,46));sari(c,t,350,350,.95,empty)
 # Drain and small puddle with a cold reflection.
 c.poly([(550,1007),(619,1000),(638,1029),(567,1037)],'#152b38')
 for i in range(5):c.line([(558+i*12,1006),(573+i*12,1032)],'#809298',2)
 c.ellipse((452,1060,548,1081),'#223e4d');c.line([(470,1068),(526,1067)],'#65818a',1)

def phone_insert(c,t):
 c.rect((-100,-100,820,1400),'#192b3d')
 # Forearm and fingers wrap the phone rather than float behind it.
 poly(c,[(118,1280),(178,950),(190,610),(257,555),(292,654),(264,1011),(239,1280)],'#b9896c')
 c.round((205,240,568,1005),40,'#0c1725','#71878c',4)
 c.round((225,266,548,982),26,'#294553')
 c.round((330,274,439,294),7,'#0b1b29')
 c.ellipse((325,365,448,488),'#5e7376')
 # Illustrated mother avatar, seen on the incoming/active call screen.
 c.ellipse((353,383,423,457),'#272638');c.ellipse((366,397,410,449),'#c5a18b')
 c.poly([(352,466),(367,440),(407,440),(425,468)],'#7d4552')
 txt(c,(386,551),'MAA',39,IVORY,True)
 txt(c,(386,601),'CALLING...' if t<24.3 else 'CONNECTED',18,'#bacac7')
 c.ellipse((346,814,426,894),'#a73c4d');c.line([(365,858),(375,846),(396,846),(408,858)],'#f0e4d4',8)
 for i in range(4):
  yy=690+i*67;c.round((184,yy,244,yy+39),18,'#c69a7e','#76574c',2)
 c.line([(263,1005),(282,1280)],'#815b4d',3)
 if t<24.3:
  pulse=math.sin(t*22)*4
  c.line([(588+pulse,430),(601+pulse,454),(588+pulse,478)],'#b6b996',3)
  c.line([(611+pulse,414),(631+pulse,454),(611+pulse,494)],'#7c9491',2)

def footprint(c,x,y,s,alpha=1,side=1):
 c=c.group(x,y,s)
 col='#172f3c' if alpha>.5 else '#2a414e'
 c.ellipse((-13,-17,12,19),col);c.ellipse((-11,12,10,39),col)
 for i in range(5):
  xx=-12+i*6;c.ellipse((xx,-27+i*1.4,xx+5,-20+i*1.4),col)
 c.line([(-8,15),(-8,29)],'#6c8b90',1)
def floor_scene(c,t):
 c.rect((-100,-100,820,1400),'#2d414e')
 for yy in range(-20,1400,145):c.line([(-100,yy),(820,yy)],'#536672',3)
 for xx in range(-100,900,145):c.line([(xx,-100),(xx,1400)],'#536672',3)
 for i,at in enumerate((60.4,61.6,62.8,64.0,65.2)):
  if t>=at:footprint(c,320+(i%2)*80,170+i*130,1+i*.15,E(t,at,at+.2),(-1)**i)
 # Aarav's shoes at the near end of the approaching footprints.
 for xx in (250,405):
  c.poly([(xx-28,1280),(xx-34,995),(xx+36,995),(xx+30,1280)],'#30404b')
  c.round((xx-40,928,xx+45,1030),24,'#162231',INK,3);c.line([(xx-30,940),(xx+30,940)],'#86908b',3)
 if t>65.3:
  v=E(t,65.3,66.3);c.poly([(600,0),(820,0),(820,1110),(680-v*110,1110)],'#972e44')
  c.line([(690-v*110,1090),(820,1090)],GOLD,12)

def caption(im,t):
 d=ImageDraw.Draw(im)
 for a,b,s in CAP:
  if a<=t<b:
   f=ImageFont.truetype(str(ROOT/'fonts/Mukta-Regular.ttf'),round(28*g.SCALE))
   d.text((W/2,1155*g.SCALE),s,font=f,fill=IVORY,anchor='mm',stroke_width=max(1,round(2*g.SCALE)),stroke_fill=INK)
   break

def frame(t,subtitles=True):
 im=Image.new('RGB',(W,H));c=C(im)
 if t<10.7:
  z=1+.03*E(t,0,10.7);c=c.group(360*(1-z),650*(1-z),z);rooftop(c,t)
  v=E(t,0,4.4);aarav(c,lerp(133,270,v),lerp(900,1065,v),1.42,t,'walk' if t<4.4 else 'idle',.12, -.4 if t>5.5 else .2)
 elif t<18:
  # Sari detail: still adjacent towel makes the impossible movement legible.
  sky(c,t);sari(c,t,158,270,1.65)
 elif t<23.7:
  rooftop(c,t);aarav(c,275,1090,1.8,t,'reach' if t<21.9 else 'freeze',.45,.6)
  if t>22.1:
   c.round((153,731,184,791),4,'#132432','#b5c6bc',2)
   for i in range(2):c.line([(140-i*9,735),(132-i*9,754),(140-i*9,774)],'#c6c89f',2)
 elif t<34.3:phone_insert(c,t)
 elif t<44:
  rooftop(c,t);aarav(c,350,1080,1.85,t,'turn',.85,-E(t,34.3,35.2))
  if t>39:
   # A shadow travels up the stairwell while the source of the voice stays unseen.
   c.poly([(60,758),(75,640),(92,612),(111,641),(127,758)],'#111524')
 elif t<49:
  rooftop(c,t);aarav(c,lerp(350,110,E(t,44,45)),1080,1.65,t,'slam' if t<46.2 else 'phone',.95,-.8)
 elif t<54:
  sky(c,t);aarav(c,350,1450,2.9,t,'phone',.9,-.4)
 elif t<59.3:
  sky(c,t);sari(c,t,158,270,1.65,True)
 elif t<66.5:floor_scene(c,t)
 else:
  sky(c,t);v=E(t,66.5,69)
  # Red presence enters behind his shoulder, without revealing an ordinary face.
  c.poly([(505,420),(612,370),(704,433),(770,1190),(470,1190)],'#6e263f')
  c.poly([(532,449),(610,408),(669,456),(702,1150),(500,1150)],'#a5344b')
  c.poly([(565,449),(608,429),(643,465),(628,550),(574,534)],'#151b2a')
  for xx in (520,560,670):c.line([(xx,560),(xx+15,1110)],'#cf525b',3)
  c.line([(485,1130),(700,1130)],GOLD,12)
  aarav(c,290,1470,3.05,t,'fear',1,E(t,66.5,68.5))
  # Slow camera push into the last unsettling image is achieved by character scale.
  if t>70:
   c.ellipse((638,627,646,637),'#abb7aa')
 if subtitles:caption(im,t)
 return im

def audio():
 n=SR*DUR;dialogue=np.zeros((n,2));rng=np.random.default_rng(2407)
 for q in T:
  path=ROOT/'audio'/q['file'];raw=path.with_suffix('.wav')
  if not raw.exists():subprocess.run(['ffmpeg','-v','error','-y','-i',str(path),'-ar',str(SR),'-ac','1',str(raw)],check=True)
  sr,x=wavfile.read(raw);x=x.astype(float)/32768
  if q['role']=='phone':x=sosfilt(butter(3,[400,3400],btype='bandpass',fs=SR,output='sos'),x)*1.12
  if q['role'] in ('below','presence'):
   x=sosfilt(butter(2,4400,fs=SR,output='sos'),x)
   y=np.pad(x,(0,int(.5*SR)))
   for delay,gain in ((.12,.19),(.26,.10),(.41,.05)):
    k=int(delay*SR);y[k:k+len(x)]+=x*gain
   x=y
  start=int(q['start']*SR);count=min(len(x),n-start)
  gains=(1,1) if q['role'] in ('phone','narrator') else ((1,.72) if q['role']=='below' else (.8,1))
  dialogue[start:start+count,0]+=x[:count]*gains[0];dialogue[start:start+count,1]+=x[:count]*gains[1]
 tt=np.arange(n)/SR;noise=rng.normal(0,1,n)
 amb=sosfilt(butter(2,220,fs=SR,output='sos'),noise)*.014
 amb+=.007*np.sin(2*np.pi*58*tt)+.003*np.sin(2*np.pi*87.1*tt)
 sound=np.stack([amb,amb],axis=1)
 def cue(at,dur,kind,vol=.1,pan=0):
  length=int(dur*SR);t=np.arange(length)/SR;ns=rng.normal(0,1,length)
  if kind=='cloth':x=sosfilt(butter(2,[400,5000],btype='bandpass',fs=SR,output='sos'),ns)*np.sin(np.pi*t/dur)
  elif kind=='step':x=(ns*np.exp(-t*65)+np.sin(2*np.pi*90*t)*np.exp(-t*25))
  elif kind=='wet':x=(sosfilt(butter(2,2200,fs=SR,output='sos'),ns)*np.exp(-t*18)+.4*np.sin(2*np.pi*(620*t-180*t*t))*np.exp(-t*20))
  elif kind=='slam':x=ns*np.exp(-t*28)+np.sin(2*np.pi*63*t)*np.exp(-t*9)
  elif kind=='ring':x=(np.sin(2*np.pi*660*t)+.5*np.sin(2*np.pi*880*t))*(.5+.5*np.sin(t*20))*np.sin(np.pi*t/dur)
  else:x=np.sin(2*np.pi*1300*t)*np.exp(-t*35)
  pos=int(at*SR);length=min(length,n-pos);sound[pos:pos+length,0]+=x[:length]*vol*(1-max(0,pan)*.5);sound[pos:pos+length,1]+=x[:length]*vol*(1+min(0,pan)*.5)
 for t in (.6,1.4,2.2,3,3.8):cue(t,.22,'step',.10)
 for t in (11.8,13.7,15.6,18.8):cue(t,.8,'cloth',.035,.6)
 cue(22.1,.7,'ring',.06);cue(23.1,.7,'ring',.055);cue(24.1,.12,'click',.05)
 cue(44.2,.25,'step',.11,-.6);cue(44.7,.25,'step',.12,-.7);cue(45.9,.7,'slam',.19,-.5)
 cue(54.3,.3,'cloth',.05)
 for i,t in enumerate((60.4,61.6,62.8,64,65.2)):cue(t,.45,'wet',.07+i*.025,(-1)**i*.65)
 sound[(tt>65.9)&(tt<66.5)]*=.08
 cue(69.2,1.2,'cloth',.045,.9)
 sound[tt>70]*=.25
 mixaudio=dialogue+sound;peak=np.max(np.abs(mixaudio));mixaudio*=.86/max(.86,peak)
 mixaudio[-SR:]*=np.linspace(1,0,SR)[:,None]
 wavfile.write(OUT/'Chhat_Par_Maa_Mix.wav',SR,(mixaudio*32767).astype(np.int16))
 def stamp(t):
  ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
 (OUT/'Chhat_Par_Maa_Hinglish.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(a)} --> {stamp(b)}\n{s}' for i,(a,b,s) in enumerate(CAP)),encoding='utf8')
 print('Audio complete',round(20*math.log10(np.max(abs(mixaudio)))),flush=True)
def render():
 target=OUT/('Chhat_Par_Maa_4K.mp4' if '--4k' in sys.argv else 'Chhat_Par_Maa_1080p.mp4');temp=OUT/('render_'+uuid.uuid4().hex+'.mp4')
 p=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-i',str(OUT/'Chhat_Par_Maa_Mix.wav'),'-c:v','libx264','-preset','ultrafast','-crf','19','-threads','4','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-t',str(DUR),'-movflags','+faststart',str(temp)],stdin=subprocess.PIPE)
 for i in range(DUR*FPS):
  p.stdin.write(frame(i/FPS).tobytes())
  if i%(FPS*10)==0:print(f'{W} render {i/FPS:.0f}/{DUR}s',flush=True)
 p.stdin.close();assert p.wait()==0;temp.replace(target);print(target,flush=True)
if __name__=='__main__':
 if not (OUT/'Chhat_Par_Maa_Mix.wav').exists():audio()
 if '--render' in sys.argv:render()
 else:
  times=[2,8,14,20,27,36,41,45.5,51,57,63,68]
  sheet=Image.new('RGB',(6*216,2*384))
  for i,t in enumerate(times):
   im=frame(t);im.save(OUT/f'qa_{t}.jpg');sheet.paste(im.resize((216,384)),((i%6)*216,(i//6)*384))
  sheet.save(OUT/'contact_sheet.jpg')
