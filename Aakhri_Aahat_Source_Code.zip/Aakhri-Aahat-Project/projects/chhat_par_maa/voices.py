from pathlib import Path
import asyncio,json,subprocess
import edge_tts
ROOT=Path(__file__).resolve().parent
LINES=[
 (0.4,'narrator','रात को आरव छत पर कपड़े लेने गया।','Raat ko Aarav chhat par|kapde lene gaya.'),
 (5.5,'below','बेटा, मेरी लाल साड़ी भी ले आना।','Beta, meri laal saari bhi le aana.'),
 (11.2,'narrator','हवा बिल्कुल बंद थी। फिर भी लाल साड़ी हिल रही थी।','Hawa bilkul band thi.|Phir bhi laal saari hil rahi thi.'),
 (18.5,'narrator','वह हाथ बढ़ाने ही वाला था, कि माँ का फ़ोन आया।','Woh haath badhaane hi waala tha,|ki maa ka phone aaya.'),
 (24.3,'phone','मैं अस्पताल में हूँ। पापा के पास आज रात रुकूँगी। दरवाज़ा अंदर से बंद कर लेना।','Main hospital mein hoon.|Papa ke paas aaj raat rukoongi.|Darwaaza andar se band kar lena.'),
 (34.5,'narrator','आरव ने सीढ़ियों की तरफ देखा।','Aarav ne seedhiyon ki taraf dekha.'),
 (39,'below','बेटा, फ़ोन वाली की बात मत सुनना।','Beta... phone waali ki baat mat sunna.'),
 (44,'narrator','उसने झट से छत का दरवाज़ा बंद कर दिया।','Usne jhat se chhat ka darwaaza|band kar diya.'),
 (49.5,'phone','लाल साड़ी उतारी तो नहीं?','Laal saari utaari toh nahi?'),
 (54,'narrator','आरव मुड़ा। रस्सी खाली थी।','Aarav muda.|Rassi khaali thi.'),
 (59.5,'narrator','उसके पीछे गीले पैरों की आहट आई।','Uske peechhe geele pairon ki aahat aayi.'),
 (66.5,'presence','मैं खुद उतर आई।','Main khud utar aayi.')]
async def main():
 sem=asyncio.Semaphore(3)
 async def one(i,item):
  start,role,text,sub=item;path=ROOT/'audio'/f'{i:02}_{role}.mp3'
  async with sem:
   if not path.exists() or path.stat().st_size<100:
    voice='hi-IN-MadhurNeural' if role=='narrator' else 'hi-IN-SwaraNeural'
    rate='-5%' if role in ['narrator','phone'] else '-13%'
    await asyncio.wait_for(edge_tts.Communicate(text,voice,rate=rate,pitch='-4Hz' if role!='phone' else '+0Hz').save(str(path)),60)
   dur=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(path)]))
   print(i,role,round(dur,2),flush=True)
   return dict(index=i,start=start,role=role,hindi=text,subtitle=sub,file=path.name,duration=dur)
 result=await asyncio.gather(*(one(i,q) for i,q in enumerate(LINES)))
 for i,q in enumerate(result):
  limit=result[i+1]['start']-.25 if i+1<len(result) else 72
  if q['start']+q['duration']>limit:print('OVERLAP',i,q['duration'],limit-q['start'])
 (ROOT/'timeline.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':asyncio.run(main())
