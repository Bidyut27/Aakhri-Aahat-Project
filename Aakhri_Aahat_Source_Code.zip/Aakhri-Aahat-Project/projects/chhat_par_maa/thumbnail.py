"""Matching character thumbnail drawn with the production's Python rig."""
import sys
sys.argv.append('--4k')
import render as r
from PIL import Image,ImageDraw,ImageFont
im=r.frame(68,subtitles=False)
d=ImageDraw.Draw(im)
d.rectangle((0,0,r.W,690),fill='#090d16')
d.rectangle((145,140,r.W-145,158),fill='#ca233b')
def title(s,y,size,fill):
 f=ImageFont.truetype(str(r.ROOT/'fonts/Mukta-Bold.ttf'),size)
 d.text((r.W/2,y),s,font=f,fill=fill,anchor='mm',stroke_width=3,stroke_fill='#090d16')
title('NEECHE',300,240,'#fff3dc')
title('KAUN HAI?',540,240,'#e82d43')
d.rectangle((0,3420,r.W,r.H),fill='#090d16')
title('CHHAT PAR MAA',3600,145,'#fff3dc')
im.save(r.OUT/'Chhat_Par_Maa_Thumbnail.png')
