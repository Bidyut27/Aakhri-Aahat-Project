# Seat 18 A

Original emotional airport horror short. Exactly **60.000 seconds**, including the subscribe/follow end card from 54–60 seconds.

## Delivery and visual rules

- Native 2160 × 3840, 30 fps, H.264 video with AAC stereo audio; 1080 × 1920 viewing copy.
- Seat labels on both boarding passes and in subtitles read **18 A** in numerals.
- Black, charcoal and red art direction with off-white text. No channel-name text or logo on screen.
- Mukta Regular, centered, off-white subtitles with no word highlights or bold emphasis.
- Mukta ExtraBold display text. FACEBOOK, INSTAGRAM and FOLLOW are uppercase and bold on the outro.
- Approved ElevenLabs Viraj Hindi narration and dialogue, including the subscribe/follow CTA. Original voice speed and pitch are preserved.

## Story

A son hears the boarding announcement for his father's flight, which vanished ten years earlier. His father is visible behind the gate glass and warns him not to approach. Staff hand the son a boarding pass for seat 18 A. The father's pass has the same seat, and the father's name begins to fade. The flight needs a replacement. The last reflection shows the son with his father's aged face, while his real hand is still young.

All people, the flight identifier and the incident are fictional. The character names Arun and Rajan identify the two passes.

## Animation

Jointed running with knee and arm motion, trailing suitcase and rotating wheels, blinking, breathing, eye direction, smile-to-fear changes, reaching, finger writing, boarding-pass movement, a fading name, glass contact and an aging reflection. Mouth shapes follow voice amplitude during the character dialogue; they are simple speaking animation, not phoneme-accurate lip-sync. Camera pushes are secondary to character and prop movement.

## Sound

Original synthesized terminal ventilation, distant turbine hum, PA chimes, footsteps, suitcase wheels, finger squeak, paper rustles, glass knocks and restrained suspense tones. The announcement quote has a PA-style filter. Background audio ducks beneath narration and falls away at the final reveal.

## Project files

- `render.py`: scene artwork, character rig, typography, animation and video export.
- `primitives.py`: resolution-independent drawing helpers.
- `prepare.py`: narration placement, captions and audio synthesis/mix.
- `timeline.json`: final subtitle times and text.
- `edit.json`: source-voice and destination-scene intervals.
- `Narration_Hindi.txt`: Hindi recording script.
- `audio/Viraj_original.mp3`: source voice take.
- `audio/word_timings.json`: returned timing metadata.
- `audio/Viraj_Synced.wav`: aligned voice track.
- `audio/Music_and_Effects.wav`: separate background track.
- `audio/Final_Mix.wav`: final 48 kHz stereo mix, exactly 2,880,000 samples.
- `fonts/`: Mukta Regular/Bold/ExtraBold and their SIL Open Font License.
- `output/Seat_18A_Hinglish.srt`: subtitle file, including the CTA text.
- `output/contact_sheet.jpg`: storyboard review frames.
- `output/qa_audio.json`: duration and audio-level check.

## Reproduce

This is an editable Python animation project, not an Adobe project. Requires Python 3.12, Pillow, NumPy, SciPy, FFmpeg with libx264, and system DejaVu Sans Mono Bold for boarding-pass numerals. Font paths can be changed in `render.py`.

```bash
python prepare.py
python render.py --preview
python render.py --render --4k
ffmpeg -i output/Seat_18A_4K.mp4 -vf scale=1080:1920 -c:v libx264 -crf 20 -preset fast -c:a copy -movflags +faststart output/Seat_18A_1080p.mp4
```

The master draws geometric artwork and text at output resolution from a 720 × 1280 logical coordinate system. It contains exactly 1,800 frames. The 1080p copy is downscaled from the master.

## Voice provenance

Voice ID: F8IvasoAdpDhOjLm5YBm. Model: eleven_v4. Source take: wnfwSArhnGOcuIPLTnZc. Flow: bg0PqeBwS7e5pW30PKJT. The source recording is bundled; no paid regeneration is needed to rebuild this edit.
