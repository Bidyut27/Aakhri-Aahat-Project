"""Seat 18A: exactly 1800 frames at 30 fps. Native flat 2D geometry, 4K master."""
from pathlib import Path
import math,json,sys,subprocess
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from scipy.io import wavfile
import primitives as g
from primitives import C,limb,ease,lerp
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
g.SCALE=3 if '--4k' in sys.argv else 1.5
W,H=int(720*g.SCALE),int(1280*g.SCALE);FPS=30;DURATION=60
P={'bg':'#0B0B0D','wall':'#222226','floor':'#343236','edge':'#797577','red':'#C62828','light':'#FF625A','white':'#F5F0E6','skin':'#BD957F','grey':'#aaa29e'}
T=json.loads((ROOT/'timeline.json').read_text()) if (ROOT/'timeline.json').exists() else []
audio_path=ROOT/'audio/Viraj_Synced.wav'
if audio_path.exists():
 sr,v=wavfile.read(audio_path);v=v.astype(float)/32768
else:sr=48000;v=np.zeros(sr*60)
FONT_CACHE={}
def txt(c,xy,s,size=26,col=None,bold=False,mono=False):
 key=(round(size*c.s*g.SCALE),bold,mono)
 if key not in FONT_CACHE:
  path='/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf' if mono else ROOT/'fonts'/('Mukta-ExtraBold.ttf' if bold else 'Mukta-Regular.ttf')
  FONT_CACHE[key]=ImageFont.truetype(str(path),max(1,key[0]))
 c.d.text(c.pt(xy),s,font=FONT_CACHE[key],fill=col or P['white'],anchor='mm')
def amplitude(t):
 a=int(max(0,t)*sr);b=min(len(v),a+1200)
 return min(1,float(np.sqrt(np.mean(v[a:b]**2)))*10) if b>a else 0
def plane(c,x,y,s=1):
 c=c.group(x,y,s);c.poly([(-87,0),(-34,-10),(-7,-58),(8,-58),(6,-8),(76,-4),(93,0),(75,5),(8,11),(4,39),(-9,39),(-22,12),(-77,9)],'#d0c8bf')
 c.poly([(-73,0),(-89,-22),(-102,-22),(-87,7)],P['red'])
 for xx in [-55,-39,-23,-7,9,25,41]:c.ellipse((xx,-3,xx+5,1),'#414147')

def actor(c,x,y,s,t,kind='son',pose='idle',gaze=0,speak=False,reach=None,smile=False,age=0):
 c=c.group(x,y,s);walk=pose=='run';bob=abs(math.sin(t*10))*5 if walk else math.sin(t*2.4)*1.4;c=c.group(0,-bob)
 dad=kind=='dad';staff=kind=='staff';grey=dad or age>.5
 shirt='#908986' if dad else '#9b2835' if staff else '#64272f';trouser='#323137' if dad else '#1b1a20'
 c.ellipse((-61,-9,61,10),'#0c0b10')
 for xx,sign in [(-23,1),(23,-1)]:
  swing=math.sin(t*10)*30*sign if walk else (5*math.sin(t*2) if pose=='recoil' else 0)
  knee=(xx+swing*.5,-71-abs(swing)*.25);foot=(xx+swing,-13)
  limb(c,(xx,-136),knee,trouser,26);limb(c,knee,foot,trouser,22)
  c.round((foot[0]-16,-21,foot[0]+24,-2),5,'#bcb6aa');c.rect((foot[0]-16,-6,foot[0]+24,-1),'#6c6769')
 c.round((-48,-257,48,-133),13,shirt)
 if dad:
  for yy in [-239,-212,-183,-153]:c.line([(-43,yy),(43,yy)],'#6e6869',2)
  for xx in [-24,0,24]:c.line([(xx,-251),(xx,-139)],'#6e6869',2)
  c.rect((15,-224,35,-202),'#a69d94')
 elif staff:
  c.poly([(-15,-255),(12,-255),(0,-196)],P['white']);c.line([(-19,-249),(0,-180),(21,-249)],'#4e1d28',4)
  c.round((17,-225,37,-211),2,P['white'])
 else:
  c.line([(-18,-251),(-8,-216)],'#ad7479',3);c.line([(18,-251),(8,-216)],'#ad7479',3)
  c.round((-29,-182,29,-151),5,'#50242e');c.line([(-25,-179),(25,-179)],'#8b5158',2)
 # articulated shoulders, elbows and hands, with explicit contact targets
 for sign in [-1,1]:
  hand=(sign*57,-147);el=(sign*67,-201)
  if walk:el=(sign*64,-202+sign*math.sin(t*10)*32);hand=(sign*42,-161+sign*math.sin(t*10)*47)
  if dad and sign==-1:el=(-68,-204);hand=(-72,-182)
  if pose=='bang':hand=(sign*82,-300-12*math.sin(t*15));el=(sign*83,-222)
  if pose=='recoil':el=(sign*79,-207);hand=(sign*93,-250)
  if reach is not None and sign==1:hand=reach;el=((44+hand[0])*.5+18,(-238+hand[1])*.5+33)
  limb(c,(sign*45,-239),el,shirt,21);limb(c,el,hand,P['skin'],16)
  if pose in ['bang','touch'] or reach is not None and sign==1:
   c.ellipse((hand[0]-9,hand[1]-12,hand[0]+9,hand[1]+10),P['skin'])
   for j in range(3):c.line([(hand[0]-7+j*6,hand[1]-4),(hand[0]-7+j*6,hand[1]-19)],P['skin'],4)
 if dad and pose!='bang':plane(c,-84,-173,.38)
 # face, eyes, eyelids, brows, jaw and mouth response to the voice envelope
 hx=3*math.sin(t*1.5)+gaze*5;head=c.group(hx,-289)
 c.rect((hx-12,-282,hx+12,-250),P['skin'])
 head.ellipse((-34,-65,34,10),P['skin']);head.ellipse((-39,-34,-29,-14),P['skin']);head.ellipse((29,-34,39,-14),P['skin'])
 hair='#a9a3a0' if dad else tuple(round(lerp(a,b,age)) for a,b in zip((23,21,26),(169,163,160)))
 head.poly([(-33,-27),(-35,-57),(-13,-72),(18,-69),(34,-51),(33,-36),(20,-48),(-21,-48),(-25,-26)],hair)
 if staff:head.round((-40,-62,-28,14),7,'#20171e')
 for xx in [-12,12]:
  worried=pose in ['bang','recoil','scared','write']
  head.line([(xx-6,-37-(3 if worried and xx<0 else 0)),(xx+6,-37-(3 if worried and xx>0 else 0))],'#51413d',2)
  if t%4.1>3.93:head.line([(xx-4,-26),(xx+4,-26)],'#362d2d',2)
  else:
   head.ellipse((xx-5,-31,xx+5,-22),'#e5d9cd');head.ellipse((xx-2+gaze*2,-29,xx+2+gaze*2,-23),'#29242a')
 head.line([(1,-24),(5,-14),(0,-12)],'#99715f',2)
 mouth=amplitude(t) if speak else 0
 if mouth>.08:head.ellipse((-7,-4,7,1+mouth*11),'#48282c')
 elif smile:head.line([(-10,-4),(-4,0),(4,0),(10,-4)],'#74504a',2)
 else:head.line([(-8,-3),(8,-3 if pose!='scared' else 0)],'#74504a',2)
 if grey:
  for yy in [-43,-40]:head.line([(-12,yy),(12,yy)],'#997f72',1)
  head.line([(-25,-16),(-18,-11)],'#997f72',1);head.line([(18,-11),(25,-16)],'#997f72',1)
  head.line([(-21,-1),(-12,10),(12,10),(22,-2)],'#aca198',3)

def terminal(c,t,offset=0):
 c.rect((0,0,720,1280),P['wall'])
 c.poly([(0,0),(720,0),(540,234),(180,234)],'#383438')
 for x in [-130,130,390,650,910]:c.line([(360,234),(x,0)],'#787174',3)
 for x in [125,570]:c.line([(x,96),(x+35,147)],P['white'],6)
 c.rect((0,752,720,1280),P['floor'])
 for x in [-900,-300,300,900,1500]:c.line([(360,670),(x,1280)],'#595256',2)
 for yy in [820,919,1054,1223]:c.line([(0,yy),(720,yy)],'#595256',2)
 c.rect((40,261,680,749),'#171b23')
 # tarmac: navigation lights and a distant aircraft
 c.rect((40,584,680,749),'#27242a')
 for i in range(9):c.ellipse((60+i*70,649,64+i*70,653),P['light'] if i%2 else '#b0a29c')
 plane(c,365+math.sin(t*.13)*14,550,1.5)
 for xx in [40,247,467,680]:c.rect((xx-4,261,xx+4,749),'#7b7277')
 c.rect((40,483,680,490),'#7b7277')
 # benches, counter and directional sign
 for xx in [-55,55,165]:
  c.round((xx,786,xx+93,865),8,'#242126','#73646b',3);c.line([(xx+10,865),(xx+10,930)],'#9b8b8c',5)
 c.round((478,751,691,920),8,'#201e24');c.rect((478,751,691,765),P['red'])
 c.round((280,164,610,233),5,'#101115');txt(c,(445,201),'GATE 06',30,P['white'],True)

def board(c,t,u):
 terminal(c,t)
 c.round((52,248,668,696),12,'#0d0d11','#696067',3)
 c.rect((53,249,667,324),P['red']);txt(c,(360,288),'DEPARTURES',36,P['white'],True)
 txt(c,(360,379),'FLIGHT 071',48,P['white'],True,True)
 txt(c,(360,454),'DELHI     GATE 06',26,P['grey'],False,True)
 c.round((110,518,610,619),6,'#481821');txt(c,(360,566),'BOARDING',48,P['light'],True)
 actor(c,355,1112,1.05,t,pose='scared',gaze=1)
 # the old pass is in his hand: establishes the lost-flight connection
 c.round((410,885,602,1003),5,'#c5bcae');txt(c,(506,911),'FLIGHT 071',18,'#373035',True)
 txt(c,(506,952),'10 YEARS AGO',15,'#5c4b4e',False,True)

def running(c,t,u):
 terminal(c,t)
 x=lerp(126,524,ease(u));actor(c,x,1070,1.03,t,pose='run',gaze=1)
 # suitcase trails with rotating wheels and a connected handle
 bx=x-108;by=1046+abs(math.sin(t*10))*2
 c.line([(x-45,907),(bx+22,912),(bx+22,953)],'#a58d8e',5)
 c.round((bx-17,949,bx+58,1057),9,'#4b242d',P['red'],2)
 for xx in [bx-1,bx+43]:
  c.ellipse((xx-9,1050,xx+9,1068),'#18151b','#9b9090',2)
  c.line([(xx,1059),(xx+6*math.cos(t*10),1059+6*math.sin(t*10))],'#b6a29e',2)

def glassbase(c,t):
 c.rect((0,0,720,1280),'#201e24')
 c.rect((47,164,673,1054),'#14151c')
 c.poly([(55,838),(665,838),(665,1052),(55,1052)],'#363139')
 for xx in [130,310,490]:c.line([(xx,837),(xx-150,1052)],'#514650',2)
 c.rect((520,242,619,281),P['red']);txt(c,(570,262),'GATE 06',17,P['white'],True)
 c.line([(58,343),(661,343)],'#2d292f',2)

def glassfront(c,t):
 c.rect((47,164,673,1054),None,'#8c7c80',7)
 c.poly([(61,181),(80,181),(350,1037),(331,1037)],'#38333c')
 c.line([(650,180),(650,1036)],'#65545c',2)
 c.rect((26,1050,695,1074),'#9c898b')

def reunion(c,t,u,warning=False):
 glassbase(c,t)
 x=406;y=1016;s=1.63
 if warning:
  a=ease(u*.95);px=175+360*a;py=696+4*math.sin(a*30)
  actor(c,x,y,s,t,kind='dad',pose='write',gaze=-1,reach=((px-x)/s,(py-y)/s))
  word='MAT AANA';n=max(0,min(len(word),int(u*len(word)*1.4)))
  txt(c,(352,703),word[:n],52,P['white'],True)
 else:actor(c,x,y,s,t,kind='dad',gaze=-1,smile=u<.6)
 glassfront(c,t)
 # foreground son, cropped shoulder and reaching hand
 c.poly([(0,920),(72,878),(147,972),(177,1280),(0,1280)],'#55222c')
 if not warning:
  c.line([(113,1050),(164,995),(208,956-18*ease(u))],P['skin'],23)
  c.ellipse((196,937-18*ease(u),221,964-18*ease(u)),P['skin'])

def passcard(c,x,y,w=500,h=300,name='ARUN',fade=0):
 c.round((x,y,x+w,y+h),12,P['white'])
 c.rect((x,y+25,x+w,y+69),P['red']);txt(c,(x+w/2,y+47),'BOARDING PASS',23,P['white'],True)
 txt(c,(x+96,y+104),'PASSENGER',15,'#61565a')
 color=tuple(round(lerp(a,b,fade)) for a,b in zip((40,31,38),(245,240,230)))
 txt(c,(x+139,y+143),name,32,color,True)
 txt(c,(x+w-106,y+105),'SEAT',19,'#61565a');txt(c,(x+w-106,y+166),'18 A',52,'#211c23',True,True)
 txt(c,(x+140,y+213),'071  /  DELHI',22,'#352b32',False,True)
 for i in range(41):
  xx=x+30+i*6;c.rect((xx,y+h-54,xx+(1 if i%3 else 3),y+h-22),'#3c3037')
 c.line([(x+w-208,y+83),(x+w-208,y+h-15)],'#b5a9ac',2)

def handoff(c,t,u):
 terminal(c,t);actor(c,553,1022,1.32,t,kind='staff',speak=26.7<t<28.1,gaze=-1,reach=(-115,-180))
 actor(c,177,1075,1.1,t,pose='scared',gaze=1,reach=(110,-188))
 # staff extends the pass, son closes his fingers around it
 y=lerp(682,600,ease(u*2));x=lerp(264,110,ease(u*2))
 passcard(c,x,y,500,300)
 c.round((x+472,y+163,x+519,y+243),19,P['skin'])
 if u>.4:c.round((x-12,y+177,x+28,y+248),16,P['skin'])

def dadpass(c,t,u):
 glassbase(c,t);actor(c,368,1030,1.5,t,kind='dad',pose='scared',gaze=-1,reach=(70,-228))
 y=lerp(818,620,ease(u*2));passcard(c,107,y,506,300,'RAJAN',ease((u-.32)/.5))
 for x in [95,600]:c.round((x,y+175,x+31,y+255),14,P['skin'])
 glassfront(c,t)
 # print disappears on the name field only; the seat remains 18A

def banging(c,t,u):
 glassbase(c,t);actor(c,419,1015,1.63,t,kind='dad',pose='bang',gaze=-1,speak=41.8<t<44.1)
 glassfront(c,t)
 # contact rings expand briefly with each strike
 for at in [42.2,43.1,44.0]:
  q=t-at
  if 0<q<.3:
   rad=8+q*70;c.ellipse((549-rad,532-rad,549+rad,532+rad),None,'#9c6f76',2)
 actor(c,lerp(180,98,ease(u)),1190,1.0,t,pose='recoil',gaze=1)

def reflection(c,t,u):
 glassbase(c,t)
 # Mirror likeness has son's burgundy clothes, but father's grey hair and wrinkles.
 actor(c,378,1030,1.72,t,kind='son',pose='scared',gaze=-.2,age=ease((t-50.8)/1.2),reach=(91,-263))
 glassfront(c,t)
 # young, unwrinkled foreground hand touches the reflected palm.
 k=ease((u-.12)/.5);hx=lerp(638,534,k);hy=lerp(1100,584,k)
 c.poly([(660,1280),(720,1280),(hx+26,hy+69),(hx-21,hy+63)],'#5f2730')
 c.round((hx-24,hy-10,hx+23,hy+88),20,P['skin'])
 for j in range(4):
  xx=hx-20+j*13;c.round((xx,hy-49+(abs(j-1.5)*8),xx+10,hy+12),5,P['skin'])
 # Status is part of the airport display, not a subtitle highlight.
 if t>48.5:
  c.round((88,198,630,278),5,'#421620');txt(c,(359,239),'REPLACEMENT COMPLETE',25,P['light'],True)

def outro(c,t):
 c.rect((0,0,720,1280),P['bg']);u=ease((t-54)/.6)
 c.line([(90,223),(90+540*u,223)],P['red'],4)
 txt(c,(360,375),'SUBSCRIBE',78,P['red'],True);txt(c,(360,462),'karein',45)
 txt(c,(360,658),'FACEBOOK',56,P['white'],True);txt(c,(360,724),'aur',29)
 txt(c,(360,791),'INSTAGRAM',56,P['white'],True)
 txt(c,(360,912),'pe FOLLOW karein',44,P['light'],True)
 c.line([(269,1024),(451,1024)],'#65202b',3)

def frame(t):
 im=Image.new('RGB',(W,H),P['bg']);c=C(im)
 if t>=54:outro(c,t);return im
 if t<6.2:sc='board';a,b=0,6.2
 elif t<12:sc='run';a,b=6.2,12
 elif t<18.5:sc='reunion';a,b=12,18.5
 elif t<25:sc='warning';a,b=18.5,25
 elif t<31.8:sc='handoff';a,b=25,31.8
 elif t<38.8:sc='pass';a,b=31.8,38.8
 elif t<45.5:sc='bang';a,b=38.8,45.5
 else:sc='reflection';a,b=45.5,54
 u=(t-a)/(b-a);z=1+.025*ease(u);c=C(im,360*(1-z),660*(1-z),z)
 if sc=='board':board(c,t,u)
 elif sc=='run':running(c,t,u)
 elif sc=='reunion':reunion(c,t,u)
 elif sc=='warning':reunion(c,t,u,True)
 elif sc=='handoff':handoff(c,t,u)
 elif sc=='pass':dadpass(c,t,u)
 elif sc=='bang':banging(c,t,u)
 else:reflection(c,t,u)
 # Normal-weight, monochrome, centered subtitles. No word highlights.
 c=C(im)
 r=next((r for r in T if r['start']<=t<r['end']),None)
 if r:
  lines=r['caption'].split('\n');h=44*len(lines)+36
  c.round((32,1177-h,688,1177),10,'#0B0B0D')
  for i,line in enumerate(lines):txt(c,(360,1177-h+35+i*44),line,32,P['white'])
 return im

def preview():
 times=[2,8,15,23,29,36,43,49,52.6,56]
 sheet=Image.new('RGB',(1000,730),P['bg']);d=ImageDraw.Draw(sheet)
 for i,t in enumerate(times):
  im=frame(t);im.save(OUT/f'qa_{t}.jpg',quality=88);x=i%5*200;y=i//5*365
  sheet.paste(im.resize((200,356)),(x,y));d.text((x+7,y+349),str(t)+'s',fill='white')
 sheet.save(OUT/'contact_sheet.jpg',quality=90)

def render():
 name='Seat_18A_4K.mp4' if '--4k' in sys.argv else 'Seat_18A_1080p.mp4'
 p=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{W}x{H}','-framerate','30','-i','pipe:0','-i',str(ROOT/'audio/Final_Mix.wav'),'-c:v','libx264','-threads','4','-preset','veryfast','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-movflags','+faststart','-t','60',str(OUT/name)],stdin=subprocess.PIPE)
 for i in range(1800):
  p.stdin.write(frame(i/30).tobytes())
  if i%150==0:print(f'{i/30:.0f}/60 seconds rendered',flush=True)
 p.stdin.close();assert p.wait()==0;print('Complete',flush=True)

if __name__=='__main__':
 if '--preview' in sys.argv:preview()
 if '--render' in sys.argv:render()
