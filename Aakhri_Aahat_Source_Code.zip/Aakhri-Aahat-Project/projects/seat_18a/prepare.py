"""Exact 60-second edit, natural-speed narration, original synchronized airport SFX."""
from pathlib import Path
import json,subprocess
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter,sosfilt
from scipy.ndimage import uniform_filter1d,maximum_filter1d
ROOT=Path(__file__).resolve().parent;SR=48000
# Source audio interval, picture interval, scene. Every scene includes a natural pause.
SEG=[(0,6,0,6.2,'board'),(6,11.3,6.2,12,'run'),(11.3,17,12,18.5,'reunion'),(17,22.72,18.5,25,'warning'),(22.72,28.9,25,31.8,'handoff'),(28.9,35,31.8,38.8,'pass'),(35,40.2,38.8,45.5,'bang'),(40.2,47.3,45.5,54,'reflection'),(47.3,None,54,60,'outro')]
CAPS=[
 (0,3.08,'Papa ki aakhri flight\nkabhi land nahi hui.'),
 (3.08,5.95,'Aaj... usi flight ka\nboarding announcement hua.'),
 (6.3,9.7,'Das saal purana flight number.\nWahi manzil.'),
 (9.7,11.2,'Main gate ki taraf bhaaga.'),
 (11.4,13.4,'Glass ke us paar papa the.'),
 (13.4,14.5,'Wahi shirt.'),
 (14.5,16.9,'Haath mein mere liye\nkhareeda hua khilauna.'),
 (17.25,20.2,'Mujhe dekhte hi unki\nmuskaan gayab ho gayi.'),
 (20.2,22.65,'Glass par likha...\n“Mat aana.”'),
 (22.8,24.25,'Peeche se staff boli...'),
 (24.25,25.75,'“Aapka boarding pass.”'),
 (25.75,26.9,'Mera naam tha.'),
 (26.9,28.85,'Seat... 18 A.'),
 (29,30.75,'Papa ne apna pass dikhaya.'),
 (30.75,33,'Wahi seat... 18 A.'),
 (33,34.9,'Lekin unka naam\nmit raha tha.'),
 (35.15,36.25,'Main peeche hata.'),
 (36.25,37.8,'Papa glass peetne lage.'),
 (37.8,40.1,'“Bhaag! Inhe meri jagah\nkoi chahiye!”'),
 (40.3,41.53,'Announcement hua...'),
 (41.53,43.6,'“Passenger replacement\ncomplete.”'),
 (43.6,45.65,'Glass mein mera chehra tha...'),
 (45.65,47.25,'Lekin papa ki umr ka.'),
 (47.4,51,'Subscribe karein aur Facebook,\nInstagram pe follow karein.')]

def stamp(t):
 n=round(t*1000);return f'{n//3600000:02}:{n//60000%60:02}:{n//1000%60:02},{n%1000:03}'

def main():
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(ROOT/'audio/Viraj_original.mp3'),'-af','loudnorm=I=-18:TP=-3:LRA=9','-ar',str(SR),'-ac','1',str(ROOT/'audio/voice_normalized.wav')],check=True)
 _,v=wavfile.read(ROOT/'audio/voice_normalized.wav');v=v.astype(float)/32768;voice=np.zeros(SR*60)
 edits=[]
 for a,b,start,end,scene in SEG:
  b=b if b is not None else len(v)/SR
  offset=.12 if scene!='outro' else .3;dest=start+offset
  clip=v[round(a*SR):round(b*SR)].copy();fade=min(96,len(clip)//2);clip[:fade]*=np.linspace(0,1,fade);clip[-fade:]*=np.linspace(1,0,fade)
  assert dest+len(clip)/SR<=end+.001,(scene,dest,len(clip)/SR,end)
  at=round(dest*SR);voice[at:at+len(clip)]=clip
  edits.append(dict(source_start=a,source_end=b,start=start,end=end,scene=scene,voice_start=dest))
 def mapped(t):
  for r in edits:
   if r['source_start']<=t<=r['source_end']:return r['voice_start']+t-r['source_start']
  return edits[-1]['voice_start']+min(t,len(v)/SR)-edits[-1]['source_start']
 rows=[dict(start=mapped(a),end=mapped(min(b,len(v)/SR)),caption=cap) for a,b,cap in CAPS]
 (ROOT/'timeline.json').write_text(json.dumps(rows,indent=2));(ROOT/'edit.json').write_text(json.dumps(edits,indent=2))
 # Environmental layers: terminal ventilation, distant turbine and a restrained tonal bed.
 n=len(voice);t=np.arange(n)/SR;rng=np.random.default_rng(180)
 air=sosfilt(butter(2,700,fs=SR,output='sos'),rng.standard_normal(n))*.017
 turbine=.01*np.sin(2*np.pi*61*t+.5*np.sin(t*.17))+.006*np.sin(2*np.pi*122.3*t)
 tension=.011*np.sin(2*np.pi*49*t)+.006*np.sin(2*np.pi*73.8*t)
 ambience=np.column_stack([air+turbine,np.roll(air,900)+turbine]);music=np.column_stack([tension,tension]);fx=np.zeros((n,2))
 def add(at,sound,pan=0):
  i=round(at*SR);k=min(len(sound),n-i)
  if i<0 or k<=0:return
  fx[i:i+k,0]+=sound[:k]*(1-.35*pan);fx[i:i+k,1]+=sound[:k]*(1+.35*pan)
 def tone(d,f,amp):
  q=np.arange(round(d*SR))/SR;return amp*np.sin(2*np.pi*f*q)*np.exp(-q*4)*np.minimum(1,q*180)
 def foot():
  q=np.arange(round(.2*SR))/SR;return .095*np.sin(2*np.pi*105*q)*np.exp(-q*28)+.035*rng.standard_normal(len(q))*np.exp(-q*45)
 def glassknock():
  q=np.arange(round(.43*SR))/SR;return (.11*np.sin(2*np.pi*370*q)+.045*np.sin(2*np.pi*971*q))*np.exp(-q*19)
 # Two airport PA chimes. All effects are original synthesis, no borrowed recordings.
 for at in [3.12,45.62]:
  for j,f in enumerate([659.25,523.25]):add(at+j*.23,tone(.55,f,.042),.25)
 for i,at in enumerate(np.arange(6.48,11.65,.34)):add(at,foot(),-.4+i%2*.8)
 # Suitcase wheels roll beneath the footsteps.
 q=np.arange(round(5.4*SR))/SR;add(6.4,.012*rng.standard_normal(len(q))*(.5+.5*np.sin(q*70)**2),-.4)
 # Finger squeak traces the warning and paper rustles mark each boarding-pass movement.
 q=np.arange(round(1.2*SR))/SR;add(22.5,.013*np.sin(2*np.pi*(1050*q+35*np.sin(q*9)))*np.sin(np.pi*q/1.2)**2,.4)
 for at in [25.5,32.1]:
  q=np.arange(round(.55*SR))/SR;noise=rng.standard_normal(len(q));noise=sosfilt(butter(2,[900,5800],btype='bandpass',fs=SR,output='sos'),noise)
  add(at,.034*noise*np.sin(np.pi*q/.55)**2,.3)
 for at in [42.2,43.1,44.0]:add(at,glassknock(),.55)
 # Pull room tone away from the final aged reflection; leave a beat before CTA.
 envelope=np.ones(n);envelope[t>=51.8]=np.clip((53.3-t[t>=51.8])/1.5,0,1)
 ambience*=envelope[:,None];music*=envelope[:,None]
 add(51.1,tone(.9,46,.11))
 # Slight PA band-limit only on the announcement quote, keeping every spoken word intact.
 lo,hi=round(mapped(41.53)*SR),round(mapped(43.6)*SR)
 pa=sosfilt(butter(2,[250,3400],btype='bandpass',fs=SR,output='sos'),voice[lo:hi])
 voice[lo:hi]=.35*voice[lo:hi]+.85*pa
 activity=maximum_filter1d((np.abs(voice)>.012).astype(float),size=9601);duck=uniform_filter1d(.8-.47*activity,size=6001)
 bed=ambience+music;mix=voice[:,None]+bed*duck[:,None]+fx*.7
 mix*=min(1,.84/max(np.max(np.abs(mix)),1e-9));mix[-4800:]*=np.linspace(1,0,4800)[:,None]
 for name,data in [('Viraj_Synced',voice),('Music_and_Effects',bed+fx*.7),('Final_Mix',mix)]:wavfile.write(ROOT/f'audio/{name}.wav',SR,(np.clip(data,-1,1)*32767).astype(np.int16))
 (ROOT/'output/Seat_18A_Hinglish.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(r["start"])} --> {stamp(r["end"])}\n{r["caption"]}' for i,r in enumerate(rows))+'\n')
 (ROOT/'output/qa_audio.json').write_text(json.dumps(dict(duration=60,samples=len(mix),peak_dbfs=float(20*np.log10(np.max(np.abs(mix)))),voice_speed_changed=False,finite=bool(np.isfinite(mix).all())),indent=2))
 print('60.000 seconds, original voice speed; peak',20*np.log10(np.max(np.abs(mix))),flush=True)

if __name__=='__main__':main()
