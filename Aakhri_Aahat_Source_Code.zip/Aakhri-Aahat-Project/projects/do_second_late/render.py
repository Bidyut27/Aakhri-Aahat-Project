"""Do Second Late: deterministic native-resolution Python 2D animation.
Run python render.py --render --4k; requires Pillow, NumPy, SciPy, ffmpeg.
All story visuals are procedural geometry. No generated video is used.
"""
from pathlib import Path
import math,sys,json,subprocess,uuid
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter,sosfilt
from PIL import Image,ImageDraw,ImageFont
import primitives as g
from primitives import C,limb,ease,lerp
ROOT=Path(__file__).resolve().parent; OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
FPS=24; DURATION=60; g.SCALE=3 if '--4k' in sys.argv else 1.5
W,H=int(720*g.SCALE),int(1280*g.SCALE)
INK='#101c26'; SKIN='#ba896c'; LIGHT='#ddb193'; SHADE='#875c50'
FONT={}
def txt(c,xy,text,size=25,fill='#eee9df',bold=False):
 k=(round(size*c.s*g.SCALE),bold)
 if k not in FONT:FONT[k]=ImageFont.truetype(str(ROOT/'fonts'/('Mukta-Bold.ttf' if bold else 'Mukta-Regular.ttf')),max(1,k[0]))
 c.d.text(c.pt(xy),text,font=FONT[k],fill=fill,anchor='mm',stroke_width=0)
def E(t,a,b):return ease((t-a)/(b-a))
def mix(a,b,v):return tuple(lerp(x,y,v) for x,y in zip(a,b))
def outlined(c,pts,col,w=2):
 c.poly(pts,col);c.line(pts+[pts[0]],INK,w)
def stroke(c,a,b,col,w):limb(c,a,b,INK,w+4);limb(c,a,b,col,w)
def arm(c,shoulder,hand,side=1):
 # Analytic two-link inverse kinematics keeps wrists attached to targets.
 dx,dy=hand[0]-shoulder[0],hand[1]-shoulder[1];d=max(.01,math.hypot(dx,dy));L=65
 d=min(d,129);mid=((shoulder[0]+hand[0])/2,(shoulder[1]+hand[1])/2)
 h=math.sqrt(max(0,L*L-d*d/4)); elbow=(mid[0]-side*dy/max(d,1)*h,mid[1]+side*dx/max(d,1)*h)
 stroke(c,shoulder,elbow,'#713346',28);stroke(c,elbow,hand,SKIN,20)
 c.line([mix(elbow,hand,.08),mix(elbow,hand,.23)],'#c3a19a',4)
 return hand
def hand(c,x,y,raised=False,grip=False):
 c.ellipse((x-11,y-12,x+11,y+13),SKIN,INK,2)
 if raised:
  for i in range(4):
   xx=x-8+i*5;end=y-25-(3 if i in (1,2) else 0)
   stroke(c,(xx,y-5),(xx-2+i,end),LIGHT,4)
  stroke(c,(x+7,y+3),(x+17,y-7),SKIN,5)
 else:
  for i in range(3):c.line([(x-5+i*5,y+1),(x-6+i*5,y+8)],SHADE,1)
def head(c,x,y,t,fear=0,look=0,smile=0,talk=0):
 c=c.group(x,y)
 c.ellipse((-45,-13,-28,19),SKIN,INK,2);c.ellipse((29,-13,44,19),SHADE,INK,2)
 outlined(c,[(-36,-51),(-17,-68),(19,-65),(37,-40),(35,26),(18,49),(-8,51),(-32,31)],SKIN)
 c.poly([(16,-61),(36,-40),(35,26),(18,49),(4,49),(20,22),(23,-23)],SHADE)
 c.poly([(-31,8),(-23,32),(-5,45),(15,42),(29,22),(32,33),(17,50),(-8,51),(-30,30)],'#634e49')
 outlined(c,[(-39,-9),(-47,-43),(-31,-68),(-3,-77),(18,-86),(37,-73),(42,-48),(34,-27),(24,-42),(3,-48),(-15,-32),(-30,-34),(-29,-7)],'#18222b')
 c.line([(-35,-49),(-14,-60),(9,-65),(26,-70)],'#3a4650',3)
 c.line([(-30,-58),(-4,-69),(19,-76)],'#4b5059',2)
 blink=1-E(t%4.8,4.60,4.68)+E(t%4.8,4.72,4.80)
 for xx in (-16,16):
  if blink<.4:c.line([(xx-10,-11),(xx+10,-11)],INK,3)
  else:
   c.ellipse((xx-11,-20-fear*2,xx+11,-4+fear*4),'#e8e5d8',INK,2)
   gx=xx+look*5;c.ellipse((gx-4,-18,gx+4,-5),'#172d34');c.ellipse((gx-2,-17,gx,-13),'#f4f2e8')
  c.line([(xx-11,-26-fear*5),(xx,-30-fear*5),(xx+9,-26)],'#24242a',4)
 c.line([(2,-8),(7,8),(-1,11)],SHADE,2)
 if smile>.1:
  c.line([(-14,25),(-7,29+smile*4),(5,29+smile*4),(17,22)],'#392b32',3)
  if talk>.1:c.ellipse((-7,28,8,30+talk*11),'#35252e')
 elif talk>.08 or fear>.6:
  c.ellipse((-9,24,10,28+max(talk*15,fear*9)),'#35252e',INK,1)
 else:c.line([(-10,29),(1,27),(11,29)],'#573e3c',2)
 for xx,yy in [(-23,23),(-18,29),(-13,35),(-7,40),(5,40),(13,36),(23,26)]:c.line([(xx,yy),(xx+1,yy+3)],'#38343a',1)
 if fear>.6:
  c.poly([(31,-12),(27,4),(31,10),(35,5)],'#b7d1cd')
def pose(t):
 # Predictions use pose(t+2), making the offset exact at every frame.
 wash=1-E(t,4,5.1)
 raised=E(t,12,13)-E(t,16,17)
 phone=E(t,20,22)
 grab=E(t,46,46.5)
 vanish=E(t,49,50)
 return dict(wash=wash,raised=raised,phone=phone,grab=grab,vanish=vanish)
def phone(c,x,y,angle=0):
 # Rotated polygon keeps the phone rigid during the fall.
 def tr(a,b):return (x+a*math.cos(angle)-b*math.sin(angle),y+a*math.sin(angle)+b*math.cos(angle))
 outlined(c,[tr(-14,-29),tr(14,-29),tr(14,29),tr(-14,29)],'#14232c',2)
 c.poly([tr(-10,-23),tr(10,-23),tr(10,21),tr(-10,21)],'#517b80')
 c.ellipse((*tr(-3,12),*tr(3,18)),'#d25155') if abs(angle)<.01 else None
def person(c,x,y,s,t,reflected=False,final=False):
 p=pose(t+2 if reflected else t)
 if final:p=dict(wash=0,raised=0,phone=0,grab=0,vanish=0)
 if p['vanish']>.99:return
 v=p['vanish']; c=c.group(x+v*110,y-v*60,s*(1-.38*v))
 breath=math.sin(t*2.7)*1.2;wash=p['wash'];gr=p['grab'];r=p['raised'];ph=p['phone']
 lean=wash*20+gr*16
 c.ellipse((-70,-7,70,15),'#13232a')
 for side in (-1,1):
  hip=(side*23,-145); knee=(side*27+gr*side*16,-77-gr*8);foot=(side*31+v*side*24,-15)
  stroke(c,hip,knee,'#2a3540',30);stroke(c,knee,foot,'#24303c',26)
  c.round((foot[0]-18,-23,foot[0]+26,-3),7,'#18202b',INK,2);c.line([(foot[0]-15,-5),(foot[0]+23,-5)],'#6a7478',3)
 c=c.group(lean,-breath)
 outlined(c,[(-44,-277),(36,-281),(49,-161),(27,-145),(-33,-146),(-50,-163)],'#85374b')
 c.poly([(27,-278),(36,-281),(49,-161),(28,-147),(24,-200)],'#532b40')
 c.line([(-29,-173),(-9,-182),(24,-169)],'#a5505b',2)
 c.rect((-13,-303,13,-273),SKIN)
 outlined(c,[(-20,-280),(-2,-261),(-13,-245),(-33,-273)],'#a15361',1)
 outlined(c,[(17,-282),(-2,-261),(12,-248),(29,-276)],'#a15361',1)
 c.line([(0,-259),(2,-154)],'#c07578',2)
 for yy in (-232,-206,-180):c.ellipse((1,yy,4,yy+4),'#d5a08e')
 c.round((14,-245,34,-225),2,'#713347');c.line([(15,-240),(33,-240)],'#ab5d69',1)
 left=mix((-51,-142),(-33,-285),wash)
 right=mix((51,-142),(31,-285),wash)
 right=mix(right,(80,-325),r)
 left=mix(left,(-60,-264),ph*(1-gr))
 if gr: right=mix(right,(81,-286),gr);left=mix(left,(-80,-279),gr)
 arm(c,(-39,-264),left,1);arm(c,(36,-264),right,-1)
 hand(c,*left,grip=ph>.5);hand(c,*right,raised=r>.5 or gr>.5)
 if ph>.1 and not gr:phone(c,left[0],left[1]-20)
 look=-(E(t,27,27.5)-E(t,32,33)) if not final else E(t,54,56)*.5
 fear=.2+.7*E(t,7,10)
 head(c,look*10,-331+wash*55,t,fear if not final else .15,look, E(t,55,57) if final else 0, amplitude(t) if final and t>56 else 0)
 if wash>.2:
  for i in range(6):
   dy=(t*150+i*17)%65;c.line([(-14+i*6,-283+dy),(-14+i*6,-278+dy)],'#93c4cb',2)
 if gr>.1:
  # Black hand physically closes on shoulder, with individually articulated digits.
  c.line([(80,-350),(64,-297),(35,-268)],'#11141e',22)
  for i in range(4):stroke(c,(35+i*3,-271),(30+i*5,-250+math.sin(i)*3),'#181722',5)
  c.line([(28,-263),(40,-257),(29,-252)],'#b96c70',2)
def door(c,x,y,w,h,op,t):
 c.rect((x-9,y-9,x+w+9,y+h+9),'#17252b');c.rect((x,y,x+w,y+h),'#622b3b')
 for i in range(6):c.rect((x+i*w/6,y,x+(i+1)*w/6,y+h),['#6f2937','#772a37','#852b36','#942c38','#ab3542','#bf4250'][i])
 c.poly([(x,y+h),(x+w,y+h),(x+w+80,y+h+100),(x-30,y+h+60)],'#512936')
 ww=max(8,w*(1-op*.94));dy=op*35
 pts=[(x,y),(x+ww,y+dy),(x+ww,y+h-dy),(x,y+h)]
 outlined(c,pts,'#302b36',3)
 c.line([(x+13,y+20),(x+ww-8,y+dy+20),(x+ww-8,y+h-dy-20)],'#62505a',2)
 if ww>25:
  c.line([(x+ww-16,y+h*.52),(x+ww-30,y+h*.52)],'#c5a18a',5)
def room(c,t,mirror=False):
 c.rect((-100,-100,820,1400),'#223f49')
 c.poly([(-100,-100),(820,-100),(720,130),(0,130)],'#172c36')
 for row in range(12):
  yy=130+row*71
  for col in range(11):
   xx=col*73-39+(row%2)*0
   c.rect((xx,yy,xx+70,yy+68),'#31535b' if (row+col)%3 else '#345960')
   c.line([(xx+3,yy+65),(xx+67,yy+65)],'#203d46',1)
 c.poly([(-100,980),(820,980),(820,1400),(-100,1400)],'#24343f')
 for i in range(-4,10):c.line([(360+(i-3)*45,980),(360+(i-3)*200,1400)],'#49606a',2)
 for yy in (1010,1060,1135,1240,1380):c.line([(-100,yy),(820,yy)],'#4a5b65',2)
 door(c,32,225,180,700,E(t,28,29.5),t)
 c.line([(30,180),(55,175),(72,192),(89,196)],'#152e38',2)
 # Practical overhead tube and mounting bracket.
 c.round((285,109,683,155),10,'#142e38',INK,3)
 c.round((302,120,667,141),7,'#a6d7d0');c.line([(310,125),(657,125)],'#e3efe1',4)
def mirror(c,t):
 c.round((286,183,695,833),7,'#101d2a','#62747a',3)
 c.rect((301,200,680,817),'#27454d')
 for yy in range(205,820,60):c.line([(303,yy),(678,yy)],'#365b62',1)
 for xx in range(305,680,62):c.line([(xx,202),(xx,815)],'#365b62',1)
 door(c,312,268,95,513,E(t+2,28,29.5),t)
 person(c,510,965,1.52,t,True,t>=51)
 # Mask lower body outside mirror with basin/cabinet later. Edge glints.
 c.line([(306,204),(675,204),(675,813)],'#6b9397',2)
 c.line([(319,218),(347,218)],'#b3c3bb',2)
 c.poly([(656,205),(660,205),(620,816),(616,816)],'#3d5c65')
def basin(c,t):
 outlined(c,[(254,859),(692,859),(672,1095),(291,1095)],'#263a45',3)
 c.line([(478,896),(478,1080)],'#101f2b',2)
 for xx in (452,500):c.round((xx,933,xx+8,985),3,'#759198')
 outlined(c,[(226,807),(682,807),(718,858),(689,935),(280,935),(230,880)],'#9caeaa',3)
 c.ellipse((272,820,665,908),'#6d898a',INK,2);c.ellipse((298,831,643,891),'#45666d')
 c.ellipse((465,864,503,878),'#162e39','#9bb6b2',2)
 c.round((472,754,502,823),8,'#789294',INK,2);c.round((484,750,551,770),8,'#a5bbba',INK,2)
 c.line([(490,754),(543,754)],'#d6ddd1',4)
 c.line([(484,748),(470,737),(491,737)],'#c4d0c9',5)
 if t<6:
  for i in range(3):c.line([(541+i*2,770),(540+i*2,857)],'#8ec3ca',2)
  for i in range(4):
   rr=(t*30+i*5)%22;c.ellipse((542-rr,851-rr*.2,542+rr,851+rr*.2),None,'#8dc2c4',1)
 else:
  yy=770+((t*32)%87);c.ellipse((540,yy,544,yy+7),'#9ec9c9')
def caption(im,t):
 for a,b,text in CAPTIONS:
  if a<=t<b:
   d=ImageDraw.Draw(im);font=ImageFont.truetype(str(ROOT/'fonts/Mukta-Regular.ttf'),round(29*g.SCALE))
   lines=text.split('|');yy=(1137-(len(lines)-1)*18)*g.SCALE
   for line in lines:
    d.text((W/2,yy),line,font=font,fill='#f2eee5',anchor='mm',stroke_width=max(1,round(2*g.SCALE)),stroke_fill='#101922');yy+=38*g.SCALE
   break
def frame(t):
 im=Image.new('RGB',(W,H),'#15242e');base=C(im)
 # Camera cuts on story beats; smooth movements within each shot.
 if t<8:z=1+.035*E(t,0,8);cx,cy=360,620
 elif t<18:z=1.10+.035*E(t,8,18);cx,cy=390,600
 elif t<24:z=1.17;cx,cy=280,690
 elif t<35:z=1.02;cx,cy=355,620
 elif t<40:z=1.20+.055*E(t,35,40);cx,cy=460,560
 elif t<51:z=1.08;cx,cy=385,650
 else:z=1.03+.13*E(t,51,59);cx,cy=480,650-90*E(t,51,57)
 shake=(math.sin(t*68)*2)*(E(t,46,46.1)-E(t,46.4,46.9))
 c=base.group(cx*(1-z)+shake,cy*(1-z),z)
 room(c,t)
 # Draw mirror on a clipped transparent layer to guarantee reflection never escapes.
 layer=Image.new('RGB',(W,H));mc=C(layer,c.x,c.y,c.s);mirror(mc,t)
 box=tuple(round(v) for v in c.box((286,183,695,833)))
 im.paste(layer.crop(box),box[:2])
 basin(c,t)
 if t<51:person(c,170,1080,1.80,t)
 if 49<=t<51:
  u=(t-49)/2;y=lerp(685,1040,min(1,u*1.8));bounce=max(0,math.sin((u-.55)*12))*25 if u>.55 else 0
  phone(c,280+u*70,y-bounce,u*3.7)
 elif t>=51:phone(c,350,1040,1.5)
 # Water flecks, atmospheric dust, and practical light give environmental movement.
 for i in range(14):
  xx=(i*83+math.sin(t*.25+i)*12)%720;yy=(i*139+t*(4+i%3))%1080
  c.ellipse((xx,yy,xx+1.2,yy+1.2),'#6d8588')
 caption(im,t)
 return im

# Raw narration segments are placed without time-stretching to leave space for acting.
SEGMENTS=[(0,5.95,.4),(6.5,9.15,7.3),(9.6,11.6,10),(11.65,14.9,12.3),(15,18.1,19.2),(18.2,20.9,25.1),(20.95,23.9,28.3),(24.05,26.55,31.4),(26.7,30.9,35),(31,34.65,41),(34.8,39.05,45.2),(40.35,43.15,53),(43.4,45.04,57)]
CAPTIONS=[(.4,3,'Raghav ka chehra paani mein jhuka tha.'),(3.5,6.3,'Lekin aaine mein...|woh use dekh raha tha.'),(7.4,10,'Usne socha, neend kam hui hai.'),(10.1,12,'Phir parchhaai ne haath uthaya.'),(12.4,13.5,'Do second baad...'),(13.7,15.7,'uska apna haath uth gaya.'),(19.3,20.8,'Raghav ne phone nikala.'),(21,22.4,'Sab record karna tha.'),(25.2,28,'Tabhi aaine mein|peechhe ka darwaaza khula.'),(28.4,29.8,'Usne palatkar dekha.'),(30,31.2,'Darwaaza band tha.'),(31.5,32.6,'Do second baad...'),(32.7,34,'woh bhi khul gaya.'),(35.1,37.2,'Aaina der se nahi chal raha tha.'),(37.4,39.3,'Woh do second aage tha.'),(41.1,44.6,'Phir aaine mein uske kandhe par|ek kaala haath aaya.'),(45.3,47.2,'Raghav peechhe hatna chahta tha.'),(47.4,49.5,'Magar do second beet chuke the.'),(53.1,54.4,'Bathroom khaali tha.'),(54.8,55.8,'Aaina nahi.'),(57.1,59,'Ab tumhari baari.')]
SR=48000;VOICE=None
def amplitude(t):
 if VOICE is None:return .3+math.sin(t*12)*.2
 a=int(t*SR);v=VOICE[a:a+1600];return min(1,float(np.sqrt(np.mean(v*v)))*8) if len(v) else 0
def make_audio():
 global VOICE
 subprocess.run(['ffmpeg','-y','-v','error','-i',str(ROOT.parent/'assets/voice.mp3'),'-ar',str(SR),'-ac','1',str(OUT/'raw.wav')],check=True)
 sr,v=wavfile.read(OUT/'raw.wav');v=v.astype(np.float64)/32768;VOICE=np.zeros(SR*60)
 for a,b,dest in SEGMENTS:
  q=v[int(a*SR):int(b*SR)].copy();n=min(240,len(q)//2);q[:n]*=np.linspace(0,1,n);q[-n:]*=np.linspace(1,0,n)
  pos=int(dest*SR);VOICE[pos:pos+len(q)]+=q
 rng=np.random.default_rng(418);tt=np.arange(SR*60)/SR
 # Synthesized SFX, room tone and a restrained tension bed.
 noise=rng.normal(0,1,len(tt));lp=sosfilt(butter(2,600,fs=SR,output='sos'),noise)
 bed=.008*np.sin(2*np.pi*53*tt)+.004*np.sin(2*np.pi*79.7*tt)+.008*lp
 tension=np.clip((tt-35)/12,0,1)*.012*np.sin(2*np.pi*(99*tt+.045*tt*tt))
 sound=bed+tension
 def add(at,dur,kind,gain=.1):
  n=int(dur*SR);t=np.arange(n)/SR;ns=rng.normal(0,1,n)
  if kind=='water':s=sosfilt(butter(2,[700,7000],fs=SR,btype='bandpass',output='sos'),ns)*(.5+.2*np.sin(t*23))
  elif kind=='creak':s=(np.sin(2*np.pi*(230*t+45*t*t+2*np.sin(t*8)))+.4*np.sin(2*np.pi*610*t))*np.sin(np.pi*np.minimum(t/dur,1))
  elif kind=='impact':s=(np.sin(2*np.pi*82*t)*np.exp(-t*15)+ns*np.exp(-t*55))
  elif kind=='drop':s=np.sin(2*np.pi*(1400*t-900*t*t))*np.exp(-t*30)
  elif kind=='cloth':s=sosfilt(butter(2,[300,3500],fs=SR,btype='bandpass',output='sos'),ns)*np.sin(np.pi*t/dur)
  else:s=ns*np.exp(-t*60)
  pos=int(at*SR);n=min(n,len(sound)-pos);sound[pos:pos+n]+=s[:n]*gain
 add(.1,5.8,'water',.055);add(5.8,.12,'impact',.05)
 for t in (7.2,9.7,18.7,23,34.5,38.8,52,59.3):add(t,.18,'drop',.05)
 for t in (10,12,14,16,20):add(t,.6,'cloth',.06)
 add(21.5,.08,'click',.035);add(26,1.5,'creak',.035);add(28,1.5,'creak',.075)
 add(44,.5,'cloth',.07);add(46,.6,'cloth',.12);add(49,.6,'cloth',.14)
 add(50.1,.4,'impact',.22);add(50.4,.2,'impact',.08)
 # Strategic quiet before the grab, and quiet room after disappearance.
 sound[(tt>43.7)&(tt<44)]*=.1;sound[tt>51]*=.25
 stereo=np.stack([VOICE+sound,VOICE+sound*.92],axis=1)
 stereo*=.89/max(.89,np.max(np.abs(stereo)));stereo[-2400:]*=np.linspace(1,0,2400)[:,None]
 wavfile.write(OUT/'Do_Second_Late_Mix.wav',SR,(stereo*32767).astype(np.int16))
 def stamp(t):
  ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
 (OUT/'Do_Second_Late_Hinglish.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(a)} --> {stamp(b)}\n'+s.replace('|','\n') for i,(a,b,s) in enumerate(CAPTIONS)),encoding='utf8')
def render():
 target=OUT/('Do_Second_Late_4K.mp4' if '--4k' in sys.argv else 'Do_Second_Late_1080p.mp4')
 temp=target.with_name('render_'+uuid.uuid4().hex+'.mp4')
 cmd=['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-i',str(OUT/'Do_Second_Late_Mix.wav'),'-c:v','libx264','-preset','ultrafast','-crf','19','-pix_fmt','yuv420p','-threads','4','-c:a','aac','-b:a','192k','-t','60','-movflags','+faststart',str(temp)]
 p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 for i in range(FPS*60):
  p.stdin.write(frame(i/FPS).tobytes())
  if i%(FPS*5)==0:print(f'Render {i/FPS:.0f}/60s',flush=True)
 p.stdin.close();assert p.wait()==0
 temp.replace(target)
 print(target,flush=True)
if __name__=='__main__':
 make_audio()
 if '--render' in sys.argv:render()
 else:
  times=[1,3,5,11,13,21,26.8,28.8,37,44.5,46.5,49.5,54,57.5]
  sheet=Image.new('RGB',(7*216,2*384))
  for i,t in enumerate(times):
   im=frame(t);im.save(OUT/f'qa_{t}.jpg');sheet.paste(im.resize((216,384)),((i%7)*216,(i//7)*384))
  sheet.save(OUT/'contact_sheet.jpg')
