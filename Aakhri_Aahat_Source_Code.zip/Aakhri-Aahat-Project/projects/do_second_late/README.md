# Do Second Late — Python animation

60-second original horror short, 24 fps, vertical 9:16.
All video frames are drawn using Python/Pillow procedural geometry; no AI-generated video is used. Hindi narration reuses the previously generated Viraj recording. All effects and the atmosphere bed are synthesized locally with NumPy/SciPy.

## Rebuild
Install Python dependencies from requirements.txt and make ffmpeg available. Run `python render.py --render --4k` for the native 2160×3840 master. Run without --4k for 1080×1920. Run without --render for contact sheets and audio.

## Timing
Real pose uses pose(t); reflected pose uses pose(t+2). The hand raises at real 12s / reflection 10s, lowers at 16s / 14s. Door at real 28s / reflection 26s. Shoulder grab at real 46s / reflection 44s; disappearance at 49s / 47s. All are separated by 48 frames at 24fps. The final reflection is intentionally independent after 51s.

## Style and limits
Stylized articulated 2D rig with interpolated joints, hand poses, face acting, camera easing, procedural sound, and plain subtitles. The motions are deliberately rigged; this is not hand-drawn frame-by-frame character animation. The 4K render draws geometry at target resolution.

## Credits
Original story and production prepared for the user. Mukta font by Ek Type, SIL Open Font License. Hindi voice recording supplied from the earlier approved production.
