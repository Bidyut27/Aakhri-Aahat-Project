"""Attendance: exactly 1800 frames at 30 fps. Native flat 2D geometry, 4K master."""
from pathlib import Path
import math,json,sys,subprocess
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from scipy.io import wavfile
import primitives as g
from primitives import C,limb,ease,lerp
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
g.SCALE=3 if '--4k' in sys.argv else 1.5
W,H=int(720*g.SCALE),int(1280*g.SCALE);FPS=30;DURATION=60
P={'bg':'#0B0B0D','wall':'#222226','floor':'#343236','edge':'#797577','red':'#C62828','light':'#FF625A','white':'#F5F0E6','skin':'#BD957F','grey':'#aaa29e'}
T=json.loads((ROOT/'timeline.json').read_text()) if (ROOT/'timeline.json').exists() else []
audio_path=ROOT/'audio/Viraj_Synced.wav'
if audio_path.exists():
 sr,v=wavfile.read(audio_path);v=v.astype(float)/32768
else:sr=48000;v=np.zeros(sr*60)
FONT_CACHE={}
def txt(c,xy,s,size=26,col=None,bold=False,mono=False):
 key=(round(size*c.s*g.SCALE),bold,mono)
 if key not in FONT_CACHE:
  path='/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf' if mono else ROOT/'fonts'/('Mukta-ExtraBold.ttf' if bold else 'Mukta-Regular.ttf')
  FONT_CACHE[key]=ImageFont.truetype(str(path),max(1,key[0]))
 c.d.text(c.pt(xy),s,font=FONT_CACHE[key],fill=col or P['white'],anchor='mm')
def amplitude(t):
 a=int(max(0,t)*sr);b=min(len(v),a+1200)
 return min(1,float(np.sqrt(np.mean(v[a:b]**2)))*10) if b>a else 0


def head(c,x,y,s,t,gaze=0,fear=0,talk=False):
 c=c.group(x,y,s)
 c.ellipse((-47,-24,-31,11),'#ba8e79');c.ellipse((32,-25,47,10),'#ba8e79')
 c.poly([(-39,-62),(-15,-80),(23,-73),(40,-46),(36,20),(20,46),(-12,49),(-33,28)],'#c29a83')
 c.poly([(20,-67),(40,-46),(36,20),(20,46),(8,47),(24,13),(26,-34)],'#9f735f')
 c.poly([(-41,-18),(-47,-53),(-30,-81),(-4,-93),(27,-81),(44,-55),(39,-29),(23,-48),(7,-55),(-15,-38),(-31,-42),(-31,-14)],'#17151c')
 c.line([(-37,-58),(-15,-75),(8,-77),(29,-62)],'#4d353d',3)
 c.line([(-30,-48),(-7,-64),(13,-63)],'#413039',2)
 for xx in [-16,15]:
  c.line([(xx-10,-25-(fear*5 if xx<0 else 0)),(xx+9,-25-(fear*5 if xx>0 else 0))],'#33232a',4)
  if t%4.7>4.53:c.line([(xx-8,-11),(xx+8,-11)],'#402d30',2)
  else:
   c.ellipse((xx-10,-18,xx+10,-3+fear*3),'#f1e2d0');c.ellipse((xx-4+gaze*3,-16,xx+4+gaze*3,-4),'#30232c');c.ellipse((xx-1+gaze*3,-14,xx+1+gaze*3,-11),'#fff3e0')
 c.line([(2,-8),(8,9),(0,12)],'#8c6052',2)
 m=amplitude(t) if talk else .15*fear
 if m>.08:c.ellipse((-11,24,10,28+m*14),'#45232b')
 else:c.line([(-11,27),(-1,25),(11,27)],'#6a3f3b',2)
 c.line([(-25,25),(-14,39),(10,41),(25,27)],'#785849',3)
 for xx,yy in [(-22,26),(-17,30),(-12,34),(15,32),(21,25),(-8,39),(6,39)]:c.line([(xx,yy),(xx+1,yy+3)],'#4d3834',1)
 if fear>.5:c.poly([(32,-4),(28,11),(34,16),(37,11)],'#e7c1a8')

def person(c,x,y,s,t,pose='idle',gaze=0,talk=False):
 c=c.group(x,y,s);run=pose=='run';bob=abs(math.sin(t*11))*7 if run else math.sin(t*2)*1.2;c=c.group(0,-bob)
 c.ellipse((-71,-8,72,12),'#101016')
 for xx,sign in [(-24,-1),(24,1)]:
  sw=math.sin(t*11)*36*sign if run else 0
  limb(c,(xx,-158),(xx+sw*.45,-87-abs(sw)*.2),'#292733',30);limb(c,(xx+sw*.45,-87-abs(sw)*.2),(xx+sw,-18),'#24222d',25)
  c.round((xx+sw-16,-23,xx+sw+29,-3),6,'#8e8381');c.rect((xx+sw-16,-8,xx+sw+29,-2),'#39323d')
 c.poly([(-45,-284),(42,-284),(55,-167),(29,-145),(-39,-150),(-53,-178)],'#762e40')
 c.poly([(31,-280),(44,-278),(55,-168),(30,-147),(22,-164)],'#4e2233')
 c.rect((-14,-307,14,-276),'#b98d77')
 c.poly([(-17,-283),(0,-265),(-12,-246),(-31,-278)],'#a64a59');c.poly([(17,-283),(0,-265),(13,-245),(31,-276)],'#a64a59')
 c.line([(0,-263),(2,-157)],'#bd6872',2)
 for yy in [-236,-209,-182]:c.ellipse((-1,yy,3,yy+4),'#d39791')
 c.line([(-17,-274),(-2,-210),(18,-274)],'#1b1a23',5);c.round((-13,-211,16,-173),3,'#ded2bf');c.rect((-8,-205,11,-196),'#862b3c');c.line([(-7,-188),(9,-188)],'#62535a',2)
 c.round((17,-244,37,-223),3,'#642739')
 for sign in [-1,1]:
  elbow=(sign*66,-224);hand=(sign*61,-164)
  if run:elbow=(sign*68,-224+math.sin(t*11)*sign*26);hand=(sign*39,-193+math.sin(t*11)*sign*48)
  if pose in ['mobile','receiver'] and sign==-1:elbow=(-87,-239);hand=(-49,-329)
  if pose=='reach' and sign==1:elbow=(85,-240);hand=(119,-273)
  if pose=='shock':elbow=(sign*78,-227);hand=(sign*78,-272)
  limb(c,(sign*43,-269),elbow,'#762e40',25);limb(c,elbow,hand,'#c29a83',18);c.ellipse((hand[0]-11,hand[1]-10,hand[0]+11,hand[1]+10),'#c29a83')
  if pose=='mobile' and sign==-1:c.round((-61,-361,-36,-303),5,'#131820','#8c6b7d',2)
  if pose=='receiver' and sign==-1:receiver(c,-49,-331,.64)
 head(c,0,-336,1,t,gaze,1 if pose in ['shock','receiver','run'] else .35,talk)

def receiver(c,x,y,s=1):
 c=c.group(x,y,s);c.round((-15,-63,15,63),12,'#171923','#8e6374',2)
 c.round((-23,-68,21,-35),9,'#272632');c.round((-23,35,21,68),9,'#272632')
 for yy in [-60,-53,48,55]:c.line([(-10,yy),(10,yy)],'#645565',2)

def keyboard(c,x,y,s,t=0,haunted=False):
 c=c.group(x,y,s);c.poly([(0,0),(250,0),(270,76),(-20,76)],'#34313c')
 for row in range(4):
  for col in range(12):
   xx=col*20+row*-3;yy=9+row*15;down=haunted and (int(t*8)%12==col and int(t*5)%4==row)
   c.round((xx,yy+(3 if down else 0),xx+15,yy+10+(3 if down else 0)),2,'#8e727f' if down else '#57515d')
 c.round((61,66,185,72),2,'#706371')

def chair(c,x,y,s=1,t=0,turn=0):
 c=c.group(x,y,s);w=64-abs(turn)*22
 c.round((-w,-267,w,-113),17,'#252630','#685663',4)
 for yy in range(-248,-131,15):c.line([(-w+12,yy),(w-12,yy)],'#393641',2)
 c.round((-73,-127,75,-102),10,'#34313e','#715565',2)
 c.line([(0,-103),(0,-27)],'#93818b',10)
 for xx,yy in [(-72,0),(72,0),(-38,18),(45,16)]:
  c.line([(0,-28),(xx,yy)],'#675967',7);c.ellipse((xx-9,yy-5,xx+9,yy+7),'#171820')
 for sign in [-1,1]:c.line([(sign*59,-105),(sign*88,-157),(sign*64,-157)],'#72606d',7)

def office(c,t,dark=False):
 c.rect((0,0,720,1280),'#14151e' if dark else '#282633')
 c.poly([(0,0),(720,0),(610,222),(110,222)],'#252530' if dark else '#3c3947')
 for x in [-300,120,600,1040]:c.line([(360,222),(x,0)],'#4c4352' if not dark else '#211c29',2)
 for x in [130,480]:
  c.poly([(x,80),(x+116,80),(x+90,115),(x+15,115)],'#9c303e' if dark else '#e4d9ca')
 c.rect((44,249,485,659),'#0c111c')
 for i in range(9):
  x=49+i*50;h=85+(i%4)*48;c.rect((x,657-h,x+37,657),'#242432')
  for yy in range(679-h,640,30):c.rect((x+11,yy,x+17,yy+9),'#74515b')
 for xx in [43,190,338,486]:c.line([(xx,248),(xx,660)],'#544454',7)
 c.line([(44,446),(487,446)],'#544454',5)
 c.rect((526,294,686,819),'#69515c');c.rect((537,304,675,808),'#19212b')
 c.line([(647,517),(647,589)],'#c2a29e',6)
 c.round((553,244,663,279),4,'#782437');txt(c,(608,263),'EXIT',21,P['white'],True)
 c.round((491,494,522,560),4,'#3b323f');c.rect((496,508,517,528),'#ae4052')
 c.poly([(0,818),(720,818),(720,1280),(0,1280)],'#24212c')
 for xx in [-800,-300,200,700,1200]:c.line([(360,735),(xx,1280)],'#433441',2)
 for yy in [872,951,1067,1220]:c.line([(0,yy),(720,yy)],'#433441',2)
 # Distant desks are fixed landmarks across angles.
 for x in [70,330]:
  c.poly([(x,665),(x+164,665),(x+205,724),(x-20,724)],'#56424e');c.rect((x-10,724,x+1,844),'#6d5663');c.rect((x+182,724,x+193,844),'#6d5663')
  c.round((x+35,578,x+138,661),5,'#0b1018','#6a5061',3);c.rect((x+42,585,x+131,650),'#2a2635' if dark else '#433348')
  c.rect((x+80,661,x+91,678),'#6a5061');keyboard(c,x+52,690,.38)
  chair(c,x+85,857,.55,t)
 c.round((49,162,225,210),5,'#11131b');txt(c,(138,188),'02:00 AM',24,'#cd9ca5',True)

def roster(c,t):
 office(c,t)
 c.rect((0,910,720,1280),'#3c2c39');c.round((37,260,683,868),24,'#151923','#9d778a',6)
 c.round((59,282,661,824),10,'#242b39');c.rect((59,282,661,377),'#7d293f')
 txt(c,(360,332),'ATTENDANCE',43,P['white'],True)
 txt(c,(360,425),'02:00 AM  |  NIGHT SHIFT',23,'#c2a5af')
 for yy,name in [(520,'NIKHIL'),(671,'MEERA')]:
  c.round((83,yy-48,637,yy+53),9,'#343241')
  c.ellipse((107,yy-16,139,yy+16),'#b65265');txt(c,(251,yy),name,36,P['white'],True)
  txt(c,(514,yy),'PRESENT',30,'#e5b1b6',True)
 c.rect((329,869,391,921),'#66505f');c.poly([(245,922),(477,922),(503,945),(215,945)],'#77606d')
 keyboard(c,170,978,1.45)


def emptydesk(c,t,active=False):
 office(c,t)
 c.rect((0,817,720,1280),'#211d28')
 # Empty chair is staged beside the desk, fully readable in silhouette.
 # Chair is visibly empty throughout, placed behind desk.
 c.poly([(53,613),(627,613),(711,813),(5,813)],'#60434f');c.rect((5,813,711,840),'#362330')
 c.rect((40,840,60,1070),'#70505e');c.rect((650,840,670,1070),'#70505e')
 c.round((207,381,513,621),12,'#10131e','#8f6b7c',4);c.rect((221,397,499,602),'#3f2d3f' if active else '#222432')
 if active:
  for j in range(int(t*5)%5+1):c.line([(246,448+j*27),(369+(j%2)*73,448+j*27)],'#c1687c',4)
 else:
  c.line([(239,422),(480,583)],'#3c3343',2)
 c.rect((343,620,376,660),'#6f5263');c.poly([(294,658),(424,658),(447,679),(271,679)],'#7e5c6c')
 keyboard(c,230,711,1,t,active)
 c.round((73,655,189,704),4,'#211c27','#9a6f79',2);txt(c,(132,681),'MEERA',22,P['white'],True)
 c.ellipse((550,724,595,777),'#4b3949');c.line([(571,729),(571,747)],'#b27b8a',2)
 # Dust and a dried plant establish the long-unused desk.
 for i in range(25):
  x=60+(i*83)%590;y=627+(i*29)%175;c.ellipse((x,y,x+2,y+2),'#97737e')
 c.poly([(96,563),(143,563),(136,624),(104,624)],'#713744')
 for x,y in [(94,492),(136,483),(159,526)]:c.line([(121,569),(x,y)],'#8f715e',3);c.poly([(x,y),(x-14,y-10),(x-8,y+14)],'#7b6556')

 chair(c,553+math.sin(t*2)*3 if active else 553,1048,1.0,t,math.sin(t*.9)*.3 if active else .1)

def mobilecall(c,t):
 office(c,t);person(c,365,1101,1.65,t,pose='mobile',gaze=1,talk=13<t<16)
 c.round((423,303,679,423),12,'#171a26','#7f4c65',2);txt(c,(550,344),'SECURITY',28,P['white'],True)
 for i in range(17):
  h=7+12*abs(math.sin(t*7+i*1.3));c.line([(452+i*12,389-h),(452+i*12,389+h)],'#cb7f94',3)

def scanner(c,t):
 office(c,t);c.rect((0,0,720,1280),'#29232f')
 c.rect((476,150,720,1111),'#141c27');c.line([(640,495),(640,747)],'#ac8d98',12)
 c.round((90,265,504,838),23,'#151923','#947382',5)
 c.round((118,299,477,517),10,'#2a3040');txt(c,(298,342),'NIKHIL',36,P['white'],True)
 done=t>=29.4
 txt(c,(298,403),'CHECKOUT' if done else 'PLACE FINGER',31,'#f1c4c2' if done else '#af99a7',True)
 if done:txt(c,(298,460),'SUCCESSFUL',31,'#f1c4c2',True)
 c.round((221,582,375,739),15,'#6f334b' if done else '#29313f','#b26d83',3)
 # Fingerprint rings are graphical device content.
 for k in range(5):c.ellipse((254-k*5,619-k*6,342+k*5,693+k*6),None,'#cf8092',2)
 u=ease((t-27.4)/.9);hx=lerp(623,300,u);hy=lerp(1063,673,u)
 c.poly([(hx-40,hy+195),(hx+70,hy+195),(720,1280),(502,1280)],'#762e40')
 c.round((hx-36,hy+25,hx+65,hy+211),27,'#bb8e79');c.round((hx-24,hy-40,hx+20,hy+133),21,'#cba28c');c.round((hx-17,hy-28,hx+13,hy+3),9,'#dfb8a0')
 for j in range(3):c.round((hx+17+j*15,hy+83+j*10,hx+34+j*15,hy+157+j*10),8,'#c19882')

def printer(c,t):
 office(c,t,True);c.rect((0,0,720,1280),'#15131e');c.poly([(0,816),(720,816),(720,1200),(0,1200)],'#3d2837')
 c.round((84,338,637,786),28,'#45404d','#876878',4);c.poly([(113,337),(603,337),(563,268),(152,268)],'#645060')
 c.round((133,413,587,563),12,'#12131c');c.rect((153,445,568,476),'#080a11');c.ellipse((559,362,576,379),'#d86c7b')
 txt(c,(235,379),'OFFICE PRINTER',19,'#d1b7c1',True)
 # The sheet emerges physically from the slot, growing downward.
 amount=ease((t-35.3)/2.2);bottom=lerp(477,984,amount)
 c.poly([(172,476),(550,476),(570,bottom),(152,bottom)],P['white'])
 if amount>.7:
  txt(c,(360,580),'ATTENDANCE',32,'#392c37',True)
  c.line([(190,624),(531,624)],'#897581',2)
  txt(c,(360,697),'NIKHIL - ABSENT',29,'#7e293e',True)
  txt(c,(360,776),'MEERA - PRESENT',29,'#332834',True)
  txt(c,(360,886),'02:00 AM',23,'#796574')


def deskphone(c,t,raised=False):
 c.round((157,677,583,895),25,'#34313f','#8d6277',4);c.round((325,709,533,771),6,'#61716e');txt(c,(429,741),'INCOMING CALL',21,'#121f25',True)
 for row in range(3):
  for col in range(3):
   x=352+col*53;y=794+row*25;c.round((x,y,x+36,y+16),3,'#766573')
 if not raised:
  dx=math.sin(t*48)*3;c.round((188+dx,660,266+dx,889),27,'#171921','#896276',3)
  for yy in [673,836]:c.round((177+dx,yy,281+dx,yy+44),14,'#272634')
 # Coiled cord remains attached.
 for j in range(20):
  x=194+math.sin(j*2)*11;y=892+j*7;c.ellipse((x-6,y-4,x+6,y+6),None,'#9a7487',2)

def phone_scene(c,t):
 office(c,t,True)
 c.poly([(0,641),(720,641),(720,1031),(0,1031)],'#553344');c.round((438,582,671,634),4,'#16151e','#956471',2);txt(c,(555,608),'NIKHIL',28,P['white'],True)
 deskphone(c,t)
 if t>44:
  u=ease((t-44)/1);c.round((lerp(75,176,u),lerp(1041,748,u),lerp(167,267,u),lerp(1201,899,u)),31,P['skin'])

def finalcall(c,t):
 office(c,t,True)
 c.poly([(0,1114),(720,1114),(720,1280),(0,1280)],'#3a2634')
 # Tight character close-up: listening mouth stays still while his own voice comes from receiver.
 person(c,351,1465,2.8,t,pose='receiver',gaze=lerp(1,-1,ease((t-49)/3)),talk=False)
 for j in range(22):
  x=216+math.sin(j*2)*10;y=735+j*13;c.ellipse((x-7,y-5,x+7,y+5),None,'#a9788b',2)
 # No physical second person: the impossible identity comes from the voice and slip.

def outro(c,t):
 c.rect((0,0,720,1280),P['bg']);c.line([(90,223),(630,223)],P['red'],4)
 txt(c,(360,375),'SUBSCRIBE',78,P['red'],True);txt(c,(360,462),'karein',45)
 txt(c,(360,658),'FACEBOOK',56,P['white'],True);txt(c,(360,724),'aur',29)
 txt(c,(360,791),'INSTAGRAM',56,P['white'],True);txt(c,(360,912),'pe FOLLOW karein',44,P['light'],True)

def frame(t):
 im=Image.new('RGB',(W,H),P['bg']);c=C(im)
 if t>=54:outro(c,t);return im
 if t<2.2:office(c,t);person(c,364,1110,1.23,t,gaze=1)
 elif t<9.8:roster(c,t)
 elif t<13:emptydesk(c,t)
 elif t<20:mobilecall(c,t)
 elif t<25:emptydesk(c,t,True)
 elif t<27.3:
  office(c,t);person(c,lerp(199,517,ease((t-25)/2.3)),1127,1.24,t,pose='run',gaze=1)
 elif t<32:scanner(c,t)
 elif t<34.4:
  office(c,t,True);person(c,535,1080,1.15,t,pose='shock',gaze=-1)
  if 32<t<32.28 or 32.4<t<32.53:im=Image.new('RGB',(W,H),'#08080e')
 elif t<42:printer(c,t)
 elif t<46:phone_scene(c,t)
 else:finalcall(c,t)
 # Subtitles stay fixed to the final master frame.
 c=C(im);r=next((r for r in T if r['start']<=t<r['end']),None)
 if r:
  lines=r['caption'].split('\n');h=44*len(lines)+36;c.round((32,1177-h,688,1177),10,P['bg'])
  for i,line in enumerate(lines):txt(c,(360,1177-h+35+i*44),line,32,P['white'])
 return im

def preview():
 times=[1,5,11,16,22,26,30,33,39,43,50,56]
 sheet=Image.new('RGB',(1200,730),P['bg']);d=ImageDraw.Draw(sheet)
 for i,t in enumerate(times):
  im=frame(t);im.save(OUT/f'qa_{t}.jpg',quality=90);x=i%6*200;y=i//6*365
  sheet.paste(im.resize((200,356)),(x,y));d.text((x+7,y+349),str(t)+'s',fill='white')
 sheet.save(OUT/'contact_sheet.jpg',quality=92)

def render():
 name='Attendance_4K.mp4' if '--4k' in sys.argv else 'Attendance_1080p.mp4'
 p=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{W}x{H}','-framerate','30','-i','pipe:0','-i',str(ROOT/'audio/Final_Mix.wav'),'-c:v','libx264','-threads','4','-preset','veryfast','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-movflags','+faststart','-t','60',str(OUT/name)],stdin=subprocess.PIPE)
 for i in range(1800):
  p.stdin.write(frame(i/30).tobytes())
  if i%150==0:print(f'{i/30:.0f}/60 seconds rendered',flush=True)
 p.stdin.close();assert p.wait()==0;print('Complete',flush=True)
if __name__=='__main__':
 if '--preview' in sys.argv:preview()
 if '--render' in sys.argv:render()
