# Attendance

Original fictional Hindi office horror short. Exactly 60 seconds, vertical 9:16, 30 fps.

## Deliverables
- output/Attendance_4K.mp4 — native 2160 x 3840 master
- output/Attendance_1080p.mp4 — 1080 x 1920 sharing copy
- output/Attendance_Hinglish.srt — plain Roman Hindi subtitles
- Thumbnail_9x16.png — illustrated black/crimson cover
- output/Attendance_Social_Media.md — ready-to-post YouTube, Instagram and Facebook copy

## Rebuild
Requires Python 3, Pillow, NumPy, SciPy and ffmpeg.
Run `python prepare.py`, then `python render.py --4k --render`.
For native 1080p use `python render.py --render`.
Preview scenes using `python render.py --preview`.
Run `python check_export.py` after both MP4s exist.

## Creative choices
Flat 2D animation with articulated limbs, running, phone gestures, blinking, expressive eyes, animated keyboard keys, scanner contact, light cut, paper feed and phone vibration. Close-ups prioritize readable attendance names and printed text. The character listening at the end does not move his mouth: the identical voice is coming from the receiver.

Regular-weight off-white centered Hinglish subtitles, no highlights. Black/crimson visual language. No channel name on screen. Six-second closing card uses bold SUBSCRIBE, FACEBOOK, INSTAGRAM and FOLLOW.

## Scene order
0–6: Nikhil alone; attendance shows two names.
6–13: Night roster and Meera's long-unused desk.
13–20: Call to security; warning not to check out.
20–25: Empty chair and moving keyboard keys.
25–29: Run to exit, finger reaches scanner.
29–32: Checkout successful.
32–36: Lights cut; printer starts.
36–42: Paper shows NIKHIL - ABSENT and MEERA - PRESENT.
42–48: Desk phone rings; Nikhil answers.
48–54: His own voice reports an intruder; brief suspense hold.
54–60: Subscribe/follow ending.

## Editable files
render.py and primitives.py: original geometry and animation.
prepare.py: scene cuts, captions, pauses, sound synthesis and mix.
timeline.json and edit.json: final subtitle times and voice source mapping.
Narration_Hindi.txt: final Hindi script with performance tags.
audio/word_timings.json: source timing reference; tags are not subtitles.
audio/Viraj_original.mp3: ElevenLabs eleven_v4 narration, Viraj - Deep, Suspenseful and Mysterious.
audio/Viraj_Synced.wav: original-speed narration with pauses.
audio/Music_and_Effects.wav: original synthesized office ambience and SFX.
audio/Final_Mix.wav: 48 kHz stereo mix.
fonts/: bundled Mukta fonts with license.

## QA
Caption bounds and source segment durations checked before export. Audio is exactly 60 seconds with peak headroom. Final exports checked for 1800 frames, 30 fps, 9:16 dimensions and full ffmpeg decode without errors. Thumbnail illustration is distinct from the flat 2D movie rendering.
