from pathlib import Path
import json,subprocess
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter,sosfilt
from scipy.ndimage import uniform_filter1d,maximum_filter1d
ROOT=Path(__file__).resolve().parent;SR=48000
SEG=[(0, 4.9, 0, 6, 'hook'), (4.9, 10.9, 6, 13, 'roster'), (10.9, 17.2, 13, 20, 'guard'), (17.2, 21, 20, 25, 'keys'), (21, 23.8, 25, 29, 'run'), (23.8, 25.5, 29, 32, 'checkout'), (25.5, 28.8, 32, 36, 'dark'), (28.8, 33.5, 36, 42, 'print'), (33.5, 38.9, 42, 48, 'phone'), (38.9, 42.5, 48, 54, 'voice'), (42.5, None, 54, 60, 'outro')]
CAPS=[(0.08, 1.92, 'Office mein main akela tha.'), (1.96, 4.88, 'Lekin attendance mein...\ndo log present the.'), (4.92, 8.48, 'Raat 2 baje, mere naam ke\nneeche Meera ka naam tha.'), (8.56, 10.88, 'Uski desk pichhle saal se\nkhaali thi.'), (10.9, 12.4, 'Maine guard ko phone kiya.'), (12.44, 13.68, 'Meera present dikh rahi hai.'), (14.144, 16.16, 'Woh bola, apna\ncheckout mat karna.'), (16.32, 16.96, 'Main aa raha hoon.'), (17.36, 19.52, 'Tabhi Meera ki\nkhaali desk se...'), (19.56, 20.96, 'Keyboard ki awaaz aayi.'), (21, 22.16, 'Main darwaaze ki taraf bhaaga.'), (22.48, 23.6, 'Scanner par ungli rakh di.'), (24, 25.28, 'Checkout successful.'), (25.76, 27.28, 'Saari lights bujh gayin.'), (27.36, 28.56, 'Andhere mein printer chala.'), (28.96, 30.32, 'Parchi par likha tha...'), (30.36, 32, 'Nikhil... absent.'), (32.08, 33.28, 'Meera... present.'), (33.76, 35.28, 'Meri desk ka phone baja.'), (35.36, 36.16, 'Maine uthaya.'), (36.4, 38.8, 'Doosri taraf...\nmeri hi awaaz thi.'), (39.109, 40.64, 'Hello, security?'), (40.68, 42.36, 'Mere office mein\nkoi ghus aaya hai.'), (42.704, 46.06, 'Subscribe karein aur Facebook,\nInstagram pe follow karein.')]
def stamp(t):
 n=round(t*1000);return f'{n//3600000:02}:{n//60000%60:02}:{n//1000%60:02},{n%1000:03}'
def main():
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(ROOT/'audio/Viraj_original.mp3'),'-af','loudnorm=I=-18:TP=-3:LRA=9','-ar',str(SR),'-ac','1',str(ROOT/'audio/voice_normalized.wav')],check=True)
 _,v=wavfile.read(ROOT/'audio/voice_normalized.wav');v=v.astype(float)/32768;voice=np.zeros(SR*60);edits=[]
 for a,b,start,end,scene in SEG:
  b=b if b is not None else len(v)/SR;dest=start+.12
  # Build in extra silence before the final whispered line and CTA.
  if scene=='outro':dest=54.7
  clip=v[round(a*SR):round(b*SR)].copy();fade=min(96,len(clip)//2);clip[:fade]*=np.linspace(0,1,fade);clip[-fade:]*=np.linspace(1,0,fade)
  assert dest+len(clip)/SR<=end+.001,(scene,dest,len(clip)/SR,end)
  at=round(dest*SR);voice[at:at+len(clip)]=clip
  edits.append(dict(source_start=a,source_end=b,start=start,end=end,scene=scene,voice_start=dest))
 def mapped(t):
  for r in edits:
   if r['source_start']<=t<=r['source_end']:return r['voice_start']+t-r['source_start']
  return 59
 rows=[dict(start=mapped(a),end=mapped(b),caption=cap) for a,b,cap in CAPS]
 (ROOT/'timeline.json').write_text(json.dumps(rows,indent=2));(ROOT/'edit.json').write_text(json.dumps(edits,indent=2))
 n=len(voice);t=np.arange(n)/SR;rng=np.random.default_rng(409);fx=np.zeros((n,2))
 def add(at,sound,pan=0):
  i=round(at*SR);k=min(len(sound),n-i)
  if i<0 or k<=0:return
  fx[i:i+k,0]+=sound[:k]*(1-.35*pan);fx[i:i+k,1]+=sound[:k]*(1+.35*pan)
 def tone(d,f,amp):
  q=np.arange(round(d*SR))/SR;return amp*np.sin(2*np.pi*f*q)*np.exp(-q*4)*np.minimum(1,q*180)
 def noise(d,lo,hi,amp):
  q=np.arange(round(d*SR))/SR;x=sosfilt(butter(2,[lo,hi],btype='bandpass',fs=SR,output='sos'),rng.standard_normal(len(q)));return x*amp*np.sin(np.pi*q/d)**2
 # Quiet office ventilation and electrical hum; cut power at 32 seconds.
 air=sosfilt(butter(2,650,fs=SR,output='sos'),rng.standard_normal(n))*.013
 hum=.008*np.sin(2*np.pi*100*t)+.006*np.sin(2*np.pi*50*t)
 drone=.009*np.sin(2*np.pi*46*t)+.005*np.sin(2*np.pi*69.3*t)
 bed=np.column_stack([air+hum+drone,np.roll(air,700)+hum+drone]);bed[t>=32]*=.2;bed[t>=51.8]=0
 # Keyboard events share exact timing with depressed key frames.
 for at in np.arange(20.35,24.8,.18):
  add(float(at),tone(.045,1700,.035)+noise(.045,700,6500,.07),.45)
 for at in [25.15,25.48,25.81,26.14,26.47,26.8]:add(at,tone(.17,110,.075)+noise(.17,250,2000,.03),-.25)
 # Scanner acceptance, relay clicks and power drop.
 add(29.4,tone(.22,1240,.055));add(29.58,tone(.25,1650,.04))
 for at in [32.0,32.4]:add(at,noise(.065,700,7000,.11))
 # Paper feed motor, rollers and paper friction.
 q=np.arange(round(2.3*SR))/SR
 printer=.026*(np.sin(2*np.pi*145*q)+.35*np.sin(2*np.pi*620*q))*(.6+.4*np.sin(q*27)**2)*np.sin(np.pi*q/2.3)**2
 add(34.7,printer+noise(2.3,450,3300,.035),.4)
 add(37,noise(.35,700,5200,.045),.4)
 # Telephone ring in two short bursts; ends when the handset is lifted.
 for at in [42.05,42.8,43.55]:
  q=np.arange(round(.38*SR))/SR;ring=.055*(np.sin(2*np.pi*440*q)+np.sin(2*np.pi*480*q))*.5*np.sin(np.pi*q/.38)**2;add(at,ring,-.4)
 add(44.2,tone(.09,390,.045)+noise(.09,500,2200,.04),-.4)
 # Guard and impossible caller receive a telephone band-limit, identity preserved.
 for a,b in [(14.144,16.96),(39.109,42.36)]:
  lo,hi=round(mapped(a)*SR),round(mapped(b)*SR)
  voice[lo:hi]=.25*voice[lo:hi]+.95*sosfilt(butter(2,[300,3300],btype='bandpass',fs=SR,output='sos'),voice[lo:hi])
 add(51.8,tone(.8,40,.065))
 activity=maximum_filter1d((np.abs(voice)>.012).astype(float),size=9601);duck=uniform_filter1d(.8-.5*activity,size=6001)
 mix=voice[:,None]+bed*duck[:,None]+fx*.72;mix*=min(1,.84/max(np.max(np.abs(mix)),1e-9));mix[-4800:]*=np.linspace(1,0,4800)[:,None]
 for name,data in [('Viraj_Synced',voice),('Music_and_Effects',bed+fx*.72),('Final_Mix',mix)]:wavfile.write(ROOT/f'audio/{name}.wav',SR,(np.clip(data,-1,1)*32767).astype(np.int16))
 (ROOT/'output/Attendance_Hinglish.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(r["start"])} --> {stamp(r["end"])}\n{r["caption"]}' for i,r in enumerate(rows))+'\n')
 (ROOT/'output/qa_audio.json').write_text(json.dumps(dict(duration=60,samples=len(mix),peak_dbfs=float(20*np.log10(np.max(np.abs(mix)))),voice_speed_changed=False,finite=bool(np.isfinite(mix).all())),indent=2))
 print('60 seconds, natural voice speed, peak',20*np.log10(np.max(np.abs(mix))))
if __name__=='__main__':main()
