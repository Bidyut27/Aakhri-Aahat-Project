# Attendance — social media posting package

Original fictional office horror story. Hinglish copy, spoiler-free descriptions. Topic-based hashtags; no claim of current trend status.

## YouTube Shorts

**Title**
Office Mein Akela... Attendance Mein 2? | Hindi Horror

**Description**
Raat 2 baje office mein sirf Nikhil tha. Lekin attendance screen par 2 log present the. Doosra naam Meera ka tha... jiski desk pichhle saal se khaali thi.

Guard ne bas ek baat kahi: “Apna checkout mat karna.”
Aap hote toh rukte ya turant office se nikalte?

Attendance — ek original fictional Hindi horror story, 60-second 2D animation mein.
Subscribe karein aur Facebook, Instagram pe follow karein.

**Hashtags**
#HindiHorror #OfficeHorror #Attendance #HorrorStory #Shorts

**YouTube tags — comma-separated**
attendance horror, office horror story, Hindi horror story, horror story in Hindi, night shift horror, haunted office, empty office horror, mysterious attendance, checkout horror, paranormal story, animated horror, 2D animation, suspense story, horror shorts, scary story

**Pinned comment**
Guard kehta “checkout mat karna” aur khaali desk se typing sunai deti... aap kya karte? 👀

## Instagram Reels

**Cover title**
OFFICE MEIN KAUN HAI?

**Caption**
Office mein akela tha. Attendance mein 2 log present the. 💻
Doosri desk pichhle saal se khaali thi.

“Apna checkout mat karna.”
Aap guard ki baat maante ya exit ki taraf bhaagte?

Attendance | Original fictional Hindi horror story.
Aisi aur kahaniyon ke liye FOLLOW karein. YouTube par subscribe aur FACEBOOK par bhi follow karein.

**Hashtags**
#OfficeHorror #HindiHorror #NightShiftHorror #HorrorReels #AnimatedHorror

## Facebook Reels

**Title**
Office Mein Koi Nahi Tha... Phir Meera Present Kaise Thi?

**Description / caption**
Nikhil raat 2 baje apni shift khatam karke nikal raha tha. Attendance screen par uske naam ke neeche Meera ka naam dikha. Lekin Meera ki desk pichhle saal se khaali thi.

Guard ko phone kiya toh jawab aaya: “Apna checkout mat karna. Main aa raha hoon.”

Aapko yeh system ki galti lagti ya kisi aur ki maujoodgi?

Yeh ek kalpanik office horror kahani hai.
FOLLOW karein; YouTube par subscribe aur INSTAGRAM par bhi follow karein.

**Hashtags**
#OfficeHorror #HindiHorror #NightShift #ScaryStory
