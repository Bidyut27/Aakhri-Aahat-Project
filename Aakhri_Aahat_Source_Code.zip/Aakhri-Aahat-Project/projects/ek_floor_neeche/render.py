"""Ek Floor Neeche. Original procedural 2D animation, native vector geometry rasterized per frame.
python render.py --preview | --render --4k ; run prepare.py first for timed voice and captions.
"""
from pathlib import Path
import sys, math, json, subprocess
import numpy as np
from PIL import Image, ImageDraw
import primitives as g
from primitives import C, limb, ease, lerp
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
g.SCALE=3 if '--4k' in sys.argv else 1.5
W,H=int(720*g.SCALE),int(1280*g.SCALE)
FPS=30
P={'bg':'#0a1521','wall':'#253b46','side':'#172a36','floor':'#3f535b','edge':'#60777b','ink':'#101b26','cream':'#eee4c9','orange':'#cf744b','rust':'#9c4b3b','mint':'#8fb9af','red':'#e38a74','skin':'#bf926d'}
timeline=json.loads((ROOT/'timeline.json').read_text()) if (ROOT/'timeline.json').exists() else []
DURATION=timeline[-1]['end']+3 if timeline else 80

def bike(c,x,y,s=1):
 c=c.group(x,y,s)
 c.ellipse((-125,15,130,45),'#11202b')
 for xx in [-87,85]:
  c.ellipse((xx-32,-34,xx+32,30),'#0b1520','#7f9292',5)
  c.ellipse((xx-19,-21,xx+19,17),'#334a56');c.ellipse((xx-5,-7,xx+5,3),'#a4b4aa')
 c.line([(-85,-4),(-44,-53),(35,-54),(85,-4),(-25,-6),(-44,-53)],'#879994',8)
 c.poly([(-50,-67),(18,-75),(52,-56),(29,-33),(-38,-37)],P['orange'])
 c.round((-67,-84,12,-68),5,'#101c25');c.line([(71,-13),(51,-101),(35,-112)],'#c0c6b2',7)
 c.line([(48,-101),(88,-106)],'#c0c6b2',6);c.ellipse((64,-99,88,-77),P['cream'])
 c.round((-104,-132,-44,-85),7,'#a75e40');c.line([(-74,-130),(-74,-87)],'#efc78d',3)
 c.rect((-103,-107,-47,-98),'#efc78d')

def boy(c,x,y,s,t,walk=False,phone=False,scared=False,customer=False,reach=0):
 c=c.group(x,y,s);c=c.group(0,-abs(math.sin(t*7))*4 if walk else math.sin(t*2)*1.5)
 skin=P['skin'];shirt='#93aaa0' if customer else P['orange'];dark='#213344'
 c.ellipse((-65,-7,65,11),'#0f202c')
 if not customer:
  c.round((-70,-240,-29,-121),9,'#99513b',P['orange'],3)
  c.rect((-65,-216,-31,-204),'#ecc38a')
 for xx,sign in [(-22,1),(22,-1)]:
  st=math.sin(t*7)*25*sign if walk else 0
  limb(c,(xx,-129),(xx+st*.5,-68),dark,28);limb(c,(xx+st*.5,-68),(xx+st,-13),dark,24)
  c.round((xx+st-15,-20,xx+st+27,-1),5,'#c5c8b5');c.rect((xx+st-15,-7,xx+st+27,-2),'#7b8c8d')
 c.round((-46,-249,46,-130),12,shirt)
 c.poly([(-38,-239),(-26,-246),(27,-136),(13,-131)],'#483d3d' if not customer else '#708b86')
 if not customer:
  c.rect((-40,-195,40,-187),'#ebc393');c.round((13,-229,34,-210),3,P['cream']);c.txt((24,-220),'K',12,P['rust'])
 c.line([(0,-229),(0,-143)],'#e0a071',2)
 swing=math.sin(t*7)*20 if walk else 0
 limb(c,(-44,-231),(-59,-187+swing),shirt,22);limb(c,(-59,-187+swing),(-55,-146+swing),skin,17)
 if phone:
  limb(c,(44,-230),(72,-208),shirt,22);limb(c,(72,-208),(57,-283),skin,17)
  c.round((47,-306,66,-266),4,P['ink'],'#a5b3a8',2)
 elif reach:
  limb(c,(44,-230),(72,-266),shirt,22);limb(c,(72,-266),(93,-310),skin,17)
 else:
  limb(c,(44,-231),(57,-184-swing),shirt,22);limb(c,(57,-184-swing),(55,-143-swing),skin,17)
 c.rect((-12,-272,12,-241),skin)
 c.ellipse((-34,-343,34,-270),skin)
 for xx in [-36,27]:c.ellipse((xx,-316,xx+9,-297),skin)
 c.poly([(-33,-305),(-35,-331),(-18,-349),(8,-354),(31,-340),(35,-316),(22,-327),(-15,-325),(-25,-306)],'#13222c')
 if not customer:
  c.round((-37,-349,34,-332),6,'#bf6545');c.poly([(-39,-336),(40,-336),(55,-329),(-38,-329)],P['orange'])
 blink=t%4.4>4.23
 for xx in [-11,12]:
  c.line([(xx-5,-315),(xx+5,-319 if scared else -315)],'#382f2c',2)
  if blink:c.line([(xx-3,-306),(xx+3,-306)],P['ink'],2)
  else:c.ellipse((xx-3,-309,xx+3,-303),P['ink'])
 c.line([(1,-304),(5,-296),(0,-295)],'#966d55',2)
 if scared:c.ellipse((-5,-288,6,-279),'#483d36')
 else:c.line([(-7,-285),(8,-285)],'#684c40',2)

def corridor(c,t,number='404',opening=0,many=False):
 c.rect((0,0,720,1280),P['wall'])
 c.poly([(0,0),(720,0),(559,225),(161,225)],'#182c38')
 c.poly([(0,0),(161,225),(161,890),(0,1090)],'#20323e')
 c.poly([(720,0),(559,225),(559,890),(720,1090)],'#142735')
 c.poly([(0,1090),(161,890),(559,890),(720,1090),(720,1280),(0,1280)],P['floor'])
 for xx in [-300,0,240,480,720,1020]:c.line([(360,760),(xx,1280)],'#536971',2)
 for yy in [947,1040,1170]:c.line([(0,yy),(720,yy)],'#536971',2)
 c.rect((268,250,452,262),P['cream'])
 c.poly([(280,264),(440,264),(560,900),(160,900)],'#2b414a')
 c.rect((240,363,503,900),'#0a1824');c.rect((252,377,491,896),'#536366')
 if opening:
  width=239*(1-.82*opening);c.poly([(252,377),(252+width,377+55*opening),(252+width,896-30*opening),(252,896)],'#46575c')
  # A silhouette stays almost invisible behind the opening.
  c.ellipse((400,495,463,565),'#142330');c.poly([(405,552),(462,552),(481,875),(384,875)],'#142330')
  c.ellipse((419,524,423,528),'#9ea998');c.ellipse((440,524,444,528),'#9ea998')
 else:
  c.rect((271,398,472,688),None,'#697b7b',2);c.rect((271,718,472,873),None,'#697b7b',2)
 dx=252+239*(1-.82*opening)
 c.round((dx-83,420,dx-29,454),4,'#1a2f3b');c.txt((dx-56,438),number,20,P['cream'],mono=True)
 c.ellipse((dx-40,663,dx-31,672),P['cream']);c.line([(dx-36,669),(dx-62,669)],P['cream'],4)
 # pipes, loose wiring, wall damage
 c.line([(197,228),(197,671),(213,690),(213,887)],'#617373',5)
 c.line([(170,300),(213,325),(186,358),(209,393)],'#182d37',3)
 for yy in [477,695]:
  c.line([(566,yy),(603,yy+15),(614,yy+1)],'#40545d',2)
 if many:
  for xx in [15,575]:
   c.poly([(xx,300),(xx+127,388),(xx+127,957),(xx,1065)],'#0b1924')
   c.poly([(xx+12,324),(xx+116,398),(xx+116,943),(xx+12,1024)],'#42555d')
   c.round((xx+28,435,xx+104,477),4,'#1a2b36');c.txt((xx+66,456),'404',24,P['cream'],mono=True)
 c.txt((106,166),'STAIR B',17,P['mint'],mono=True)

def stairs(c,t,progress=0,floor='3',run=False):
 c.rect((0,0,720,1280),'#1d333f')
 c.rect((0,0,720,160),'#142732');c.rect((0,160,720,173),'#52676e')
 c.rect((55,207,170,349),'#304954');c.txt((111,254),'FLOOR',16,P['mint']);c.txt((111,307),floor,46,P['cream'],mono=True)
 c.rect((469,195,649,539),'#112732');c.rect((482,208,636,525),'#26444f')
 for xx in [518,564,610]:c.line([(xx,209),(xx,526)],'#536f76',4)
 c.rect((275,219,411,228),P['cream']);c.poly([(281,231),(402,231),(600,600),(113,600)],'#263f49')
 # upper landing and diagonal staircase, thirteen explicit treads
 c.rect((0,570,180,602),'#7e8e8c');c.rect((0,602,180,626),'#374f5b')
 for i in range(13):
  x=170+i*32;y=590+i*25
  c.rect((x,y,x+34,y+120),'#304957');c.rect((x,y,x+34,y+11),'#86948d');c.line([(x,y+12),(x+34,y+12)],'#1c3543',2)
 c.rect((586,915,720,942),'#87948d');c.rect((586,942,720,1054),'#344d59')
 u=progress%1;x=lerp(127,633,u);y=lerp(575,918,u)
 boy(c,x,y,.83,t,walk=True,scared=run)
 # near railing makes depth clear
 for i in range(10):
  xx=160+i*48;yy=469+i*32;c.line([(xx,yy),(xx,yy+180)],'#112734',9);c.line([(xx+3,yy),(xx+3,yy+180)],'#648088',2)
 c.line([(0,452),(143,452),(635,781),(720,781)],'#9baba4',10)
 c.line([(0,466),(143,466),(635,795),(720,795)],'#142b39',8)
 c.rect((0,1060,720,1280),'#112634')

def shaft(c,t,second=False):
 c.rect((0,0,720,1280),'#263c46')
 # Two nested rectangular landings around an open well.
 c.poly([(44,234),(676,234),(676,1015),(44,1015)],'#101f2a')
 for k,(x,y,w,h) in enumerate([(72,269,576,691),(160,365,400,480)]):
  c.rect((x,y,x+w,y+h),'#465b62')
  c.rect((x+34,y+40,x+w-34,y+h-42),'#152c38')
  for i in range(12):
   yy=y+45+i*(h-90)/12;c.line([(x,yy),(x+32,yy)],'#82928d',2)
   c.line([(x+w-31,yy),(x+w,yy)],'#82928d',2)
  c.rect((x+26,y+31,x+w-26,y+h-33),None,'#9eada4',4)
 c.rect((248,467,472,756),'#58716d')
 for yy in [507,572,637,702]:c.line([(248,yy),(472,yy)],'#69807a',1)
 bike(c,360,653,.55)
 c.line([(99,297),(99,341)],P['orange'],5);c.line([(187,394),(187,437)],P['orange'],5)
 c.txt((360,160),'PHIR WAHI DO MANZIL' if second else 'BAS DO MANZIL DOOR',24,P['red'] if second else P['cream'])
 # foreground hands grip railing
 c.line([(15,1003),(705,1003)],'#afbab0',15)
 for xx in [173,547]:c.round((xx-33,982,xx+32,1034),15,P['skin'])
 if second:
  c.line([(264,799),(457,799)],P['red'],3)
  c.txt((360,831),'DISTANCE: UNCHANGED',13,P['mint'],mono=True)

def phone(c,t,mode='message',message=None):
 c.rect((0,0,720,1280),P['bg'])
 # diagonal stair silhouettes keep the setting present
 for i in range(12):c.rect((0,180+i*62,115+i*47,199+i*62),'#1b303c')
 c.poly([(116,1280),(158,852),(514,850),(620,1280)],'#714b3e')
 c.round((142,222,578,1003),45,'#080f18','#5a7479',4)
 c.round((160,244,560,980),31,'#213f4a')
 c.round((286,255,435,280),13,'#090f18');c.txt((208,301),'02:13',17,P['cream'],mono=True)
 c.txt((505,301),'LTE',14,P['mint'],mono=True)
 c.txt((360,376),'CUSTOMER',29,P['cream'])
 c.line([(185,416),(535,416)],'#526b70',2)
 if mode=='order':
  c.txt((360,476),'DELIVER TO',19,P['mint']);c.txt((360,566),'404',99,P['cream'],mono=True)
  c.txt((360,650),'FOURTH FLOOR',21,P['cream']);c.round((194,731,526,807),15,P['orange']);c.txt((360,770),'ORDER PICKED UP',21,P['ink'])
 elif mode=='call':
  c.ellipse((282,462,438,618),'#496971');c.ellipse((336,486,384,534),P['mint']);c.round((315,540,405,588),25,P['mint'])
  c.txt((360,684),'INCOMING CALL',23,P['mint'])
  amp=4+3*math.sin(t*5)
  for i in range(13):
   h=8+abs(math.sin(t*9+i*.7))*amp*5;c.line([(240+i*20,750-h),(240+i*20,750+h)],P['mint'],5)
  c.ellipse((309,842,411,944),'#74988b');c.txt((360,892),'CALL',19,P['ink'])
 else:
  y=488+8*(1-ease(t*2))
  c.round((184,y,529,y+194),17,'#d1d1b8')
  lines=message or ['Ek floor neeche','aa jao.']
  for i,line in enumerate(lines):c.txt((356,y+58+i*44),line,28,'#20343f')
  c.txt((483,y+170),'02:13',13,'#61716e',mono=True)
  c.txt((360,759),'Message received',16,P['mint'])
  c.line([(313,928),(407,928)],P['cream'],4)
 # thumb
 c.round((514,731,593,940),32,P['skin']);c.line([(530,768),(570,768)],'#976f55',2)

def exterior(c,t,reveal=False,people=True):
 c.rect((0,0,720,1280),'#0b1b29')
 c.ellipse((548,112,620,184),'#bec5b0')
 for i in range(25):
  x=(i*173+31)%720;y=(i*79+73)%530;c.ellipse((x,y,x+2,y+2),'#607d87')
 if reveal:
  # Ground floor plus two upper storeys: roof is fully visible.
  c.rect((103,414,617,997),'#304952');c.rect((87,397,633,419),'#77857f')
  for row in range(3):
   yy=450+row*173
   for xx in [146,453]:
    c.rect((xx,yy,xx+118,yy+117),'#0f2431');c.rect((xx+9,yy+9,xx+109,yy+108),'#355a63');c.line([(xx+59,yy),(xx+59,yy+117)],'#728b88',4)
   if row<2:c.rect((105,yy+142,615,yy+152),'#687d7c')
  c.rect((306,795,415,997),'#101e28');c.txt((360,764),'ENTRY',15,P['cream'])
  c.line([(647,420),(670,420),(670,763),(647,763)],P['red'],3)
  c.txt((655,592),'2',25,P['cream'])
 else:
  # Cropped facade conceals roof until the reveal.
  c.rect((82,0,638,1000),'#2d4651')
  for row in range(5):
   yy=-40+row*200
   for xx in [130,460]:
    c.rect((xx,yy,xx+120,yy+136),'#102733');c.rect((xx+10,yy+10,xx+110,yy+126),'#2c525e');c.line([(xx+60,yy),(xx+60,yy+136)],'#65817e',3)
   c.rect((83,yy+164,636,yy+176),'#5e7475')
  c.rect((290,718,430,1000),'#0b1b28');c.rect((300,730,420,1000),'#364f59')
 c.rect((0,998,720,1280),'#1c3440');c.rect((0,997,720,1010),'#6f807d')
 bike(c,220,1101,.75)
 if people:
  if reveal:boy(c,464,1095,.64,t,phone=True,customer=True)
  else:boy(c,lerp(401,483,ease(t/4)),1060,.78,t,walk=True)
 c.line([(45,730),(45,1000)],'#657d7d',8);c.rect((27,721,94,734),P['cream'])
 if not reveal:c.txt((360,170),'02:13 AM',33,P['cream'],mono=True)

def window(c,t,shout=False):
 c.rect((0,0,720,1280),P['wall']);c.rect((124,207,626,967),P['ink'])
 c.rect((144,227,606,945),'#1b3541');c.poly([(144,635),(606,517),(606,945),(144,945)],'#405a60')
 for i in range(4):c.line([(144,691+i*67),(606,573+i*67)],'#5b7478',2)
 bike(c,392,795,.58);boy(c,506,719,.45,t,phone=True,customer=True)
 c.rect((124,207,626,967),None,'#91a09a',14);c.line([(371,217),(371,955)],'#91a09a',10)
 c.line([(140,506),(613,506)],'#91a09a',10);c.rect((94,962,651,989),'#b1b7a5')
 boy(c,188,1095,1.23,t,scared=True,reach=shout)
 if shout:c.txt((450,343),'UPAR DEKHO!',30,P['cream'])

def finaldoor(c,t,u):
 corridor(c,t,opening=ease(u*.9))
 boy(c,174,1053,1.0,t,phone=True,scared=True)
 # advancing dark shape creeps along floor
 if u>.5:c.poly([(450,891),(482,891),(657,1120),(299,1120)],'#10212e')

def frame(t):
 im=Image.new('RGB',(W,H),P['bg']);c=C(im)
 row=next((r for r in timeline if r['start']<=t<r['end']),timeline[-1] if timeline else {'scene':'exterior','start':0,'end':5,'caption':''})
 sc=row['scene'];idx=timeline.index(row) if timeline else 0
 first=last=idx
 while first>0 and timeline[first-1]['scene']==sc:first-=1
 while last+1<len(timeline) and timeline[last+1]['scene']==sc:last+=1
 start=timeline[first]['start'] if timeline else 0;end=timeline[last]['end'] if timeline else 5
 u=(t-start)/max(.001,end-start);local=t-start
 zoom=1+.035*ease(u) if sc not in ['down1','down2'] else 1
 c=C(im,360*(1-zoom),620*(1-zoom),zoom)
 if t>=timeline[-1]['end'] if timeline else False:
  c.txt((360,415),'EK FLOOR',55,P['cream']);c.txt((360,487),'NEECHE',68,P['red']);c.line([(300,572),(420,572)],P['mint'],3)
  c.txt((360,660),'AAKHRI AAHAT',30,P['cream']);c.txt((360,715),'Kuch raaste khatam nahi hote.',18,P['mint']);return im
 if sc=='exterior':exterior(c,local)
 elif sc=='order':phone(c,local,'order')
 elif sc in ['landing4','landing3']:
  corridor(c,t);boy(c,lerp(159,217,ease(u)),1040,1.1,t,walk=u<.6,scared=sc=='landing3');c.txt((108,261),'04' if sc=='landing4' else '03',45,P['mint'],mono=True)
 elif sc in ['msg1','msg2','msgfinal']:
  phone(c,local,message=['Ek floor','neeche.'] if sc=='msg2' else ['Bas ek floor','aur.'] if sc=='msgfinal' else None)
 elif sc in ['down1','down2']:stairs(c,t,u*(2 if sc=='down2' else 1),'3' if sc=='down1' else '?',sc=='down2')
 elif sc in ['shaft1','shaft2']:shaft(c,t,sc=='shaft2')
 elif sc=='call':phone(c,local,'call')
 elif sc in ['talk','panic']:
  corridor(c,t);boy(c,343,1055,1.8,t,phone=True,scared=sc=='panic')
 elif sc=='customer':
  exterior(c,t,people=False);c.rect((0,0,720,720),'#152c39');c.txt((360,200),'GATE KE BAHAR',25,P['mint']);boy(c,414,1117,1.6,t,phone=True,customer=True)
 elif sc=='all404':corridor(c,t,many=True);boy(c,360,1090,.85,t,scared=True)
 elif sc in ['window','shout']:window(c,t,sc=='shout')
 elif sc=='reveal':exterior(c,t,True)
 elif sc=='door':finaldoor(c,t,u)
 # small branding and chapter tick stay outside action
 c=C(im)
 c.txt((360,50),'AAKHRI AAHAT',14,'#9db1ae')
 c.line([(52,88),(52+616*t/DURATION,88)],'#809f9b',2)
 # Safe, high-contrast subtitle panel with deliberate line breaks.
 if row.get('caption') and sc not in ['msg1','msg2','msgfinal']:
  lines=row['caption'].split('\n');height=45*len(lines)+36
  c.round((38,1165-height,682,1165),12,'#0b1a25')
  for i,line in enumerate(lines):c.txt((360,1183-height+i*43+20),line,27,P['cream'])
 return im

def preview():
 sheet=Image.new('RGB',(1080,math.ceil(len(timeline)/6)*346),P['bg']);d=ImageDraw.Draw(sheet)
 for i,r in enumerate(timeline):
  t=(r['start']+r['end'])/2;im=frame(t);im.save(OUT/f'qa_{i:02}.jpg',quality=86)
  x=i%6*180;y=i//6*346;sheet.paste(im.resize((180,320)),(x,y));d.text((x+6,y+323),f'{i:02} {r["scene"]}',fill='white')
 sheet.save(OUT/'contact_sheet.jpg',quality=90)

def render():
 name='Ek_Floor_Neeche_4K.mp4' if '--4k' in sys.argv else 'Ek_Floor_Neeche_1080p.mp4'
 cmd=['ffmpeg','-v','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{W}x{H}','-framerate',str(FPS),'-i','pipe:0','-i',str(ROOT/'audio/Final_Mix.wav'),'-c:v','libx264','-threads','4','-preset','veryfast','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-movflags','+faststart','-t',str(DURATION),str(OUT/name)]
 p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 for i in range(math.ceil(FPS*DURATION)):
  p.stdin.write(frame(i/FPS).tobytes())
  if i%(FPS*5)==0:print(f'{i/FPS:.0f}/{DURATION:.1f} seconds rendered',flush=True)
 p.stdin.close();assert p.wait()==0;print('Complete',flush=True)

if __name__=='__main__':
 if '--preview' in sys.argv:preview()
 if '--render' in sys.argv:render()
