"""Phrase-aligned edit and original synthesized sound design. No speech time stretching."""
from pathlib import Path
import math,json,subprocess
import numpy as np
from scipy.io import wavfile
from scipy.ndimage import uniform_filter1d,maximum_filter1d
from scipy.signal import butter,sosfilt
ROOT=Path(__file__).resolve().parent;SR=48000
# Speech boundaries, scene, Roman Hindi subtitle, extra hold after the phrase.
ROWS=[
 (0,'exterior','Raat ke 2:13 baje...',0),
 (2.68,'exterior','Delivery boy Kabir\nbuilding pahuncha.',0),
 (5.86,'order','Order tha... flat 404.',.35),
 (8.82,'landing4','Chauthi manzil par\ncustomer ka message aaya.',.15),
 (11.9,'msg1','Ek floor neeche aa jao.',.55),
 (14.02,'down1','Kabir teesri manzil\npar utar gaya.',.35),
 (16.28,'landing3','Yahan bhi... 404?',.45),
 (19.22,'msg2','Phone phir baja.',0),
 (20.36,'msg2','Ek floor neeche.',.55),
 (21.88,'shaft1','Usne seedhiyon ke\nbeech se neeche dekha.',0),
 (24.74,'shaft1','Neeche uski bike\nkhadi thi.',0),
 (26.98,'shaft1','Bas do manzil door.',.45),
 (28.66,'down2','Woh do manzil\naur utra.',1.2),
 (30.6,'shaft2','Bike... ab bhi\ndo manzil neeche thi.',.8),
 (33.86,'call','Tabhi customer ka\ncall aaya.',.2),
 (35.4,'customer','Bhaiya, kahan ho?\nMain gate par khada hoon.',.1),
 (38.18,'panic','Kabir ki awaaz\nkaanp gayi.',0),
 (40.1,'panic','Aap hi toh mujhe\nneeche bula rahe ho!',.2),
 (41.8,'customer','Nahi bhaiya... main toh\nkab se keh raha hoon...',0),
 (44.42,'customer','Building mein mat jaana.',.5),
 (45.94,'all404','Kabir palta.',0),
 (47.22,'all404','Har darwaaze par\nek hi number tha.',0),
 (49.88,'all404','404.',.7),
 (51.38,'window','Usne khidki se\nbahar jhaanka.',0),
 (53.88,'window','Customer uski bike\nke paas khada tha.',0),
 (57.06,'shout','Kabir chillaya...',0),
 (58.18,'shout','UPAR DEKHO!',.4),
 (59.30,'customer','Customer ne dheere\nse kaha...',0),
 (61.69,'reveal','Is building mein toh\nsirf DO MANZIL hain.',1.2),
 (65.08,'door','Kabir ke peeche\nek darwaaza khula.',.5),
 (67.4,'door','Phone par aakhri\nmessage aaya.',.35),
 (69.45,'msgfinal','Bas ek floor aur.',1.0),
]

def timestamp(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'

def main():
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(ROOT/'audio/Viraj_original.mp3'),'-af','loudnorm=I=-18:TP=-3:LRA=9','-ar',str(SR),'-ac','1',str(ROOT/'audio/voice_normalized.wav')],check=True)
 sr,v=wavfile.read(ROOT/'audio/voice_normalized.wav');v=v.astype(np.float64)/32768
 rows=[];pos=.24
 for i,(a,scene,cap,hold) in enumerate(ROWS):
  b=ROWS[i+1][0] if i+1<len(ROWS) else len(v)/SR
  duration=b-a
  rows.append(dict(start=pos if i else 0,end=pos+duration+hold,voice_start=pos,source_start=a,source_end=b,scene=scene,caption=cap))
  pos+=duration+hold
 duration=math.ceil((pos+3)*30)/30
 voice=np.zeros(round(duration*SR))
 for r in rows:
  clip=v[round(r['source_start']*SR):round(r['source_end']*SR)].copy()
  n=min(96,len(clip)//2);clip[:n]*=np.linspace(0,1,n);clip[-n:]*=np.linspace(1,0,n)
  idx=round(r['voice_start']*SR);voice[idx:idx+len(clip)]+=clip
 n=len(voice);t=np.arange(n)/SR;rng=np.random.default_rng(404)
 # Quiet original ambient score with slow dissonant tones and stereo movement.
 music=.025*np.sin(2*np.pi*49*t)*( .65+.35*np.sin(t*.41))
 music+=.015*np.sin(2*np.pi*73.6*t+.35*np.sin(t*.2))+.007*np.sin(2*np.pi*147.1*t)
 noise=sosfilt(butter(2,420,fs=SR,output='sos'),rng.standard_normal(n))*.022
 bed=np.column_stack([music+noise,music+np.roll(noise,1300)])
 fx=np.zeros((n,2))
 def add(at,sound,pan=0):
  idx=round(at*SR);k=min(len(sound),n-idx)
  if idx<0 or k<=0:return
  fx[idx:idx+k,0]+=sound[:k]*(1-.3*pan);fx[idx:idx+k,1]+=sound[:k]*(1+.3*pan)
 def tone(d,f,amp=.08):
  q=np.arange(round(d*SR))/SR;return amp*np.sin(2*np.pi*f*q)*np.exp(-q*8)*np.minimum(1,q*250)
 def thump(d=.25):
  q=np.arange(round(d*SR))/SR;return .12*np.sin(2*np.pi*(86*q-65*q*q))*np.exp(-q*18)+.04*rng.standard_normal(len(q))*np.exp(-q*30)
 seen=set()
 for r in rows:
  sc=r['scene'];start,end=r['start'],r['end']
  if sc in ['msg1','msg2','msgfinal'] and sc not in seen:
   add(start+.04,tone(.5,880,.07));add(start+.17,tone(.4,1174,.05));seen.add(sc)
  if sc in ['down1','down2']:
   for at in np.arange(start+.15,end-.15,.42):add(at,thump(),-.4 if int(at*10)%2 else .4)
  if sc=='shaft2':add(start,thump(.6))
  if sc=='call':
   for at in [start,start+.45]:add(at,tone(.35,660,.06)+tone(.35,880,.04))
  if sc=='door' and sc not in seen:
   q=np.arange(round(1.6*SR))/SR;s=.05*np.sin(2*np.pi*(190*q+35*np.sin(q*2)))*np.sin(np.pi*q/1.6)**2;add(start+.3,s,.7);seen.add(sc)
  if sc=='reveal':add(end-.9,thump(.6))
 # Drop ambience beneath the final message; resolve with a single low impact.
 last=rows[-1]['start'];fade_start=rows[-2]['end']-.45
 fade=np.clip((last-t)/max(.1,last-fade_start),0,1);bed*=fade[:,None]
 add(rows[-1]['end']+.03,thump(.8));bed[-SR*2:]*=np.linspace(1,0,SR*2)[:,None]
 activity=maximum_filter1d((np.abs(voice)>.016).astype(float),size=9601)
 duck=uniform_filter1d(.7-.42*activity,size=6001)
 mix=voice[:,None]+bed*duck[:,None]+fx*.65
 gain=min(1,.84/max(np.max(np.abs(mix)),1e-8));mix*=gain
 wavfile.write(ROOT/'audio/Viraj_Synced.wav',SR,(np.clip(voice,-1,1)*32767).astype(np.int16))
 wavfile.write(ROOT/'audio/Music_and_Effects.wav',SR,(np.clip(bed+fx*.65,-1,1)*32767).astype(np.int16))
 wavfile.write(ROOT/'audio/Final_Mix.wav',SR,(np.clip(mix,-1,1)*32767).astype(np.int16))
 (ROOT/'timeline.json').write_text(json.dumps(rows,indent=2))
 (ROOT/'output/Ek_Floor_Neeche_Hinglish.srt').write_text('\n\n'.join(f'{i+1}\n{timestamp(r["start"])} --> {timestamp(r["end"])}\n{r["caption"]}' for i,r in enumerate(rows))+'\n')
 (ROOT/'output/qa_audio.json').write_text(json.dumps(dict(duration=duration,peak_dbfs=20*np.log10(np.max(np.abs(mix))),finite=bool(np.isfinite(mix).all()),voice_speed_changed=False),indent=2))
 print('Duration:',duration,'peak dBFS:',20*np.log10(np.max(np.abs(mix))),flush=True)

if __name__=='__main__':main()
