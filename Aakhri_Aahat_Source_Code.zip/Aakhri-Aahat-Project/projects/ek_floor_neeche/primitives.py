from PIL import Image, ImageDraw, ImageFont
import math
SCALE=1.5
FONT="/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
MONO="/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
fonts={}
P={"white":"#eee8d7"}
def ease(v):
 v=max(0,min(1,v)); return v*v*(3-2*v)
def lerp(a,b,t): return a+(b-a)*t
class C:
 def __init__(self,im,x=0,y=0,s=1): self.im=im;self.d=ImageDraw.Draw(im);self.x=x;self.y=y;self.s=s
 def pt(self,p): return ((self.x+p[0]*self.s)*SCALE,(self.y+p[1]*self.s)*SCALE)
 def box(self,b): return (*self.pt(b[:2]),*self.pt(b[2:]))
 def group(self,x,y,s=1): return C(self.im,self.x+x*self.s,self.y+y*self.s,self.s*s)
 def rect(self,b,fill,outline=None,width=1): self.d.rectangle(self.box(b),fill,outline,width=max(1,round(width*self.s*SCALE)))
 def round(self,b,r,fill,outline=None,width=1):self.d.rounded_rectangle(self.box(b),r*self.s*SCALE,fill,outline,width=max(1,round(width*self.s*SCALE)))
 def ellipse(self,b,fill,outline=None,width=1):self.d.ellipse(self.box(b),fill,outline,width=max(1,round(width*self.s*SCALE)))
 def poly(self,pts,fill):self.d.polygon([self.pt(p) for p in pts],fill)
 def line(self,pts,fill,width=1):self.d.line([self.pt(p) for p in pts],fill,width=max(1,round(width*self.s*SCALE)),joint='curve')
 def txt(self,xy,txt,size=22,fill=None,anchor='mm',mono=False):
  key=(max(1,round(size*self.s*SCALE)),mono)
  if key not in fonts:fonts[key]=ImageFont.truetype(MONO if mono else FONT,key[0])
  self.d.text(self.pt(xy),txt,font=fonts[key],fill=fill or P['white'],anchor=anchor)

def limb(c,a,b,col,w):
 c.line([a,b],col,w);r=w/2
 for x,y in [a,b]: c.ellipse((x-r,y-r,x+r,y+r),col)

