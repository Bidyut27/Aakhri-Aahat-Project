# Ek Floor Neeche — Edit map

| Start | End | Scene | Caption |
|---:|---:|---|---|
| 0.00 | 2.92 | exterior | Raat ke 2:13 baje... |
| 2.92 | 6.10 | exterior | Delivery boy Kabir / building pahuncha. |
| 6.10 | 9.41 | order | Order tha... flat 404. |
| 9.41 | 12.64 | landing4 | Chauthi manzil par / customer ka message aaya. |
| 12.64 | 15.31 | msg1 | Ek floor neeche aa jao. |
| 15.31 | 17.92 | down1 | Kabir teesri manzil / par utar gaya. |
| 17.92 | 21.31 | landing3 | Yahan bhi... 404? |
| 21.31 | 22.45 | msg2 | Phone phir baja. |
| 22.45 | 24.52 | msg2 | Ek floor neeche. |
| 24.52 | 27.38 | shaft1 | Usne seedhiyon ke / beech se neeche dekha. |
| 27.38 | 29.62 | shaft1 | Neeche uski bike / khadi thi. |
| 29.62 | 31.75 | shaft1 | Bas do manzil door. |
| 31.75 | 34.89 | down2 | Woh do manzil / aur utra. |
| 34.89 | 38.95 | shaft2 | Bike... ab bhi / do manzil neeche thi. |
| 38.95 | 40.69 | call | Tabhi customer ka / call aaya. |
| 40.69 | 43.57 | customer | Bhaiya, kahan ho? / Main gate par khada hoon. |
| 43.57 | 45.49 | panic | Kabir ki awaaz / kaanp gayi. |
| 45.49 | 47.39 | panic | Aap hi toh mujhe / neeche bula rahe ho! |
| 47.39 | 50.01 | customer | Nahi bhaiya... main toh / kab se keh raha hoon... |
| 50.01 | 52.03 | customer | Building mein mat jaana. |
| 52.03 | 53.31 | all404 | Kabir palta. |
| 53.31 | 55.97 | all404 | Har darwaaze par / ek hi number tha. |
| 55.97 | 58.17 | all404 | 404. |
| 58.17 | 60.67 | window | Usne khidki se / bahar jhaanka. |
| 60.67 | 63.85 | window | Customer uski bike / ke paas khada tha. |
| 63.85 | 64.97 | shout | Kabir chillaya... |
| 64.97 | 66.49 | shout | UPAR DEKHO! |
| 66.49 | 68.88 | customer | Customer ne dheere / se kaha... |
| 68.88 | 73.47 | reveal | Is building mein toh / sirf DO MANZIL hain. |
| 73.47 | 76.29 | door | Kabir ke peeche / ek darwaaza khula. |
| 76.29 | 78.69 | door | Phone par aakhri / message aaya. |
| 78.69 | 81.36 | msgfinal | Bas ek floor aur. |
