# Ek Floor Neeche — Aakhri Aahat

An original Hindi supernatural horror short in flat 2D motion graphics.

## Delivery

- Approximately 84 seconds, vertical 9:16, 30 fps.
- Native 2160 × 3840 geometric render and 1080 × 1920 viewing copy.
- Hindi narration and all spoken dialogue performed by the approved ElevenLabs voice **Viraj — Deep, Suspenseful and Mysterious**.
- Roman Hindi captions burned into the image; a matching SRT is included.
- Original procedural ambient music, message alerts, footsteps, ringing, a door creak and low impacts.
- Speech retains its generated speed and pitch. Phrase pauses were extended for visual storytelling.

## Story

Delivery boy Kabir arrives for an order to flat 404. Messages tell him to descend, but each landing repeats and his bike stays two floors below. The real customer calls from outside and reveals that the building has only two upper floors. A door opens behind Kabir. One last message says, “Bas ek floor aur.”

The opening view deliberately crops the roof; the final exterior reveals the complete two-storey-above-ground facade. The stairwell is supernatural and is not intended as a physically consistent architectural plan.

## Files

- `render.py`: editable scene geometry, character rig, camera moves, overlays and export.
- `primitives.py`: scaled vector drawing helpers.
- `prepare.py`: phrase timing, audio assembly and procedural sound generation.
- `timeline.json`: source voice intervals, final scene timing and captions.
- `Narration_Hindi.txt`: complete Hindi recording script with performance cues.
- `audio/Viraj_original.mp3`: approved-voice source take.
- `audio/word_timings.json`: timing metadata returned by the transcription service.
- `audio/Viraj_Synced.wav`: isolated, aligned narration.
- `audio/Final_Mix.wav`: final 48 kHz stereo mix.
- `audio/Music_and_Effects.wav`: separate background track.
- `output/Ek_Floor_Neeche_Hinglish.srt`: timed Roman Hindi captions.
- `output/contact_sheet.jpg`: storyboard review frames.
- `output/qa_audio.json`: duration and peak-level check.

## Reproduce

Python 3.12, Pillow, NumPy, SciPy, FFmpeg with libx264, and DejaVu Sans fonts are required. The code uses system FFmpeg and font paths in `primitives.py`; change those if needed on another machine.

```bash
python prepare.py
python render.py --preview
python render.py --render --4k
ffmpeg -i output/Ek_Floor_Neeche_4K.mp4 -vf scale=1080:1920 -c:v libx264 -crf 20 -preset fast -c:a copy -movflags +faststart output/Ek_Floor_Neeche_1080p.mp4
```

Artwork is defined in 720 × 1280 coordinates and rasterized at three times that resolution for the 4K master. Text and geometry are drawn at output resolution, not enlarged from completed 720p frames.

## Animation scope

Limited 2D motion graphics: jointed walking, blinking, breathing, phone waveforms, an opening door, creeping shadow and camera pushes. Mouth animation is not phoneme lip-sync. The editable project is Python source and media assets, not an After Effects or Premiere project.

## Voice provenance

Voice ID: F8IvasoAdpDhOjLm5YBm. Model: eleven_v4. Source take: rPddFA4PIvXuCtiFkFYz. Flow: ssaplOakSrDH5oEsYnA4. Source audio is bundled so rebuilding does not require paid voice regeneration.
