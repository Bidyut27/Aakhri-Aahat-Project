"""Sync the approved Viraj take by phrase, without changing voice pitch/speed.
Run after render.py --render --4k. Source speech is included in narrated/.
The working render remains the 75s original; narrated masters are separate.
"""
from pathlib import Path
import json,math,subprocess,sys
import numpy as np
from scipy.io import wavfile
from scipy.ndimage import uniform_filter1d, maximum_filter1d
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
import render
OUT=ROOT/'narrated';OUT.mkdir(exist_ok=True);SR=48000
# Original video interval, source voice interval. None preserves a dramatic pause.
cuts=[
(0,3.1,.15,1.62),(3.1,6.3,1.64,5.22),(6.3,8.3,5.22,6.5),
(8.3,10.2,6.5,9.14),(10.2,14.2,9.14,13.78),(14.2,17.4,13.78,18.84),
(17.4,20,18.84,20.76),(20,22.2,20.76,22.73),(22.2,24.6,23.11,25.22),
(24.6,27,25.42,27.32),(27,30,27.32,30.20),(30,33,None,None),
(33,36,30.22,33.32),(36,39.5,33.32,36.09),(39.5,42,36.15,37.38),
(42,44,37.38,38.44),(44,47,38.44,39.54),(47,50,39.54,41.86),
(50,53.2,41.86,44.74),(53.2,54,None,None),(54,56.4,44.74,46.34),
(56.4,58,None,None),(58,61,46.64,49.06),(61,64,49.06,50.5),
(64,66,50.5,52.42),(66,68.5,52.42,56.17),(68.5,72,56.23,58.32),
(72,75,None,None)]
segments=[];dest=0
for a,b,sa,sb in cuts:
 d=math.ceil(max(b-a,(sb-sa+.18) if sa is not None else 0)*30-1e-7)/30
 segments.append(dict(old_start=a,old_end=b,new_start=dest,new_end=dest+d,voice_start=sa,voice_end=sb))
 dest+=d
DUR=round(dest,6)
def warp(t):
 for s in segments:
  if t<=s['old_end']+1e-8:return s['new_start']+(t-s['old_start'])*(s['new_end']-s['new_start'])/(s['old_end']-s['old_start'])
 return DUR

def build_audio():
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(OUT/'Viraj_original.mp3'),'-af','loudnorm=I=-18:TP=-2:LRA=9','-ar',str(SR),'-ac','1',str(OUT/'voice_normalized.wav')],check=True)
 sr,data=wavfile.read(OUT/'voice_normalized.wav');voice=data.astype(np.float64)/32768
 narr=np.zeros(round(DUR*SR));bed=np.zeros((len(narr),2))
 for j,s in enumerate(segments):
  a,b=s['old_start'],s['old_end'];ds,de=s['new_start'],s['new_end'];dur=de-ds
  cmd=['ffmpeg','-v','error','-ss',str(a),'-t',str(b-a),'-i',str(ROOT/'output/Music_and_Effects.wav'),'-af',f'atempo={(b-a)/dur:.9f}','-ar',str(SR),'-ac','2','-f','f32le','pipe:1']
  block=np.frombuffer(subprocess.check_output(cmd),dtype='<f4').reshape(-1,2).copy()
  n=min(len(block),round(dur*SR));idx=round(ds*SR)
  fade=min(240,n//2)
  block[:fade]*=np.linspace(0,1,fade)[:,None];block[n-fade:n]*=np.linspace(1,0,fade)[:,None]
  bed[idx:idx+n]+=block[:n]
  if s['voice_start'] is not None:
   v=voice[round(s['voice_start']*SR):round(s['voice_end']*SR)].copy()
   fade=min(120,len(v)//2);v[:fade]*=np.linspace(0,1,fade);v[-fade:]*=np.linspace(1,0,fade)
   begin=round((ds+.09)*SR);narr[begin:begin+len(v)]+=v
   s['voice_placed_start']=ds+.09;s['voice_placed_end']=ds+.09+len(v)/SR
 # Pre-duck the music before speech, with a soft recovery in pauses.
 rms=np.sqrt(np.maximum(0,uniform_filter1d(narr*narr,size=960)))
 activity=maximum_filter1d((rms>.008).astype(float),size=9601)
 duck=uniform_filter1d(.72-.48*activity,size=6721)
 mixed=narr[:,None]+bed*duck[:,None]
 for s in segments:
  if s['old_start']==56.4:
   lo,hi=round(s['new_start']*SR),round(s['new_end']*SR)
   mixed[max(0,lo-480):lo]*=np.linspace(1,0,min(480,lo))[:,None]
   mixed[lo:hi]=0
 # A little extra headroom; never clip the original voice.
 peak=float(np.max(np.abs(mixed)));gain=min(1,.88/max(peak,1e-8));mixed*=gain
 wavfile.write(OUT/'Viraj_Synced_Voice.wav',SR,(np.clip(narr,-1,1)*32767).astype(np.int16))
 wavfile.write(OUT/'Final_Mix.wav',SR,(np.clip(mixed,-1,1)*32767).astype(np.int16))
 (OUT/'sync_timeline.json').write_text(json.dumps({'duration':DUR,'source_generation':'RmbuzyCTDjddr4KzwBPy','voice':'Viraj','voice_speed_changed':False,'segments':segments,'peak_dbfs':20*math.log10(max(peak*gain,1e-9))},indent=2))
 (OUT/'Kal_Ki_Recording_Hinglish_Synced.srt').write_text('\n\n'.join(f'{i+1}\n{render.srt_time(warp(a))} --> {render.srt_time(warp(b))}\n{txt}' for i,(a,b,txt) in enumerate(render.CAPS))+'\n')
 print('Audio aligned. Duration:',DUR,flush=True)

def video():
 expr='T'
 for s in reversed(segments):
  a,b=s['old_start'],s['old_end'];d=s['new_start'];ratio=(s['new_end']-d)/(b-a)
  f=f'({d:.9f}+(T-{a:.9f})*{ratio:.9f})'
  expr=f'if(lt(T,{b:.9f}),{f},{expr})'
 vf=f"setpts='{expr}/TB',fps=30"
 (OUT/'video_filter.txt').write_text(vf)
 cmd=['ffmpeg','-v','error','-y','-i',str(ROOT/'output/Kal_Ki_Recording_2D_4K.mp4'),'-i',str(OUT/'Final_Mix.wav'),'-map','0:v:0','-map','1:a:0','-vf',vf,'-c:v','libx264','-threads','4','-preset','veryfast','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-t',str(DUR),'-movflags','+faststart',str(OUT/'Kal_Ki_Recording_2D_4K.mp4')]
 subprocess.run(cmd,check=True)
 print('4K narrated master complete.',flush=True)

if __name__=='__main__':
 build_audio()
 if '--audio-only' not in sys.argv:video()
