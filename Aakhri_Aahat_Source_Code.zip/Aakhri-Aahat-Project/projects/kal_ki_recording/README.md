# Kal Ki Recording — Aakhri Aahat

81.3-second narrated flat 2D motion-graphics horror short. The original visual cut was 75 seconds.

## Delivery status

The video includes geometric environments, jointed character animation, moving doors and props, animated warning cards, CCTV effects, timed Roman Hindi captions, original synthesized music and sound effects, and an ending card.

**Hindi narration is included**, using the user-approved ElevenLabs Viraj voice. Take RmbuzyCTDjddr4KzwBPy supplies the narrator and spoken dialogue. Phrase boundaries were aligned using returned word timestamps. Speech retains its original speed and pitch; selected shots were extended to fit it. Background music and effects are ducked under speech. The blackout remains silent. Character mouths are not lip-synced.

The 4K master is rendered directly from procedural geometry at 2160 × 3840, 30 fps, H.264 with AAC stereo audio. The 1080p copy is a downscaled viewing version. Narrated runtime: 81.3 seconds.

## Art direction

The user's The Last Lift reference informed the flat geometric style, restrained palette, simple facial details, perspective backgrounds, articulated limbs, prop-driven action, and lower-screen captions. No frames or audio from the reference have been reused. Previously generated painted illustrations are deliberately excluded from this production.

## Files

- render.py — editable procedural animation, original sound generation, caption timing, export commands.
- Narration_Hindi.md — approved narration and voice direction.
- output/Kal_Ki_Recording_Hinglish.srt — timed Roman Hindi captions.
- output/timeline.json — timing data.
- output/Music_and_Effects.wav — 48 kHz stereo music and effects mix, without narration.

## Reproduce or edit

Requires Python 3, Pillow, numpy, scipy, FFmpeg with libx264, and DejaVu fonts. Change font paths near the top of render.py if necessary.

```
python render.py --preview
python render.py --render --4k
```

Native working coordinates are 720 × 1280; geometry and fonts are multiplied by 3 before drawing the 4K output, rather than upscaling raster frames. The preview uses a 1.5 scale.

## Narrated version

The narrated/ directory includes the approved Viraj source MP3, the synced voice WAV, final stereo mix, word timings, sync timeline, and synchronized SRT captions. sync_voice.py recreates the edit. No new speech generation is needed.

To reproduce the narrated master, first render the original 75-second picture, then run:

```
python sync_voice.py
```

The output master goes into narrated/Kal_Ki_Recording_2D_4K.mp4. The lower-resolution preview is a downscale of that master. The original output/Music_and_Effects.wav is the 75-second music/effects source used by sync_voice.py.

## Scope of animation

This is deliberately limited flat 2D motion graphics: rigged limbs, walking cycles, blinking, gentle breathing, sliding doors, rotating fan, advancing hands, screen changes, and prop movement. It is not frame-by-frame character animation or lip-synced dialogue.
