"""Original flat 2D motion-graphics short. Geometry and animation are procedural.
Run: python render.py --preview; python render.py --render
No generated raster artwork is used. Requires Pillow, numpy, scipy and FFmpeg.
"""
from pathlib import Path
import math, json, subprocess, sys, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy.signal import butter, sosfilt

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output'; OUT.mkdir(exist_ok=True)
SCALE=3 if '--4k' in sys.argv else 1.5; W,H=int(720*SCALE),int(1280*SCALE); FPS=30; DURATION=75
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
MONO='/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'
fonts={}
P={'bg':'#0b1720','wall':'#22353e','side':'#192a33','floor':'#30434b','line':'#49606a','navy':'#314e60','navy2':'#243d4d','skin':'#ba8e69','skin2':'#9f7557','hair':'#101f27','yellow':'#c6a65a','paper':'#ddd8bd','white':'#e8e8d6','red':'#d97770','mint':'#91bcb4'}
def ease(v):
 v=max(0,min(1,v)); return v*v*(3-2*v)
def lerp(a,b,t): return a+(b-a)*t
class C:
 def __init__(self,im,x=0,y=0,s=1): self.im=im;self.d=ImageDraw.Draw(im);self.x=x;self.y=y;self.s=s
 def pt(self,p): return ((self.x+p[0]*self.s)*SCALE,(self.y+p[1]*self.s)*SCALE)
 def box(self,b): return (*self.pt(b[:2]),*self.pt(b[2:]))
 def group(self,x,y,s=1): return C(self.im,self.x+x*self.s,self.y+y*self.s,self.s*s)
 def rect(self,b,fill,outline=None,width=1): self.d.rectangle(self.box(b),fill,outline,width=max(1,round(width*self.s*SCALE)))
 def round(self,b,r,fill,outline=None,width=1):self.d.rounded_rectangle(self.box(b),r*self.s*SCALE,fill,outline,width=max(1,round(width*self.s*SCALE)))
 def ellipse(self,b,fill,outline=None,width=1):self.d.ellipse(self.box(b),fill,outline,width=max(1,round(width*self.s*SCALE)))
 def poly(self,pts,fill):self.d.polygon([self.pt(p) for p in pts],fill)
 def line(self,pts,fill,width=1):self.d.line([self.pt(p) for p in pts],fill,width=max(1,round(width*self.s*SCALE)),joint='curve')
 def txt(self,xy,txt,size=22,fill=None,anchor='mm',mono=False):
  key=(max(1,round(size*self.s*SCALE)),mono)
  if key not in fonts:fonts[key]=ImageFont.truetype(MONO if mono else FONT,key[0])
  self.d.text(self.pt(xy),txt,font=fonts[key],fill=fill or P['white'],anchor=anchor)

def limb(c,a,b,col,w):
 c.line([a,b],col,w);r=w/2
 for x,y in [a,b]: c.ellipse((x-r,y-r,x+r,y+r),col)

def person(c,x,y,s,t,kind='aman',pose='idle',walk=0,raisehand=0,paper=None,ghost=False):
 """Origin at shoes; rigged flat limbs, body bob, eye blink and changing expressions."""
 c=c.group(x,y,s);bob=math.sin(t*2.3)*1.4 if not walk else abs(math.sin(t*7))*3
 c=c.group(0,-bob)
 female=kind=='woman';other=kind=='other'
 shirt='#a9a38e' if female else ('#647b80' if other else P['navy'])
 trouser='#747d77' if female else '#203440'
 skin='#9bafa4' if ghost else P['skin']; hair=P['hair']
 crouch=pose=='crouch'; bodyY=-160 if crouch else -245
 # shadow
 c.ellipse((-65,-9,65,8),'#11232b')
 # legs and shoes; articulated steps
 if crouch:
  limb(c,(-24,-105),(-61,-63),trouser,29);limb(c,(-61,-63),(-33,-12),trouser,25)
  limb(c,(24,-105),(61,-63),trouser,29);limb(c,(61,-63),(33,-12),trouser,25)
 else:
  stride=math.sin(t*7)*20*walk
  for a,off in [(-22,stride),(22,-stride)]:
   limb(c,(a,-132),(a+off*.5,-70),trouser,25);limb(c,(a+off*.5,-70),(a+off,-15),trouser,23)
   c.round((a+off-17,-19,a+off+23,-2),5,'#a4aea8')
 if crouch:
  c.round((-55,-17,-15,-1),4,'#a4aea8');c.round((15,-17,55,-1),4,'#a4aea8')
 # torso
 c.round((-48,bodyY,48,bodyY+117),13,shirt)
 if female:
  c.poly([(-40,bodyY+28),(40,bodyY+28),(55,-43),(-55,-43)],shirt)
  c.poly([(-32,bodyY),(-14,bodyY),(25,bodyY+122),(5,bodyY+119)],'#c2bca6')
 else:
  c.line([(-2,bodyY+15),(-2,bodyY+107)],'#80908b',1)
  c.rect((-35,bodyY+38,-11,bodyY+55),'#58707a');c.rect((10,bodyY+38,34,bodyY+55),'#58707a')
  c.line([(-20,bodyY+5),(-7,bodyY+63),(15,bodyY+5)],P['yellow'],4)
  c.round((-14,bodyY+63,2,bodyY+84),2,P['paper'])
  for xx in [-37,25]: c.rect((xx,bodyY+4,xx+14,bodyY+9),P['yellow'])
 # arms around two pivot joints
 if paper is not None:
  for sign in [-1,1]:
   limb(c,(sign*44,bodyY+16),(sign*58,bodyY+60),shirt,20)
   limb(c,(sign*58,bodyY+60),(sign*48,bodyY+43),skin,16)
 elif female:
  limb(c,(-46,bodyY+14),(-74,bodyY-8*raisehand+45*(1-raisehand)),shirt,20)
  limb(c,(-74,bodyY-8*raisehand+45*(1-raisehand)),(-74,bodyY-62*raisehand+62*(1-raisehand)),skin,14)
  limb(c,(46,bodyY+14),(45,bodyY+65),shirt,20);limb(c,(45,bodyY+65),(-16,bodyY+54),skin,15)
  c.line([(-45,bodyY+46),(-34,bodyY+57)],'#9d5955',5)
 else:
  swing=math.sin(t*7)*25*walk
  for sign in [-1,1]:
   sh=(sign*46,bodyY+16);el=(sign*(54+20*raisehand),bodyY+60-50*raisehand+sign*swing)
   hand=(sign*(56+20*raisehand),bodyY+100-145*raisehand+sign*swing)
   limb(c,sh,el,shirt,20);limb(c,el,hand,skin,15)
 # neck and hair silhouette
 c.rect((-13,bodyY-23,13,bodyY+4),skin)
 hy=bodyY-62
 if female:c.round((-38,hy-47,38,bodyY+43),22,hair)
 c.ellipse((-31,hy-39,31,hy+39),skin)
 c.ellipse((-35,hy-5,-24,hy+12),skin);c.ellipse((24,hy-5,35,hy+12),skin)
 if female:
  c.poly([(-34,hy+22),(-34,hy-30),(-12,hy-48),(20,hy-43),(34,hy-20),(34,hy+54),(21,hy+26),(17,hy-23),(-8,hy-14),(-23,hy-5),(-25,hy+49)],hair)
 else:
  c.poly([(-32,hy-5),(-34,hy-31),(-17,hy-44),(-4,hy-39),(10,hy-49),(28,hy-37),(33,hy-12),(22,hy-22),(-20,hy-18),(-24,hy-2)],hair)
 # eyes and eyebrows
 blink=(t%4.3)>4.12
 for xx in [-11,11]:
  if blink:c.line([(xx-3,hy+1),(xx+3,hy+1)],hair,2)
  else:c.ellipse((xx-2,hy-2,xx+2,hy+3),hair)
  c.line([(xx-5,hy-11),(xx+5,hy-8 if pose=='crouch' else hy-11)],hair,2)
 c.line([(1,hy+3),(4,hy+11),(0,hy+12)],P['skin2'],1)
 if crouch or ghost:c.ellipse((-4,hy+20,5,hy+27),'#413d35')
 else:c.line([(-7,hy+22),(7,hy+22)],'#604b3e',2)
 if not female:
  c.line([(-16,hy+21),(-11,hy+33),(12,hy+33),(19,hy+21)],'#6c5a48',2)
 if paper is not None:
  c.round((-101,bodyY+38,101,bodyY+130),2,P['paper'],'#a8aa98',1)
  if paper:
   for i,line in enumerate(paper.split('\n')):c.txt((0,bodyY+67+i*25),line,17,'#26343a')
  for sign in [-1,1]:c.ellipse((sign*95-8,bodyY+61,sign*95+8,bodyY+81),skin)

def room(c,t,morning=False):
 c.rect((0,0,720,1280),P['wall'])
 c.poly([(0,0),(720,0),(630,160),(90,160)],'#31444c')
 c.poly([(0,0),(90,160),(90,935),(0,1070)],P['side'])
 c.poly([(720,0),(630,160),(630,935),(720,1070)],'#1a2d35')
 c.poly([(0,1070),(90,935),(630,935),(720,1070),(720,1280),(0,1280)],P['floor'])
 for xx in [-420,-160,100,360,620,880,1140]:c.line([(360,880),(xx,1280)],'#3c5057',1)
 for yy in [984,1049,1137,1255]:c.line([(0,yy),(720,yy)],'#3c5057',1)
 # door right
 c.rect((450,303,627,929),'#091820');c.rect((462,315,614,917),'#314952' if not morning else '#7e8980')
 c.rect((472,327,604,684),'#122e3b' if not morning else '#b6ab8c')
 c.poly([(472,327),(496,327),(604,600),(604,661)],'#27424c' if not morning else '#c6b997')
 for xx in [495,535,575]:c.line([(xx,327),(xx,684)],'#4c636b',4)
 c.rect((480,746,502,752),P['paper']);c.rect((487,738,494,778),'#7b8d91')
 c.txt((537,287),'SECURITY',13,P['mint'])
 # clock/calendar
 c.ellipse((115,238,213,336),'#0b1b23');c.ellipse((120,243,208,331),'#bcc0aa')
 for a in range(12):
  an=a*math.pi/6;c.line([(164+36*math.sin(an),287-36*math.cos(an)),(164+39*math.sin(an),287-39*math.cos(an))],'#43575c',2)
 c.line([(164,287),(164,252)],'#273c44',3);c.line([(164,287),(187,274)],'#273c44',4)
 c.round((105,365,222,496),3,P['paper']);c.rect((105,365,222,390),'#8b5552')
 c.txt((164,408),'NOVEMBER',11,'#43545a');c.txt((164,447),'12',37,'#263b43')
 c.txt((164,478),'THURSDAY',9,'#63706b')
 # tube light and fan, rotating geometric blades
 c.round((295,176,429,186),3,'#b8bea3')
 c.line([(361,20),(361,83)],'#0e212b',6)
 for a in [0,2.094,4.189]:
  angle=a+t*2.4;pts=[]
  for rr,da in [(12,-.4),(104,-.13),(106,.13),(12,.4)]:pts.append((361+rr*math.cos(angle+da),86+rr*.24*math.sin(angle+da)))
  c.poly(pts,'#162a34')
 c.ellipse((347,75,375,97),'#475d64')
 # table
 c.poly([(102,786),(404,786),(447,824),(68,824)],'#8a866e')
 c.rect((68,824,447,844),'#b0a58a');c.rect((88,844,104,1013),'#22343c');c.rect((414,844,430,1013),'#22343c')
 c.round((161,789,301,808),3,'#1c3039')
 for yy in [793,799,804]:c.line([(167,yy),(295,yy)],'#536970',1)
 # monitor, exact screen rectangle
 c.round((105,511,402,777),9,'#0a1820','#5d737a',2)
 c.rect((118,526,389,752),'#123139')
 c.rect((234,777,273,809),'#172b34');c.round((197,805,309,815),4,'#172b34')
 c.ellipse((380,762,385,767),P['mint'] if int(t*2)%2 else '#536c65')
 # switch
 c.round((415,559,444,610),2,'#7c8986');c.rect((423,568,435,596),'#c2c5ad')
 if morning:
  c.poly([(480,685),(602,685),(720,1230),(404,1087)],'#726d58')
  # floor keys
  c.ellipse((350,1040,369,1059),None,P['yellow'],3);c.line([(367,1050),(399,1073)],P['yellow'],3);c.line([(391,1068),(385,1076)],P['yellow'],3)

def gate(c,t,opening=0):
 c.rect((0,0,720,1280),'#0d2029')
 c.rect((60,136,660,1050),'#233e49')
 c.poly([(60,1050),(660,1050),(720,1280),(0,1280)],'#344952')
 for x in [110,360,610]: c.line([(360,900),(x,1280)],'#48606a',2)
 # distant facade and trees
 c.rect((112,350,608,790),'#182e37')
 for xx in range(137,600,100):
  for yy in [385,495,605]:c.rect((xx,yy,xx+57,yy+76),'#24434e');c.line([(xx+28,yy),(xx+28,yy+76)],'#102830',3)
 for x in [76,631]:
  c.rect((x-5,510,x+5,1020),'#102b32')
  for yy in [490,560,630]:c.ellipse((x-65,yy-52,x+65,yy+75),'#142f32')
 c.rect((33,160,687,1085),'#091a23')
 # glass gate below, view preserved by inner opening
 c.rect((55,180,665,1056),'#17323c')
 # restore courtyard viewport
 c.rect((73,199,647,1038),'#1d3944')
 for xx in [95,222,449,576]:
  c.rect((xx,370,xx+65,750),'#142c36');c.line([(xx+32,370),(xx+32,750)],'#2b4650',2)
 c.poly([(73,800),(647,800),(647,1038),(73,1038)],'#304a52')
 for yy in [846,913,1007]:c.line([(73,yy),(647,yy)],'#3c5660',1)
 # overhead lamp
 c.rect((307,232,413,241),'#ccd0ac');c.poly([(317,242),(403,242),(481,800),(239,800)],'#28454d')
 c.txt((360,120),'NORTH BLOCK',18,'#849d9f')

def gate_front(c,t,opening=0):
 # door frames animate sideways
 gap=opening*240
 c.line([(360-gap,195),(360-gap,1042)],'#78908c',6)
 c.line([(360+gap,195),(360+gap,1042)],'#78908c',6)
 c.line([(342-gap,640),(342-gap,742)],'#b2b8a6',5)
 c.line([(378+gap,640),(378+gap,742)],'#b2b8a6',5)
 if opening<.15:
  c.poly([(83,209),(113,209),(425,1029),(395,1029)],'#37505a')
 # intercom
 c.round((5,550,49,710),4,'#405761','#79908c',1)
 c.ellipse((16,571,38,593),'#10252e')
 for yy in range(609,651,7):c.line([(14,yy),(39,yy)],'#1a323c',2)
 c.ellipse((17,669,37,689),P['yellow'])

def surveillance(c,t,label='CAM 02 / ENTRANCE',date='13 NOV 2026',time='02:00:00'):
 overlay=ImageDraw.Draw(c.im,'RGBA')
 for yy in range(0,1280,7):overlay.line([c.pt((0,yy)),c.pt((720,yy))],fill=(8,20,26,40),width=max(1,round(SCALE*.4)))
 # graphic corner brackets
 for xx,yy,dx,dy in [(45,137,1,1),(675,137,-1,1),(45,1017,1,-1),(675,1017,-1,-1)]:c.line([(xx,yy+dy*26),(xx,yy),(xx+dx*26,yy)],P['mint'],2)
 c.rect((44,154,676,199),'#10232c');c.txt((63,175),label,15,anchor='lm',mono=True)
 c.txt((654,175),'REC',14,P['red'],anchor='rm')
 if int(t*2)%2==0:c.ellipse((589,170,597,178),P['red'])
 c.rect((44,959,676,1008),'#10232c');c.txt((62,982),date,16,P['mint'],anchor='lm',mono=True);c.txt((650,982),time,16,P['mint'],anchor='rm',mono=True)

def underdesk(c,t,paper='',reveal=1):
 c.rect((0,0,720,1280),'#132832');c.poly([(0,0),(720,0),(619,300),(101,300)],'#30474f')
 c.rect((85,264,635,304),'#8b8872');c.rect((85,304,635,321),'#a49d82')
 c.rect((104,321,128,1060),'#0c2029');c.rect((591,321,615,1060),'#0c2029')
 for xx in [190,258,472]:c.line([(xx,321),(xx+20,400),(xx-10,480)],'#425a60',4)
 c.poly([(128,974),(592,974),(720,1280),(0,1280)],'#304751')
 person(c,360,1000,2.3,t,pose='crouch',paper=paper if reveal>0 else None)

def monitor_insert(im,t,mode):
 # Render the insert separately, with matching geometry, for a genuine screen-in-scene.
 mini=Image.new('RGB',(W,H),P['bg']);m=C(mini)
 if mode in ['woman','trapped']:
  gate(m,t);person(m,360,1014,1.7,t,kind='woman' if mode=='woman' else 'aman',raisehand=.9,ghost=mode=='trapped');gate_front(m,t)
 else:underdesk(m,t,paper='',reveal=0)
 crop=mini.crop((int(65*SCALE),int(195*SCALE),int(655*SCALE),int(1038*SCALE)))
 # screen is 271 x 226, intentional CCTV wide presentation; preserve full character
 crop=crop.resize((int(271*SCALE),int(226*SCALE)),Image.Resampling.BILINEAR)
 im.paste(crop,(int(118*SCALE),int(526*SCALE)))
 c=C(im);c.rect((118,526,389,548),'#102730');c.txt((126,537),'13 NOV / 02:00',9,P['mint'],anchor='lm',mono=True)
 c.txt((380,737),'REC',9,P['red'],anchor='rm')

def bolt(c,t):
 c.rect((0,0,720,1280),'#1d323d');c.rect((70,155,568,1080),'#40545c');c.rect((568,155,640,1080),'#172a33')
 for xx in [105,190,275,360,445,530]:c.line([(xx,165),(xx,1067)],'#496069',2)
 c.round((130,512,533,666),6,'#1f343d','#6a8083',3)
 c.round((563,525,621,650),5,'#81908b')
 for xx in [150,512,581,606]:
  for yy in [539,637]:c.ellipse((xx-4,yy-4,xx+4,yy+4),'#263b43')
 shift=ease((t-25)/1.1)*104
 c.round((178+shift,567,496+shift,610),7,'#b8c0ad');c.line([(189+shift,574),(486+shift,574)],'#e0dfc2',3)
 c.round((284+shift,554,309+shift,642),5,'#9daea5')
 # moving hand and sleeve follows the bolt
 c.poly([(0,881),(75,894),(293+shift,642),(264+shift,610)],P['navy'])
 c.ellipse((266+shift,601,316+shift,666),P['skin']);c.line([(282+shift,610),(297+shift,625)],P['skin2'],2)
 c.txt((360,416),'SECURITY ROOM',20,P['mint'])
 if t>26.3:c.txt((360,750),'LOCKED',23,P['mint'])

def power(c,t):
 c.rect((0,0,720,1280),'#233b46')
 c.round((276,363,528,713),10,'#82928d','#b6baa5',3)
 for xx in [300,503]:
  for yy in [390,685]:c.ellipse((xx-4,yy-4,xx+4,yy+4),'#344c55')
 c.round((352,454,454,620),7,'#bec2a9');c.line([(357,469),(449,469)],'#e4dfbe',4)
 c.txt((402,417),'MONITOR',18,'#243d46')
 prog=ease((t-47)/3.2)
 x=lerp(112,335,prog);y=lerp(1010,651,prog)
 c.poly([(0,1280),(154,1280),(x+25,y+80),(x-45,y+65)],P['navy'])
 c.ellipse((x-46,y,x+36,y+103),P['skin']);limb(c,(x+9,y+17),(x+18,y-62),P['skin'],23)
 c.txt((360,850),'POWER',18,P['mint'])

def breach(c,t):
 c.rect((0,0,720,1280),'#152b35');c.poly([(0,975),(720,975),(720,1280),(0,1280)],'#657061')
 c.round((73,283,647,925),15,'#081922','#6a8587',3)
 c.rect((95,307,625,870),'#183c44')
 c.rect((319,925,401,1014),'#122b35');c.round((250,1008,470,1028),6,'#0e2530')
 # face remains behind screen; limbs emerge progressively over frame
 q=ease((t-50)/4)
 g=c.group(360,652,1.4)
 g.ellipse((-90,-200,90,120),'#0a2029');g.ellipse((-47,-140,47,-15),'#66887f')
 g.poly([(-70,-190),(5,-216),(76,-161),(65,80),(34,12),(22,-139),(-31,-103),(-44,60),(-78,20)],'#0b1d26')
 for x in [-19,19]:g.ellipse((x-3,-95,x+3,-89),'#b9c7b0')
 # hands extend through screen as separately animated joints
 for sign in [-1,1]:
  origin=(360+sign*78,680);elbow=(360+sign*(100+q*48),722+q*58);palm=(360+sign*(144+q*65),750+q*166)
  limb(c,origin,elbow,'#547b75',37+q*14);limb(c,elbow,palm,'#7fa196',38+q*17)
  c.ellipse((palm[0]-31-q*8,palm[1]-25,palm[0]+31+q*8,palm[1]+42),'#9ab5a4')
  for j in range(4):
   xx=palm[0]+(j-1.5)*16;yy=palm[1]+22
   limb(c,(xx,yy),(xx+sign*(j-1)*9,yy+q*74+20-abs(j-1.5)*7),'#a9bdae',13)
  limb(c,(palm[0]-sign*20,palm[1]),(palm[0]-sign*58,palm[1]+36),'#94b0a0',17)
 # animated fractures, restrained rather than strobing
 for pts in [[(95,307),(189,412),(168,480),(259,563)],[(625,380),(548,443),(579,490),(499,576)],[(116,860),(199,779),(167,735)]]:
  if q>.2:c.line(pts,'#9bbdb1',1.5)
 c.txt((360,249),'CAM 01 / SECURITY ROOM',16,P['mint'],mono=True)

CAPS=[
(0,3.1,'Raat ke do baje...'),(3.1,6.3,'Aman ne CCTV par\nkhud ko dekha.'),
(6.3,8.3,'Waqt sahi tha.'),(8.3,10.2,'Lekin tareekh... KAL ki thi.'),
(10.2,14.2,'Recording mein woh ek aurat ke liye\ndarwaaza khol raha tha.'),
(14.2,17.4,'Phir wohi Aman...\ndesk ke neeche chhipa tha.'),
(17.4,20,'Tabhi entrance ki ghanti baji.'),(20,22.2,'Bahar... wohi aurat thi.'),
(22.2,24.6,'"Please... darwaaza khol do."'),
(24.6,27,'Aman ne taala check kiya.'),(27,30,'Security room bhi band kar liya.'),
(30,33,'Lekin screen par...'),(33,36,'Chhipa Aman camera ko dekh raha tha.'),
(36,39.5,'Usne ek kaagaz uthaya.'),(39.5,42,'"DARWAAZA NAHI."'),
(42,44,'Doosra kaagaz...'),(44,47,'"SCREEN BAND KAR."'),
(47,50,'Aman ka haath switch tak pahuncha...'),
(50,53.2,'Monitor ke andar se\nungliyaan bahar nikli.'),
(54,56.4,'Kamre ki batti bujh gayi.'),
(58,61,'Subah doosra guard aaya.'),(61,64,'Kursi khaali thi.'),
(64,66,'Monitor par Aman tha.'),(66,68.5,'Building ke bahar.'),
(68.5,72,'"Please... darwaaza khol do."')]

def captions(c,t):
 for a,b,txt in CAPS:
  if a<=t<b:
   lines=txt.split('\n');h=50+len(lines)*29
   c.round((35,1092,685,1092+h),4,'#081921')
   for i,line in enumerate(lines):
    size=23 if len(line)<37 else 20
    c.txt((360,1123+i*31),line,size,P['red'] if 'KAL' in line or 'SCREEN BAND' in line else P['white'])
   break

def frame(t):
 im=Image.new('RGB',(W,H),P['bg']);c=C(im)
 if t<6.3:
  room(c,t);person(c,510,1030,1.25,t,raisehand=.1);monitor_insert(im,t,'hiding')
  c.txt((360,75),'02:00 AM',21,P['paper'],mono=True)
 elif t<10.2:
  c.rect((0,0,720,1280),'#102630');c.txt((360,230),'SECURITY SYSTEM',18,P['mint'],mono=True)
  c.round((80,326,640,485),7,'#253e47','#546b71',2)
  c.txt((360,360),'AAJ / WALL CALENDAR',15,P['mint']);c.txt((360,422),'12 NOVEMBER',36)
  c.round((80,545,640,775),7,'#203740',P['red'],2)
  c.txt((360,581),'CCTV RECORDING',15,P['mint']);c.txt((360,653),'13 NOVEMBER',38,P['red'])
  c.txt((360,728),'02:00:00 AM',25,P['paper'],mono=True)
  if t>8.3:c.txt((360,864),'24 HOURS AHEAD',19,P['red'],mono=True)
 elif t<14.2:
  q=ease((t-10.7)/2.3);gate(c,t,q);person(c,450,1019,1.45,t,kind='woman');person(c,236-85*q,1030,1.45,t,walk=.5,raisehand=.5);gate_front(c,t,q);surveillance(c,t)
 elif t<17.4:
  underdesk(c,t,reveal=0);surveillance(c,t,label='CAM 01 / SECURITY ROOM')
 elif t<24.6:
  gate(c,t);person(c,360,1015,1.85,t,kind='woman',raisehand=ease((t-18)/2));gate_front(c,t);surveillance(c,t,date='12 NOV 2026',time='02:00:18')
  c.rect((47,207,147,239),'#476b62');c.txt((97,223),'LIVE',14)
 elif t<30:
  bolt(c,t)
 elif t<33:
  room(c,t);person(c,520,1030,1.25,t,raisehand=.25);monitor_insert(im,t,'hiding')
 elif t<47:
  message='DARWAAZA\nNAHI.' if t<42 else 'SCREEN\nBAND KAR.'
  underdesk(c,t,paper=message if t>=37 else '',reveal=1 if t>=36 else 0);surveillance(c,t,label='CAM 01 / SECURITY ROOM')
 elif t<50:power(c,t)
 elif t<56.4:breach(c,t)
 elif t<58:
  c.rect((0,0,720,1280),'#050e14')
 elif t<64:
  room(c,t,morning=True)
  # empty office chair
  c.round((469,775,577,895),13,'#1a3039','#516970',2);c.rect((516,895,529,992),'#172b34');c.line([(477,1006),(523,991),(570,1006)],'#182d36',7)
  q=ease((t-58)/3);person(c,lerp(760,585,q),1053,1.07,t,kind='other',walk=1 if t<61 else 0)
  if t>62:monitor_insert(im,t,'trapped')
  c.txt((360,230),'06:15 AM',17,P['paper'],mono=True)
 elif t<72:
  gate(c,t);person(c,360,1015,1.85,t,raisehand=.85,ghost=True);gate_front(c,t);surveillance(c,t,date='13 NOV 2026',time='02:00:00')
 elif t<75:
  c.rect((0,0,720,1280),'#0a1b24')
  c.line([(280,370),(440,370)],P['red'],2)
  c.txt((360,458),'KAL KI',37);c.txt((360,521),'RECORDING',49)
  c.txt((360,623),'Kuch darwaaze screen par khulte hain.',16,P['mint'])
  c.txt((360,1006),'AAKHRI AAHAT',22,P['paper']);c.txt((360,1046),'AN ORIGINAL HORROR SHORT',10,P['mint'])
 # restrained top identity tag
 if t<72:
  c.txt((360,43),'AAKHRI AAHAT',12,'#899f9e')
  captions(c,t)
 return im

def soundtrack():
 sr=48000;n=sr*DURATION;t=np.arange(n)/sr;rng=np.random.default_rng(82)
 # composed low suspense pad with slow beating harmonics
 pad=.033*np.sin(2*np.pi*55*t)+.018*np.sin(2*np.pi*55.35*t)+.012*np.sin(2*np.pi*82.41*t)
 pad*=.64+.20*np.sin(t*.31)
 noise=rng.normal(0,1,n)
 air=sosfilt(butter(2,550,fs=sr,output='sos'),noise)*.010
 mix=pad+air
 def put(at,sig,amp=1):
  i=int(at*sr);k=min(len(sig),n-i)
  if i>=0 and k>0:mix[i:i+k]+=sig[:k]*amp
 def note(freq,dur,amp=.12,decay=3):
  tt=np.arange(int(sr*dur))/sr
  return amp*(np.sin(2*np.pi*freq*tt)+.28*np.sin(2*np.pi*freq*2.01*tt))*np.exp(-tt*decay)*np.minimum(tt*60,1)
 def bell(at):
  put(at,note(880,1.8,.11,2.5));put(at+.29,note(659.25,2.3,.09,2.2))
 # sparse, original descending motif
 for at,f in [(0,220),(3.4,207.65),(6.4,164.81),(10.3,146.83),(14.2,138.59),(30,220),(33,207.65),(37,164.81),(42,138.59),(47,130.81),(64,220),(67,207.65),(69.5,138.59)]:put(at,note(f,3.8,.055,1.5))
 for at in np.arange(.5,10,.95):
  tt=np.arange(int(.035*sr))/sr;put(at,.028*rng.normal(0,1,len(tt))*np.exp(-tt*130))
 bell(17.5);bell(71.8)
 # sliding metallic bolt and clunk
 for at in [25.2,26.1]:
  tt=np.arange(int(.35*sr))/sr;sig=sosfilt(butter(2,[750,3500],btype='bandpass',fs=sr,output='sos'),rng.normal(0,1,len(tt)))
  put(at,.12*sig*np.exp(-tt*17))
 put(26.3,note(87,.5,.24,10));put(58,note(146,.55,.08,6))
 # paper rustle
 for at in [36.5,42]:
  tt=np.arange(int(.6*sr))/sr;sig=sosfilt(butter(2,[1800,6500],btype='bandpass',fs=sr,output='sos'),rng.normal(0,1,len(tt)))
  put(at,.025*sig*np.sin(np.pi*tt/.6)**2)
 # electronic rise and muted heartbeat before breach
 for at in np.arange(44,54,.84):put(at,note(48,.3,.11,18));put(at+.18,note(55,.2,.065,21))
 tt=np.arange(int(4*sr))/sr
 put(47,.018*np.sin(2*np.pi*(250*tt+100*tt*tt))*np.sin(np.pi*tt/8)**2)
 # glass crack: short high frequency splinters, no extreme volume spike
 for j in range(8):put(50+j*.045,note(1600+j*413,.23,.035,22))
 put(50,note(49,2.5,.20,2));put(55.8,note(61,.6,.14,8))
 # stop all sound in blackout, dawn then final plea atmosphere
 mix[int(56.4*sr):int(58*sr)]=0
 mix[int(58*sr):int(64*sr)]*=.30
 fade=np.minimum(t/1.2,1)*np.minimum((DURATION-t)/1.2,1)
 mix*=np.maximum(fade,0)
 # stereo, short room echo; normalize peak to -4 dBFS
 delayed=np.concatenate([np.zeros(int(.037*sr)),mix[:-int(.037*sr)]])
 stereo=np.stack([mix*.95+delayed*.05,mix*.92+delayed*.08],axis=1)
 stereo*=.63/max(np.max(np.abs(stereo)),1e-6)
 pcm=(np.clip(stereo,-1,1)*32767).astype('<i2')
 with wave.open(str(OUT/'Music_and_Effects.wav'),'wb') as f:f.setnchannels(2);f.setsampwidth(2);f.setframerate(sr);f.writeframes(pcm.tobytes())

def srt_time(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
def metadata():
 (OUT/'Kal_Ki_Recording_Hinglish.srt').write_text('\n\n'.join(f'{i+1}\n{srt_time(a)} --> {srt_time(b)}\n{txt}' for i,(a,b,txt) in enumerate(CAPS))+'\n')
 (OUT/'timeline.json').write_text(json.dumps({'duration':75,'fps':30,'captions':CAPS,'audio':'Original music and effects; no spoken narration in this cut.'},indent=2))

if __name__=='__main__':
 metadata()
 if '--preview' in sys.argv:
  times=[2,8.8,12,15.5,21,26.8,31,39.7,45,49,53.2,59.5,63,69,73]
  sheet=Image.new('RGB',(900,345*3),'#111d25');d=ImageDraw.Draw(sheet)
  for i,tm in enumerate(times):
   shot=frame(tm);shot.save(OUT/f'qa_{tm}.jpg',quality=85)
   x=i%5*180;y=i//5*345;sheet.paste(shot.resize((180,320)),(x,y));d.text((x+7,y+324),str(tm)+'s',fill='white')
  sheet.save(OUT/'contact_sheet.jpg',quality=90)
 if '--render' in sys.argv:
  soundtrack()
  filename='Kal_Ki_Recording_2D_4K.mp4' if '--4k' in sys.argv else 'Kal_Ki_Recording_2D_1080p.mp4'
  cmd=['ffmpeg','-v','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{W}x{H}','-framerate',str(FPS),'-i','pipe:0','-i',str(OUT/'Music_and_Effects.wav'),'-c:v','libx264','-threads','4','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-movflags','+faststart','-t',str(DURATION),str(OUT/filename)]
  p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
  for i in range(FPS*DURATION):
   p.stdin.write(frame(i/FPS).tobytes())
   if i%(FPS*5)==0: print(f'Rendered {i/FPS:.0f}/{DURATION} seconds',flush=True)
  p.stdin.close();assert p.wait()==0
  print('Render complete',flush=True)
